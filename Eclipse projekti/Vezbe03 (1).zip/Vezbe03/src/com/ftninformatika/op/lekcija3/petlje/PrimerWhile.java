package com.ftninformatika.op.lekcija3.petlje;

public class PrimerWhile {

	public static void main(String[] args) {

		int n = 10;
		int i = 1;
		//prethodni primer sa while naredbom
		while (i <= n) { 
			System.out.println("Usao sam u while petlju " + i + ". put");
			i++;
		}
		
		
	}

}
