package primeri07;

public class Primer02Pozivi {

	// Definicija funkcije bez parametara
	public static void happy(){
		System.out.println("Happy birthday to you!");
	}
	
	// Definicija funkcije sa parametrom
	public static void sing(String person){
		happy(); // Poziv funkcije bez argumenata
		happy();
		System.out.println("Happy birthday dear " + person);
		happy();
	}

	// Funkcija main se poziva automatski prilikom startovanja programa
	public static void main(String[] args) {
		sing("Fred"); // Poziv funkcije sa argumentom
	}
}
