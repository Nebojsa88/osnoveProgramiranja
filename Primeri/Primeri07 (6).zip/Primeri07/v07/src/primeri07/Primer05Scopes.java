package primeri07;

/*
 * Ovaj primer služi kao sumarni podsetnik koji ima za cilj da zaokruži priču o opsezima važenja promenljivih.
 */
public class Primer05Scopes {
	
	public static String global = "pocetna vrednost";
	
	public static void function() {
		global = "nova vrednost iz funkcije";
		double m = 7;
	}
	
	public static void function_with_params(double parameter) {
		parameter = 42;
		
		String global = "lokalna promenljiva koja se zove isto kao globalna";
		//Lokalna promenljiva gazi globalnu istog imena, pa globalna promenljiva global nije vidljiva
		//u funkciji
		System.out.println("global = " + global);
	}

	public static void main(String[] args) {
		
		//Menjanje vrednosti globalne promenljive u funkciji
		System.out.println("Menjanje vrednosti globalne promenljive u funkciji");
		System.out.println("global = " + global);
		function();
		System.out.println("global = " + global);
		
		
		//Pristup promenljivoj van opsega definisanosti
		int sum = 0;
		for (int i=0; i<10; i++) {
			sum += i;
		}
		//javlja se greška jer pristupamo promenljivoj izvan opsega u kom je definisana
		//System.out.println(i);	
		
		//promenljiva je lokalna promenljiva u funkciji function i nije vidljiva u main metodi
		//System.out.println(m);
		
		double par = 4;
		function_with_params(par);
		//Vrednost lokalne promenljive parametar se ne menja u okviru main metode.
		//Izmena iz funkcije function_with_params se izvršila nad lokalnom kopijom te promenljive
		//i ne utiče na vrednost promenljive u main metodi
		System.out.println("par = " + par);
		
		double parameter = 0;
		function_with_params(parameter);
		//Situacija je veoma slična kao u prethodnom slučaju.
		//Bez obzira na isto ime (parameter) lokalne promenljive u main metodi i parametra (lokalne promenljive)
		//u funkciji function_with_params, radi se o dve nezavisne promenljive.
		//Vrednost lokalne promenljive parameter iz main metode se kopira u promenljivu parameter funkcije
		//function_with_params
		System.out.println("parameter = " + parameter);
		
	}

}
