package primeri10;

import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;

public class Primer04_LocalDate_cheatsheet {

	public static void main(String[] args) {

		System.out.println("===================== POČETNA ISPROBAVANJA =====================");
		//Kreiranje današnjeg datuma
		LocalDate trenutniDatum = LocalDate.now();
		//Napomena: LocalDate predstavlja jedan datum
		
		// Kreiranje proizvoljnog datuma
		// Parametri se navode u redosledu godina, mesec, dan
		LocalDate proizvoljniDatum = LocalDate.of(2016, 12, 4);
		
		//Standardni ispis, bez zadavanja formata
		System.out.println("Neformatiran ispis: " + proizvoljniDatum);
		
		// Pristup proizvoljnim atributima - dan, mesec, godina itd.
		System.out.println("Redni broj dana u mesecu: " + proizvoljniDatum.getDayOfMonth());
		System.out.println("Mesec: " + proizvoljniDatum.getMonth());
		System.out.println("Prestupna godina: " + (proizvoljniDatum.isLeapYear()?"da":"ne"));
		
		System.out.println("\n========================= FORMATIRANJE =========================");
		// Ispis datuma u proizvoljnom formatu
		// Potrebno je zadati format u obliku stringa
		String formatDatuma = "dd.MM.yyyy.";
		
	    //Koristimo DateTimeFormatter koji služi za konverziju datuma u željeni string format
		//Prilikom inicijalizacije, neophodno je proslediti string format
		DateTimeFormatter mojFormater = DateTimeFormatter.ofPattern(formatDatuma);
		
		//Datum konvertujemo u string pozivom metode print iz formatera
		System.out.println("Rezultat formatiranja: " + mojFormater.format(proizvoljniDatum));
		
		System.out.println("\n===================== STRING TO LOCALDATE =======================");
		// Korisnik sa tastature unosi string u obliku na koji je navikao. Trebalo bi taj unos
		// konvertovati u LocalDate.
		
		// Pretpostavimo da string unos predstavlja korisnički unos
		String unos = "24.12.2016.";
		
		// Potreban nam je formater koji predstavlja string format koji korisnik upotrebljava
		LocalDate korisnickiDatum = LocalDate.parse(unos, mojFormater);
		System.out.println("Korisnik je uneo datum: " + korisnickiDatum);
		
		System.out.println("\n=========================== PERIOD =============================");
		// Period predstavlja vremenski interval određenog trajanja.
		// Ako na LocalDate dodamo Period dobijamo drugi LocalDate.
		
		// Periode mozemo inicijalizovati navođenjem Period.ofVremenskaJedinicaKojomMerimoPeriod(vrednost)
		Period periodOd10Meseci = Period.ofMonths(10);
		Period periodOd7Dana = Period.ofDays(7);
		
		// Pored toga, periode možemo inicijalizovati navođenjem trajanja u godinama, mesecima i danima.
		Period periodSaTriParametra = Period.of(34, 1, 16);
		
		// Period možemo inicijalizovati i navođenjem dva granična datuma (od-do)
		Period periodIzmedjuDvaDatuma = Period.between(trenutniDatum, proizvoljniDatum);
	
		// Određujemo koji će LocalDate biti posle odabranog period (ili koji je bio pre)
		// Koristimo metode plus i minus
		LocalDate datumZa7Dana = trenutniDatum.plus(periodOd7Dana);
		
		// Ili moze kraće:
		LocalDate datumPre11Dana = trenutniDatum.minusDays(11);
		System.out.println("Datum pre 11 dana: " + datumPre11Dana);
		
		System.out.println("\n======================= POREĐENJE DATUMA ======================");
		
		System.out.println("Prvi datum: " + mojFormater.format(trenutniDatum));
		System.out.println("Drugi datum: " + mojFormater.format(proizvoljniDatum));
		
		if (trenutniDatum.compareTo(proizvoljniDatum) < 0) {
			System.out.println("Prvi datum je pre drugog.");
		} else if (trenutniDatum.compareTo(proizvoljniDatum) > 0) {
			System.out.println("Prvi datum je posle drugog.");
		} else {
			System.out.println("Jednaki su.");
		}
	}

}
