package primeri10;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class Primer03_UnosDatuma {
	
	public static DateTimeFormatter mojFormater = DateTimeFormatter.ofPattern("dd.MM.yyyy.");
	
	public static boolean isDateValid(String stringDatum) {
		
		try {
			LocalDate.parse(stringDatum, mojFormater);
			return true;
		} catch (Exception e) {
			System.out.println("Uneli ste datum u pogrešnom formatu. Pokušajte ponovo.");
			return false;
		}		
	}
	
	public static void unosDatumaSaTastature() {
		
		System.out.println("\n======================= RUKOVANJE KORISNIČKIM UNOSOM ======================");

		String pattern = "dd.MM.yyyy.";
		Scanner sc = new Scanner(System.in);
		String str;
		LocalDate korisnickiDatum;
		
		do {
			System.out.println("Unesite datum (u formatu " + pattern + "): ");
			str = sc.nextLine();
		} while (!isDateValid(str));
		
		korisnickiDatum = LocalDate.parse(str, mojFormater);

		sc.close();
		System.out.println(korisnickiDatum);
	}
	public static void main(String[] args) {
		unosDatumaSaTastature();

	}

}
