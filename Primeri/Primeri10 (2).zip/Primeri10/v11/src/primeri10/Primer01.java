package primeri10;

import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.List;

public class Primer01 {

	public static ArrayList<String> imena = new ArrayList<String>();
	public static ArrayList<String> prezimena = new ArrayList<String>();
	
	/**
	 * Učitavanje podataka iz datoteke
	 * 
	 * @param path putanja do datoteke
	 */
	public static void load(String path) {
		//Da se sadržaj kolekcija ne bi duplirao, brišemo ga
		imena = new ArrayList<String>();
		prezimena = new ArrayList<String>();
		
		//Kreiramo kolekciju kako bi smo u nju učitali podatke iz datoteke
		List<String> lines;
		
		try {
			//Pokušaj čitanja iz fajla
			//Ukoliko dođe do Exception-a, izvršava se catch blok
			lines = Files.readAllLines(Paths.get(path), Charset.defaultCharset());
			
			//Ukoliko je učitavanje bilo uspešno, prelazimo na obradu podataka
			for (int i=0; i<lines.size(); i++) {
				//Jedna linija datoteke predstavlja podatke o jednom korisniku
				String line = lines.get(i);
				//npr. line = "Mirko;Mirkovic"
				
				//delimo učitanu liniju po znaku ";"
				String splits[] = line.split(";");
				//rezultat metode split za prethodni string bio bi
				//["Mirko", "Mirkovic"]
				//Na indeksu 0 u ovom rezultatu se nalazi ime, pa ga dodajemo u
				//kolekciju imena, a na indeksu 1 prezime, koje ubacujemo 
				//u kolekciju prezimena
				imena.add(splits[0]);
				prezimena.add(splits[1]);
	 		}
		} catch (IOException e) {
			//U slučaju da je došlo do greške prilikom učitavanja
			//ispisuje se poruka
			System.out.println("Ne postoji trazena datoteka.");
		}
	}
	
	/**
	 * Snimanje podataka u datoteku
	 * 
	 * @param path Putanja do datoteke
	 */
	public static void save(String path) {
		//Inicijalizujemo kolekciju čiji ćemo sadržaj upisati u datoteku
		ArrayList<String> lines = new ArrayList<String>();
		
		//Pripremamo podatke za upis u datoteku
		for (int i=0; i<imena.size(); i++) {
			//Podatke o jednom korisniku kreiramo spajanjem imena i prezimena
			//znakom ';' (primer "Pera" + ";" + "Peric" = "Pera;Peric")
			String line = imena.get(i) + ";"+ prezimena.get(i);
			lines.add(line);
		}
		
		try {

			//Paths.get(path) je putanja do datoteke
			//lines predstavlja sadržaj koji upisujemo u datoteku
			//Biramo opcije koji opisuju na koji način želimo da upišemo sadržaj u datoteku
			//Odabirom opcije StandardOpenOption.TRUNCATE_EXISTING pre upisa brišemo sadržaj datoteke
			//Odabirom opcije StandardOpenOption.APPEND nadovezujemo novi sadržaj datoteke na postojeći
			//Odabirom opcije StandardOpenOption.CREATE datoteka se kreira u slučaju da ne postoji
			
			//Ukoliko želimo da proširimo sadržaj datoteke
			//Files.write(Paths.get(path), lines, Charset.defaultCharset(), StandardOpenOption.CREATE, StandardOpenOption.APPEND);
			
			//Ukoliko želimo da poništimo (izgubimo) postojeći sadržaj datoteke
			Files.write(Paths.get(path), lines, Charset.defaultCharset(), StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING, StandardOpenOption.WRITE);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
 	public static void main(String[] args) {
 		
 		System.out.println("Sadržaj kolekcija pre učitavanja podataka iz datoteke: ");
 		print();
 		System.out.println(">>>>> UČITAVANJE <<<<<");
 		load("users.txt");
 		System.out.println("Sadržaj kolekcija posle učitavanja podataka iz datoteke: ");
 		print();
 		
 		System.out.println(">>>>> DODAVANJE NOVOG KORISNIKA <<<<<");
		imena.add("Đura");
		prezimena.add("Đurić");
		
 		System.out.println("Sadržaj kolekcija posle dodavanja novog korisnika: ");
 		print();
 		
 		System.out.println("Snimamo sadržaj kolekcija u datoteku...");
		save("users.txt");
		
		System.out.println("\nDodajemo novog korisnika u kolekcije.");
		imena.add("Jovana");
		prezimena.add("Jovanović");
		
		System.out.println("Ispis korisnika posle dodavanja novog korisnika: ");
 		print();
 		
 		System.out.println("Pozivamo učitavanje korisnika iz datoteke iako nismo sačuvali poslednjeg dodatog.");
 		load("users.txt");
 		System.out.println("Novi sadržaj kolekcija: ");
 		print();

	}
 	
 	/*
 	 * Metoda za ispis sadržaja kolekcija
 	 */
	public static void print() {

		for (int i=0; i<imena.size(); i++) {
			System.out.println(imena.get(i) + " " + prezimena.get(i));
		}
		System.out.println();
	}

}
