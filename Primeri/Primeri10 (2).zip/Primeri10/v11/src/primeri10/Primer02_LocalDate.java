package primeri10;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class Primer02_LocalDate {

	public static void main(String[] args) {
		
		LocalDate datum = LocalDate.now();
		
		System.out.println(datum);
		
		String pattern = "dd.MM.yyyy.";
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern(pattern);
		
		String formatiranDatum = dtf.format(datum);
		System.out.println(formatiranDatum);
		
		String unos = "25.12.2018.";
		LocalDate korisnickiDatum = LocalDate.parse(unos, dtf);
		System.out.println("Korisnicki datum: " + dtf.format(korisnickiDatum));

	}

}
