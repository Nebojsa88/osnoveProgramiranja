package com.ftninformatika.student;

import java.util.ArrayList;

public class Student {

	private int indeks;
	private String ime;
	private String prezime;
	private ArrayList<String> predmeti;
	private ArrayList<Integer> ocene;
	private double prosek;
	
	/**
	 * Konstruktor bez parametara
	 */
	public Student() {
		this.indeks = 1;
		this.ime = "";
		this.prezime = "";
		this.predmeti = new ArrayList<String>();
		this.ocene = new ArrayList<Integer>();
	}
	/**
	 * Kostruktor sa parametrima
	 * @param indeks
	 * @param ime
	 * @param prezime
	 */
	public Student(int indeks, String ime, String prezime) {
		this.indeks = indeks;
		this.ime = ime;
		this.prezime = prezime;
		this.predmeti = new ArrayList<String>();
		this.ocene = new ArrayList<Integer>();
	}
	
	
	/**
	 * @param indeks
	 * @param ime
	 * @param prezime
	 * @param predmeti
	 * @param ocene
	 */
	public Student(int indeks, String ime, String prezime, ArrayList<String> predmeti, ArrayList<Integer> ocene) {
		this.indeks = indeks;
		this.ime = ime;
		this.prezime = prezime;
		this.predmeti = predmeti;
		this.ocene = ocene;
	}
	//Getteri i setteri

	/**
	 * @return the indeks
	 */
	public int getIndeks() {
		return indeks;
	}
	/**
	 * @param indeks the indeks to set
	 */
	public void setIndeks(int indeks) {
		if (proveriIndeks(indeks)) {
			this.indeks = indeks;
		} else {
			System.out.println("Uneti indeks je manji od 0.");
		}
	}
	/**
	 * @return the ime
	 */
	public String getIme() {
		return ime;
	}
	/**
	 * @param ime the ime to set
	 */
	public void setIme(String ime) {
		if (proveriIme(ime)) {
			this.ime = ime;
		} else {
			System.out.println("Uneto ime nije validno.");
		}
	}
	/**
	 * @return the prezime
	 */
	public String getPrezime() {
		return prezime;
	}
	/**
	 * @param prezime the prezime to set
	 */
	public void setPrezime(String prezime) {
		if (proveriPrezime(prezime)) {
			this.prezime = prezime;
		} else {
			System.out.println("Uneto prezime nije validno.");
		}
	}
	/**
	 * @return the predmeti
	 */
	public ArrayList<String> getPredmeti() {
		return predmeti;
	}
	/**
	 * @param predmeti the predmeti to set
	 */
	public void setPredmeti(ArrayList<String> predmeti) {
		this.predmeti = predmeti;
	}
	/**
	 * @return the ocene
	 */
	public ArrayList<Integer> getOcene() {
		return ocene;
	}
	/**
	 * @param ocene the ocene to set
	 */
	public void setOcene(ArrayList<Integer> ocene) {
		this.ocene = ocene;
	}
	
	
	/*
	 * Izracunava prosek na osnovu unetih ocena
	 */
	public double izracunajProsek() {
		
		if (this.predmeti.size() > 0) {
			int sumaOcena = 0;
			for (int i = 0; i < this.ocene.size(); i++) {
				sumaOcena += this.ocene.get(i);
			}
			this.prosek = (double)sumaOcena / this.ocene.size();
		} else {
			System.out.println("Nije moguce izracunati prosek.");
			this.prosek = 0;
		}
		return this.prosek;
	}
	
	/**
	 * @return the prosek
	 */
	public double getProsek() {
		izracunajProsek();
		return this.prosek;
	}

	@Override
	public String toString() {
		return "Student [indeks=" + this.indeks + ", ime=" + this.ime + ", prezime=" + this.prezime + "]";
	}
	
	/*
	 * Na osnovu unetog naziva predmeta ponistava zabelezenu ocenu
	 */
	public boolean ponistiOcenu(String predmet) {

		int indeksPredmeta = -1;
		for(int i = 0; i < this.predmeti.size(); i++) {
			if(this.predmeti.get(i).equals(predmet)) {
				indeksPredmeta = i;
				break;
			}
		}
		if (indeksPredmeta != -1) {
			this.predmeti.remove(indeksPredmeta);
			this.ocene.remove(indeksPredmeta);
			return true;
		} else {
			System.out.println("Ne postoji predmet sa zadatim imenom.");
			return false;
		}
	}
	
	/*
	 * Na osnovu unetog naziva predmeta i ocene, dodaje se novi par predmet-ocena
	 */
	public boolean upisiOcenu(String predmet, int ocena) {
		
		if(proveriOcenu(ocena)) {
			int indeksPredmeta = -1;
			for(int i = 0; i < this.predmeti.size(); i++) {
				if(this.predmeti.get(i).equals(predmet)) {
					indeksPredmeta = i;
					break;
				}
			}
			if (indeksPredmeta == -1) {
				this.predmeti.add(predmet);
				this.ocene.add(ocena);
				return true;
			} else {
				System.out.println("Vec postoji predmet sa zadatim imenom.");
				return false;
			}
		} else {
			return false;
		}
	}

	/*
	 * Na osnovu unetog naziva predmeta ispisuje se ocena kojom je taj predmet polo�en
	 */
	public Integer citajOcenu(String predmet) {

		int indeksPredmeta = -1;
		for(int i = 0; i < this.predmeti.size(); i++) {
			if(this.predmeti.get(i).equals(predmet)) {
				indeksPredmeta = i;
				break;
			}
		}
		if (indeksPredmeta != -1) {
			return this.ocene.get(indeksPredmeta);
		} else {
			System.out.println("Ne postoji predmet sa zadatim imenom.");
			return null;
		}
	}
	
	/*
	 * Zamenjuje ocenu iz unetog predmeta ocenom novaOcena
	 */
	public boolean izmeniOcenu(String predmet, int novaOcena) {

		if(proveriOcenu(novaOcena)) {
			int indeksPredmeta = -1;
			for(int i = 0; i < this.predmeti.size(); i++) {
				if(this.predmeti.get(i).equals(predmet)) {
					indeksPredmeta = i;
					break;
				}
			}
			if (indeksPredmeta != -1) {
				/*this.predmeti.remove(indeksPredmeta);
				this.ocene.remove(indeksPredmeta);
	
				boolean indikator = upisiOcenu(predmet, novaOcena);
				return indikator;*/
				//ili
				this.ocene.set(indeksPredmeta, novaOcena);
				return true;
			} else {
				System.out.println("Ne postoji predmet sa zadatim imenom.");
				return false;
			}
		} else {
			return false;
		}
	}
	
	/*
	 * Ispis liste ocena sa odgovarajucim predmetima
	 */
	public void ispisiOcene(){
		System.out.println(">>>>>>>>>>Ocene<<<<<<<<<<");
		for(int i = 0; i < this.predmeti.size(); i++) {
			System.out.println("Predmet: " + this.predmeti.get(i) + ", ocena: " + this.ocene.get(i));
		}
	
	}

	
	/*
	 * Ispisuje sve podatke o studentu
	 */
	public void ispisPodatakaOStudentu() {
		System.out.println(toString());
		ispisiOcene();
		System.out.println("----------------------------------");
		System.out.println("Prosek: " + izracunajProsek());
	}
	
	/*
	 * Ispisuje nazive svih predmeta iz kojih student ima ocenu ve�u od zadate
	 */
	public void ispisiPredmeteSaOCenomVecomOd(int ocena) {

		for(int i = 0; i < this.ocene.size(); i++) {
			if(this.ocene.get(i) > ocena) {
				System.out.println(this.predmeti.get(i));
			}
		}
	}
	
	/*
	 * Iz liste predmeta ispisuju se oni koji pocinju zadatim stringom naziv
	 */
	public void pretragaPoNazivuPredmeta(String naziv) {
		
		for(int i = 0; i < this.predmeti.size(); i++) {
			if(this.predmeti.get(i).toLowerCase().startsWith(naziv.toLowerCase())) {
				System.out.println(this.predmeti.get(i));
			}
		}
	}
	
	
	// Izdvojene metode za proveru ispravnosti pri dodeli vrednosti atributima

	/*
	 * Proverava da li je indeks u zadatom formatu
	 */
	public boolean proveriIndeks(int indeks) {
		if (indeks > 0) {
			return true;
		}
		return false;
	}
	
	/*
	 * Validira ime (počinje velikim slovom i ne sadrži brojeve
	 */
	public boolean proveriIme(String ime) {
		if (ime == null || ime.equals("")) {
			return false;
		}
		
		//Proverava da li ime sadrži cifre
		for (int i = 0; i < ime.length(); i++) {
			if (!Character.isLetter(ime.charAt(i))) {
				
				return false;
			}
		}
		
		//Proverava da li ime počinje velikim slovom
		return Character.isUpperCase(ime.charAt(0));
	}
	
	/*
	 * Validira prezime (počinje velikim slovom i ne sadrži brojeve
	 */
	public boolean proveriPrezime(String prezime) {
		if (prezime == null || prezime.equals("")) {
			return false;
		}
		
		//Proverava da li prezime sadrži cifre
		for (int i = 0; i < prezime.length(); i++) {
			if (!Character.isLetter(prezime.charAt(i))) {
				return false;
			}
		}
		
		//Proverava da li prezime počinje velikim slovom
		return Character.isUpperCase(prezime.charAt(0));
	}
	

	/*
	 * Proverava da li je ocena u zadatom formatu
	 */
	public boolean proveriOcenu(int ocena) {
		if (ocena >= 6 && ocena<=10 ) {
			return true;
		}
		return false;
	}
}
