package com.ftninformatika.kurs64;

import java.util.ArrayList;

public class Kurs {

	private int sifra;
	private String naziv;
	private ArrayList<String> spisakPolaznika;
	private double cenaPoPolazniku;
	private double ukupnaCena;

	public Kurs() {
		this.naziv = "";
		this.spisakPolaznika = new ArrayList<>();
	}
	
	

	public Kurs(int sifra, String naziv, double cenaPoPolazniku) {
		this.sifra = sifra;
		this.naziv = naziv;
		this.cenaPoPolazniku = cenaPoPolazniku;
		this.spisakPolaznika = new ArrayList<>();
	}



	public Kurs(int sifra, String naziv, ArrayList<String> spisakPolaznika, double cenaPoPolazniku) {
		this.sifra = sifra;
		this.naziv = naziv;
		this.spisakPolaznika = spisakPolaznika;
		this.cenaPoPolazniku = cenaPoPolazniku;
	}

	public int getSifra() {
		return sifra;
	}

	public void setSifra(int sifra) {
		this.sifra = sifra;
	}

	public String getNaziv() {
		return naziv;
	}

	public void setNaziv(String naziv) {
		this.naziv = naziv;
	}

	public ArrayList<String> getSpisakPolaznika() {
		return spisakPolaznika;
	}

	public void setSpisakPolaznika(ArrayList<String> spisakPolaznika) {
		this.spisakPolaznika = spisakPolaznika;
	}

	public double getCenaPoPolazniku() {
		return cenaPoPolazniku;
	}

	public void setCenaPoPolazniku(double cenaPoPolazniku) {
		this.cenaPoPolazniku = cenaPoPolazniku;
	}
	
	public double izracunajSumu() {
		double suma = this.cenaPoPolazniku * this.spisakPolaznika.size();
		return suma;
	}

	public double getUkupnaCena() {
		this.ukupnaCena = izracunajSumu();
		return ukupnaCena;
	}
	
	public boolean dodajPolaznika(String imeIPrezime) {
		
		for(int i = 0; i < this.spisakPolaznika.size(); i++) {
			if(imeIPrezime.equals(this.spisakPolaznika.get(i))) {
				return false;
			}
		}
		this.spisakPolaznika.add(imeIPrezime);
		return true;
	}


	public String toString() {
		
		String temp = "";
		temp += "Sifra kursa: " + this.sifra + "\n";
		temp += "Naziv kursa: " + this.naziv + "\n";
		temp = temp + "Cena po polazniku: " + this.cenaPoPolazniku + "\n";
		temp += "Ukupna cena: " + getUkupnaCena() + "\n";
		temp += "Spisak polaznika:\n";
		for(int i = 0; i < this.spisakPolaznika.size(); i++) {
			temp += this.spisakPolaznika.get(i) + "\n";
		}
		return temp.trim();
	}

}
