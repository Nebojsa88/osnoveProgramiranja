package com.ftninformatika.kurs63;

public class Test {

	public static void main(String[] args) {
		
		Kurs kurs = new Kurs(11111, "OP", 100.0);
		System.out.println(kurs);
		kurs.dodajPolaznika("Pera Peric");
		kurs.dodajPolaznika("Pera Peric");
		kurs.dodajPolaznika("Mika Mikic");
		System.out.println(kurs);
	}

}
