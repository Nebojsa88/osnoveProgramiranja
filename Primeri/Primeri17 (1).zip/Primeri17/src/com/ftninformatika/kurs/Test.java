package com.ftninformatika.kurs;


public class Test {

	public static void main(String[] args) {
		
		Kurs kurs = new Kurs(1, "OOP", 15000.00);
		kurs.dodajPolaznika("Pera Peric");
		kurs.dodajPolaznika("Petar Peric");
		kurs.dodajPolaznika("Petar Peric");
		kurs.dodajPolaznika("Petar Peric");
		kurs.dodajPolaznika("Marko Markovic");
		kurs.dodajPolaznika("Milan Markovic");
		kurs.dodajPolaznika("Petar Peric");
		kurs.dodajPolaznika("Milana Markovic");
		//kurs.izbrisiSvePolaznike1("Petar Peric");
		//kurs.izbrisiSvePolaznike2("Petar Peric");
		//kurs.izbrisiSvePolaznike3("Petar Peric");
		//kurs.izbrisiSvePolaznike4("Petar Peric");

		kurs.izbrisiSvePolaznike0("Petar Peric");
		kurs.ispisiPolaznike();
		
		

	}

}
