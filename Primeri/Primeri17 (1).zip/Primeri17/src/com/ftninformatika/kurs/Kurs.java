package com.ftninformatika.kurs;

import java.util.ArrayList;
import java.util.Iterator;

public class Kurs {

	private int sifraKursa;
	private String nazivKursa;
	private double cenaPoPolazniku;
	private double ukupnaCena;
	private ArrayList<String> polaznici;

	public Kurs() {
		this.polaznici = new ArrayList<String>();
		this.cenaPoPolazniku = 15000.00;
	}

	public Kurs(int sifraKursa, String nazivKursa, double cenaPoPolazniku) {
		if(String.valueOf(sifraKursa).length() == 5) {
			this.sifraKursa = sifraKursa;
		} else {
			this.sifraKursa = 11111;
		}
		this.nazivKursa = nazivKursa;
		this.cenaPoPolazniku = cenaPoPolazniku;
		this.polaznici = new ArrayList<String>();
	}

	public int getSifraKursa() {
		return sifraKursa;
	}

	public void setSifraKursa(int sifraKursa) {
		if(String.valueOf(sifraKursa).length() == 5) {
			this.sifraKursa = sifraKursa;
		} else {
			this.sifraKursa = 11111;
		}
	}

	public String getNazivKursa() {
		return nazivKursa;
	}

	public void setNazivKursa(String nazivKursa) {
		this.nazivKursa = nazivKursa;
	}

	public double getCenaPoPolazniku() {
		return cenaPoPolazniku;
	}

	public void setCenaPoPolazniku(double cenaPoPolazniku) {
		this.cenaPoPolazniku = cenaPoPolazniku;
	}

	public double getUkupnaCena() {
		ukupnaCena = this.cenaPoPolazniku * this.polaznici.size();
		return ukupnaCena;
	}


	public ArrayList<String> getPolaznici() {
		return polaznici;
	}

	public void setPolaznici(ArrayList<String> polaznici) {
		this.polaznici = polaznici;
	}

	public boolean dodajPolaznika(String polaznik) {
		/*for(int i = 0; i < this.polaznici.size(); i++) {
			if(this.polaznici.get(i).equals(polaznik)) {
				return false;
			}
		}*/
		this.polaznici.add(polaznik);
		return true;
	}

	public void ispisiPolaznike() {
		for(int i = 0; i < this.polaznici.size(); i++) {
			System.out.println(this.polaznici.get(i));
		}
	}

	//Brisanje polaznika po imenu
	//POD USLOVOM DA NE POSTOJE DVA POLAZNIKA KOJA IMAJU ISTO IME I PREZIME
	public String izbrisiPolaznika(String polaznik) {

		int indeks = -1;
		for(int i = 0; i < this.polaznici.size(); i++) {
			if(this.polaznici.get(i).equals(polaznik)) {
				indeks = i;
				//this.polaznici.remove(i);
				break;
				
			}
		}
		if(indeks != -1) {
			return this.polaznici.remove(indeks);
		}
		return null;
	}
	
	public void izbrisiSvePolaznike0(String polaznik) {
		
		for(int i = this.polaznici.size()-1; i >= 0; i--) {
			if(this.polaznici.get(i).equals(polaznik)) {
				//System.out.println(this.polaznici.get(i));
				this.polaznici.remove(i);
			}
		}
	}

	//Primer brisanja više polaznika sa istim imenom korišćenjem dve metode
	public boolean izbrisiSvePolaznike1(String polaznik) {

		//dokle god lista sadrži polaznike sa prosleđenim imenom
		//pozivaj metodu izbrisiPolaznika koja će jednog po jednog da briše i skraćuje listu
		while(this.polaznici.contains(polaznik)) {
			izbrisiPolaznika(polaznik);
		}

		return true;
	}
	//Primer brisanja više polaznika sa istim imenom korišćenjem iteratora
	public boolean izbrisiSvePolaznike2(String polaznik) {

		//inicijalizuje se iterator za listu polaznika
		Iterator<String> it = this.polaznici.iterator();
		//prolazi se kroz listu pomoću iteratora sve dok ima elemenata
		while(it.hasNext()) {
			//sa metodom next() se preuzima element po element iz liste  pomoću iteratora
			//i pita se da li je taj element jednak sa prosleđenim polaznikom
			if(it.next().equals(polaznik)) {
				//ako je jednak, koristi se remove() metoda koja se poziva 
				//nad iteratorom i briše se elemet iz liste
				it.remove();
			}
		}

		return true;
	}

	//Primer brisanja više polaznika pomoću removeAll metode
	public boolean izbrisiSvePolaznike3(String polaznik) {

		//Kreiramo pomoćnu listu u koju dodajemo sve polaznike sa prosleđenim imenom
		ArrayList<String> polazniciZaBrisanje = new ArrayList<String>();
		for(int i = 0; i < this.polaznici.size(); i++) {
			if(this.polaznici.get(i).equals(polaznik)) {
				polazniciZaBrisanje.add(this.polaznici.get(i));
			}
		}
		//koristimo metodu removeAll nad originalnom listom i prosleđujemo pomoćnu listu
		//koja sadrži sve elemente koji treba da se obrišu iz originalne liste
		this.polaznici.removeAll(polazniciZaBrisanje);

		return true;
	}

	//Primer brisanja više polaznika pomoću pomoćne liste indeksa
	public boolean izbrisiSvePolaznike4(String polaznik) {

		//pravimo pomoćnu listu koja će sadržati pozicije elemenata koji se brišu
		ArrayList<Integer> indeksi = new ArrayList<Integer>();
		for(int i = 0; i < this.polaznici.size(); i++) {
			if(this.polaznici.get(i).equals(polaznik)) {
				indeksi.add(i);
			}
		}

		System.out.println("-----START-----");
		ispisListe(indeksi);
		System.out.println("-----------------");
		ispisListe(this.polaznici);
		System.out.println("------END------");

		//prolazimo kroz pomoćnu listu indeksa
		for (int i = 0; i < indeksi.size(); i++){
			ispisListe(this.polaznici);
			System.out.println("Briše se element na originalnoj poziciji: " + indeksi.get(i));
			System.out.println("Zbog pomeranja liste nova pozicija tog elementa je: " + (indeksi.get(i) - i));
			
			//brišemo elemente iz originalne liste tako što prosleđujemo originalni indeks
			//na kojem se element nalazio u originalnoj listi na po�?etku umanjen za broj pozivanja metode remove
			//koja smanjuje indeks(poziciju) elemenata za 1 pri svakom pozivu
			this.polaznici.remove(indeksi.get(i) - i);
			ispisListe(this.polaznici);
			System.out.println("------------------------");
		}

		return true;
	}

	public void ispisListe(ArrayList<?> lista) {
		for(int i = 0; i < lista.size(); i++) {
			System.out.println("Index: " + i + " Element: " + lista.get(i));
		}
	}

	public boolean izmeniPolaznika(String stariPolaznik, String noviPolaznik) {

		for(int i = 0; i < this.polaznici.size(); i++) {
			if(this.polaznici.get(i).equals(stariPolaznik)) {
				this.polaznici.set(i, noviPolaznik);
				return true;
			}
		}

		return false;
	}

	public void ispisiUkupanBrojPolaznika() {
		System.out.println("Ukupan broj polaznika je: " + this.polaznici.size());
	}

	public String pretragaPoPunomImenuIPrezimenu(String imeIPrezime) {

		for(int i = 0; i < this.polaznici.size(); i++) {
			if(this.polaznici.get(i).equals(imeIPrezime)) {
				return this.polaznici.get(i);
			}
		}
		return null;
	}

	public ArrayList<String> pretragaPoImenu(String ime) {

		ArrayList<String> lista = new ArrayList<String>();
		for(int i = 0; i < this.polaznici.size(); i++) {
			String[] temp = this.polaznici.get(i).split(" ");
			if(temp[0].equals(ime)) {
				lista.add(this.polaznici.get(i));
			}
		}

		return lista;
	}

	@Override
	public String toString() {
		return "Kurs [sifraKursa=" + this.sifraKursa + ", nazivKursa=" + this.nazivKursa
				+ ", cenaPoPolazniku=" + this.cenaPoPolazniku + ", ukupnaCena="
				+ getUkupnaCena() + "]";
	}




}
