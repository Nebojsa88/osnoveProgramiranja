package com.ftninformatika.kolekcije;

import java.util.ArrayList;
import java.util.Collections;

public class Kolekcije {

	public static void main(String[] args) {
		
		ArrayList<Integer> listaBrojeva = new ArrayList<Integer>();
		listaBrojeva.add(5);
		listaBrojeva.add(2);
		listaBrojeva.add(11);
		listaBrojeva.add(3);
		listaBrojeva.add(1);
		listaBrojeva.add(16);
		listaBrojeva.add(22);
		listaBrojeva.add(19);
		listaBrojeva.add(6);
		
		//metoda sort vrši sortiranje listeBrojeva
		Collections.sort(listaBrojeva);
		//metoda max vraća najveći element u listi
		System.out.println("Najveći broj u listi je: " + Collections.max(listaBrojeva));
		//metoda min vraća najmanji element u listi
		System.out.println("Najmanji broj u listi je: " + Collections.min(listaBrojeva));
		//metoda binarySearch vraća indeks prosleđenog elementa u prosleđenoj listi
		//metoda zahteva da elementi budu sortirani u rastućem redosledu
		//ako prosleđeni element za koji se traži pozicija ne postoji, vraća se negativan broj kao indeks
		System.out.println("Indeks elementa 11 u listi : " + Collections.binarySearch(listaBrojeva, 11));
		Collections.reverse(listaBrojeva);
		
		for(Integer i : listaBrojeva) {
			System.out.println(i);
		}


	}

}
