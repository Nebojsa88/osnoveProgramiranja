package com.ftninformatika.sud;

public class Predmet {
	
	private int brojPredmeta;
	private String imePredmeta;
	private String tekstPredmeta;
	
	public Predmet() {

	}

	public Predmet(int brojPredmeta, String imePredmeta, String tekstPredmeta) {
		this.brojPredmeta = brojPredmeta;
		this.imePredmeta = imePredmeta;
		this.tekstPredmeta = tekstPredmeta;
	}

	public int getBrojPredmeta() {
		return brojPredmeta;
	}

	public void setBrojPredmeta(int brojPredmeta) {
		this.brojPredmeta = brojPredmeta;
	}

	public String getImePredmeta() {
		return imePredmeta;
	}

	public void setImePredmeta(String imePredmeta) {
		this.imePredmeta = imePredmeta;
	}

	public String getTekstPredmeta() {
		return tekstPredmeta;
	}

	public void setTekstPredmeta(String tekstPredmeta) {
		this.tekstPredmeta = tekstPredmeta;
	}

	@Override
	public String toString() {
		return this.brojPredmeta + ";" + this.imePredmeta + ";" + this.tekstPredmeta;
	}

}
