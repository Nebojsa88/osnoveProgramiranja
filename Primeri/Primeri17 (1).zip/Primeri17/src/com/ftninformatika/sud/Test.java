package com.ftninformatika.sud;

public class Test {

	public static void main(String[] args) {
		
		Evidencija evidencija = new Evidencija("Prvi osnovni", "22.5.2015.");
		Predmet predmet1 = new Predmet(1, "Prvi predmet", "Neki tekst prvog predmeta");
		Predmet predmet2 = new Predmet(2, "Drugi predmet", "Neki tekst drugog predmeta");
		Predmet predmet3 = new Predmet(3, "Drugi predmet", "Neki tekst treceg predmeta");
		Predmet predmet4 = new Predmet(4, "Treci predmet", "Neki tekst treceg predmeta");
		Predmet predmet5 = new Predmet(5, "Cetvrti predmet", "Neki tekst treceg predmeta");
		Predmet predmet6 = new Predmet(6, "Drugi predmet", "Neki tekst treceg predmeta");
		evidencija.dodajPredmet(predmet1);
		evidencija.dodajPredmet(predmet2);
		evidencija.dodajPredmet(predmet3);
		evidencija.dodajPredmet(predmet4);
		evidencija.dodajPredmet(predmet5);
		evidencija.dodajPredmet(predmet6);
		System.out.println(evidencija);
		System.out.println();
		evidencija.izbrisiSvePredmete4("Drugi predmet");
		System.out.println(evidencija);

	}

}
