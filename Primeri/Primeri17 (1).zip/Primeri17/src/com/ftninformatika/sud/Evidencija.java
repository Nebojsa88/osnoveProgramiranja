package com.ftninformatika.sud;

import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.Iterator;

public class Evidencija {

	private String nazivSuda;
	private String datum;
	private ArrayList<Predmet> listaPredmeta;

	public Evidencija() {
		this.listaPredmeta = new ArrayList<Predmet>();
	}

	public Evidencija(String nazivSuda, String datum) {
		this.nazivSuda = nazivSuda;
		this.datum = datum;
		this.listaPredmeta = new ArrayList<Predmet>();
	}

	public String getNazivSuda() {
		return nazivSuda;
	}

	public void setNazivSuda(String nazivSuda) {
		this.nazivSuda = nazivSuda;
	}

	public String getDatum() {
		return datum;
	}

	public void setDatum(String datum) {
		this.datum = datum;
	}

	public ArrayList<Predmet> getListaPredmeta() {
		return listaPredmeta;
	}

	public void setListaPredmeta(ArrayList<Predmet> listaPredmeta) {
		this.listaPredmeta = listaPredmeta;
	}

	public boolean dodajPredmet(Predmet predmet) {

		for(int i = 0; i < this.listaPredmeta.size(); i++) {
			Predmet tempPredmet = this.listaPredmeta.get(i);
			if(tempPredmet.getBrojPredmeta() == predmet.getBrojPredmeta()) {
				return false;
			}
		}
		this.listaPredmeta.add(predmet);
		return true;
	}

	public void ispisNaOsnovuBroja(int brojPredmeta) {

		for(int i = 0; i < this.listaPredmeta.size(); i++) {
			Predmet tempPredmet = this.listaPredmeta.get(i);
			if(tempPredmet.getBrojPredmeta() == brojPredmeta) {
				System.out.println(tempPredmet);
			}
		}
	}

	public ArrayList<Predmet> ispisNaOsnovuImena(String imePredmeta) {

		ArrayList<Predmet> lista = new ArrayList<Predmet>();
		for(int i = 0; i < this.listaPredmeta.size(); i++) {
			Predmet tempPredmet = this.listaPredmeta.get(i);
			if(tempPredmet.getImePredmeta().equals(imePredmeta)) {
				lista.add(tempPredmet);
				System.out.println(tempPredmet);
			}
		}

		return lista;
	}

	public String dodajTekst(int brojPredmeta, String noviTekst) {

		for(int i = 0; i < this.listaPredmeta.size(); i++){
			if(this.listaPredmeta.get(i).getBrojPredmeta() == brojPredmeta) {
				Predmet temp = this.listaPredmeta.get(i);
				String stariTekst = temp.getTekstPredmeta();
				stariTekst += " " + noviTekst;
				this.listaPredmeta.get(i).setTekstPredmeta(stariTekst);
				return stariTekst;
			}
		}

		return null;
	}

	public void sacuvajPredmete(String path) {

		ArrayList<String> lines = new ArrayList<String>();

		for (int i = 0; i < this.listaPredmeta.size(); i++) {
			Predmet predmet = this.listaPredmeta.get(i);
			String line = predmet.getBrojPredmeta() + ";" + predmet.getImePredmeta() + ";" + predmet.getTekstPredmeta();
			lines.add(line);
		}

		try {
			Files.write(Paths.get(path), lines, Charset.defaultCharset(), StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING, StandardOpenOption.WRITE); 
		} catch (IOException e) {
			System.out.println("File " + path + " not found.");
		}
	}

	public void ucitajPredmete(String path) {

		ArrayList<String> lines;
		this.listaPredmeta.clear();
		try {
			lines = (ArrayList<String>) Files.readAllLines(Paths.get(path), Charset.defaultCharset());

			for (String line: lines) {
				String[] attributes = line.split(";");
				int brojPredmeta = Integer.valueOf(attributes[0]);
				String imePredmeta = attributes[1];
				String tekstPredmeta = attributes[2];
				Predmet predmetZaDodavanje = new Predmet(brojPredmeta, imePredmeta, tekstPredmeta);
				this.listaPredmeta.add(predmetZaDodavanje);
			}
		} catch (java.io.IOException e) {
			System.out.println("File " + path + " not found.");
		}
	}
	
	public void izbrisiSvePredmete0(String naziv) {

		for(int i = this.listaPredmeta.size()-1; i >= 0; i--) {
			if(this.listaPredmeta.get(i).getImePredmeta().equals(naziv)) {
				this.listaPredmeta.remove(i);
			}
		}
	}

	//Brisanje predmeta po nazivu
	//POD USLOVOM DA NE POSTOJE DVA PREDMETA SA ISTIM NAZIVOM
	public Predmet izbrisiPredmetPoNazivu(String naziv) {

		int indeks = -1;
		for(int i = 0; i < this.listaPredmeta.size(); i++) {
			if(this.listaPredmeta.get(i).getImePredmeta().equals(naziv)) {
				indeks = i;
			}
		}
		if(indeks != -1) {
			return this.listaPredmeta.remove(indeks);
		}
		return null;
	}
	
	//Pomoćna metoda koja samo vraća TRUE ako lista sadrži predmet
	//a vraća FALSE ako ne sadrži
	private boolean daLiListaSadrziPredmet(String naziv) {
		
		int indeks = -1;
		for(int i = 0; i < this.listaPredmeta.size(); i++) {
			if(this.listaPredmeta.get(i).getImePredmeta().equals(naziv)) {
				indeks = i;
			}
		}
		if(indeks != -1) {
			return true;
		}
		return false;
	}
	
	//Primer brisanja predmeta iz liste korišćenjem dodatnih metoda
	public boolean izbrisiSvePredmete1(String naziv) {

		//dokle god lista sadrži predmete sa prosleđenim imenom (u while pozivamo metodu daLiListaSadrziPredmet)
		//pozivaj metodu izbrisiPredmetPoNazivu koja će jedan po jedan da briše i skraćuje listu
		while(daLiListaSadrziPredmet(naziv)) {
			izbrisiPredmetPoNazivu(naziv);
		}

		return true;
	}
	
	
	public boolean izbrisiSvePredmete2(String naziv) {

		//inicijalizuje se iterator za listu predmeta
		Iterator<Predmet> it = this.listaPredmeta.iterator();
		//prolazi se kroz listu pomoću iteratora sve dok ima elemenata
		while(it.hasNext()) {
			//sa metodom next() se preuzima element po element iz liste  pomoću iteratora
			//i pita se da li je ime tog elementa jednako sa prosleđenim nazivom
			if(it.next().getImePredmeta().equals(naziv)) {
				//ako je jednako, koristi se remove() metoda koja se poziva 
				//nad iteratorom i briše se elemet iz liste
				it.remove();
			}
		}

		return true;
	}
	
	public boolean izbrisiSvePredmete3(String naziv) {

		//Kreiramo pomoćnu listu u koju dodajemo sve predmete sa prosleđenim imenom
		ArrayList<Predmet> predmetiZaBrisanje = new ArrayList<Predmet>();
		for(int i = 0; i < this.listaPredmeta.size(); i++) {
			if(this.listaPredmeta.get(i).getImePredmeta().equals(naziv)) {
				predmetiZaBrisanje.add(this.listaPredmeta.get(i));
			}
		}
		//koristimo metodu removeAll nad originalnom listom i prosleđujemo pomoćnu listu
		//koja sadrži sve elemente koji treba da se obrišu iz originalne liste
		this.listaPredmeta.removeAll(predmetiZaBrisanje);

		return true;
	}
	
	public boolean izbrisiSvePredmete4(String naziv) {

		//pravimo pomoćnu listu koja će sadržati pozicije elemenata koji se brišu
		ArrayList<Integer> indeksi = new ArrayList<Integer>();
		for(int i = 0; i < this.listaPredmeta.size(); i++) {
			if(this.listaPredmeta.get(i).getImePredmeta().equals(naziv)) {
				indeksi.add(i);
			}
		}

		System.out.println("-----START-----");
		ispisListe(indeksi);
		System.out.println("-----------------");
		ispisListe(this.listaPredmeta);
		System.out.println("------END------");

		//prolazimo kroz pomoćnu listu indeksa
		for (int i = 0; i < indeksi.size(); i++){
			ispisListe(this.listaPredmeta);
			System.out.println("Briše se element na originalnoj poziciji: " + indeksi.get(i));
			System.out.println("Zbog pomeranja liste nova pozicija tog elementa je: " + (indeksi.get(i) - i));
			
			//brišemo elemente iz originalne liste tako što prosleđujemo originalni indeks
			//na kojem se element nalazio u originalnoj listi na početku umanjen za broj pozivanja metode remove
			//koja smanjuje indeks(poziciju) elemenata za 1 pri svakom pozivu
			this.listaPredmeta.remove(indeksi.get(i) - i);
			ispisListe(this.listaPredmeta);
			System.out.println("------------------------");
		}

		return true;
	}
	
	public void ispisListe(ArrayList<?> lista) {
		for(int i = 0; i < lista.size(); i++) {
			System.out.println("Index: " + i + " Element: " + lista.get(i));
		}
	}
	
	public String toString() {
		
		StringBuilder sb = new StringBuilder();
		sb.append("Naziv suda: " + this.nazivSuda + "\n");
		sb.append("Datum: " + this.datum + "\n");
		for(int i = 0; i < this.listaPredmeta.size(); i++)
			sb.append(this.listaPredmeta.get(i));
		return sb.toString().trim();
	}

}
