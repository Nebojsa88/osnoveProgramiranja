package com.ftninformatika.keyword_static;

public class Test {
	
	static String nekiString = "Neki string";

	public static void main(String[] args) {

		System.out.println(nekiString);
		System.out.println("Ukupan broj kreiranih osoba je: " + Osoba.getBrojOsoba());
		Osoba pera = new Osoba("Pera", "Peric");
		System.out.println(pera);
		Osoba sima = new Osoba("Sima", "Simic");
		System.out.println(sima);
		System.out.println(pera);
		System.out.println("Ukupan broj kreiranih osoba je: " + Osoba.getBrojOsoba());

	}

}
