package com.ftninformatika.keyword_static;

public class Osoba {
	
	public static int brojOsoba = 0;
	private String ime;
	private String prezime;
	private int id;
	
	public Osoba(String ime, String prezime) {
		
		this.ime = ime;
		this.prezime = prezime;
		brojOsoba++;
		this.id = brojOsoba;
	}


	public static int getBrojOsoba() {
		return brojOsoba;
	}
	
	

	public String getIme() {
		return ime;
	}

	public static void setBrojOsoba(int brojOsoba) {
		Osoba.brojOsoba = brojOsoba;
	}


	public void setIme(String ime) {
		this.ime = ime;
	}

	public String getPrezime() {
		return prezime;
	}

	public void setPrezime(String prezime) {
		this.prezime = prezime;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	@Override
	public String toString() {
		return "Osoba [ime=" + this.ime + ", prezime=" + this.prezime + ", id=" + this.id + "]";
	}
	

}
