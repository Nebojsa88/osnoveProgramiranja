package com.ftninformatika.argumenti;

public class Argumenti {

	public static void main(String[] args) {

		if(args[0] != null) {
			System.out.println("Prvi prosleđeni argument je: " + args[0]);
		}
		
		if(args[1] != null) {
			System.out.println("Drugi prosleđeni argument je: " + args[1]);
		}

	}

}
