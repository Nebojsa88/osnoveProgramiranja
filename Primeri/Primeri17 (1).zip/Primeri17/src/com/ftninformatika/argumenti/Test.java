package com.ftninformatika.argumenti;

public class Test {

	public static void main(String[] args) {
		
		String[] args2 = new String[2];
		args2[0] = "Prvi argument";
		args2[1] = "Drugi argument";
		Argumenti.main(args2);

	}

}
