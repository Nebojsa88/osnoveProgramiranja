package com.ftninformatika.keyword_final;

public class Test {

	public static void main(String[] args) {
		
		Student student = new Student("Pera", 9.52);
		System.out.println(student);

	}

}
