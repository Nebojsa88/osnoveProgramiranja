package com.ftninformatika.keyword_final;

public class Student {

	private String ime;
	private final double prosek = 2.2;
	private final String FAKULTET = "FTN";
	private final String url = "www.google.com/";

	public Student(String ime, double prosek) {
		
		this.ime = ime;
		//this.prosek = prosek;
		//FAKULTET = "PMF"; // ne može se menjati vrednost atributa koji je final
	}

	public final String getIme() {
		return ime;
	}

	public void setIme(String ime) {
		this.ime = ime;
	}

	public double getProsek() {
		return prosek;
	}
	
	public String getFAKULTET() {
		return FAKULTET;
	}

	public String getUrl() {
		return url + "home.html";
	}
	

	@Override
	public String toString() {
		return "Student [ime=" + this.ime + ", prosek=" + this.prosek + ", FAKULTET="
				+ FAKULTET + "]";
	}


}
