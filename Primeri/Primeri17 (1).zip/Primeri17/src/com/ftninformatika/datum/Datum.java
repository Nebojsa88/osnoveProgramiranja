package com.ftninformatika.datum;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class Datum {
	
	public static boolean proveriDatum(String datum) {
		
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd.MM.yyyy.");
		try {
			//potrebno je metodi parse proslediti string u formatu
			//koji je naveden u šablonu za DateTimeFormatter tj. dd.MM.yyyy.
			//ako se ne navede string u odgovarajućem formatu,
			//kada se pokrene program izbaciće grešku
			LocalDate.parse(datum, dtf);
			return true;
		} catch (Exception e) {
			return false;
		}
	}

	public static void main(String[] args) {
		
		LocalDate datumTrenutni = LocalDate.now();
		System.out.println(datumTrenutni);
		
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd.MM.yyyy.");
		//Konverzija datuma u string
		String formatiraniDatum = dtf.format(datumTrenutni); 
		System.out.println(formatiraniDatum);
		String datumUStringFormatu = "14.04.2016.";
		//Konverzija stringa u datum
		LocalDate datumProizvoljni = null;
			//potrebno je metodi parse proslediti string u formatu
			//koji je naveden u šablonu za DateTimeFormatter tj. dd.MM.yyyy.
			//ako se ne navede string u odgovarajućem formatu,
			//kada se pokrene program izbaciće grešku
			//String datumUStringFormatu = "14.04.2016.";
			try {
				datumProizvoljni = LocalDate.parse(datumUStringFormatu, dtf);
			} catch (Exception e) {
				System.out.println("Format nije dobar.");
			}
			
		
		if(datumTrenutni.compareTo(datumProizvoljni) < 0) {
			System.out.println("Datum: " + datumTrenutni + " je manji od datuma: " + datumProizvoljni);
		} else if (datumTrenutni.compareTo(datumProizvoljni) > 0) {
			System.out.println("Datum: " + datumTrenutni + " je veći od datuma: " + datumProizvoljni);
		} else {
			System.out.println("Datum: " + datumTrenutni + " je jednak sa datumom: " + datumProizvoljni);
		}
		
	}

}
