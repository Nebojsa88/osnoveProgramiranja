package primeri12;

import java.util.ArrayList;

public class ParamsLista {

	public static void f(ArrayList<Integer> list1) {
		list1.add(4);
		list1.add(4);
	}
	
	public static void main(String[] args) {
		ArrayList<Integer> list = new ArrayList<Integer>();
		list.add(3);
		list.add(7);
		list.add(5);
		list.add(1);
		list.add(9);
		f(list);
		System.out.println("Ispis liste:");
		for (Integer el:list) {
			System.out.println(el);
		}

	}

}
