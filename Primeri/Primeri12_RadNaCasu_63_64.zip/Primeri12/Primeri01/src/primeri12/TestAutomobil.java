package primeri12;

public class TestAutomobil {

	public static void main(String[] args) {
		
		Automobil auto1 = new Automobil();
		Automobil auto2 = new Automobil(); // objekat auto2 smo instancirali ali ga ne koristimo, pa Eclipse pokazuje upozorenje
		
		/**
		 * Pokušaćemo da ispišemo na konzolu informacije koje sadrži objekat auto1.
		 * To je moguće uraditi za oba objekta iako auto1 nema eksplicitno definisane vrednosti za svoje atribute.
		 */
		System.out.println(auto1.brojTablica);  // biće ispisano null što je podrazumevana vrednost za tip String
		System.out.println(auto1.brzina);		// biće ispisan broj 0 što je podrazumevana vrednost za tip int
		
		//TODO Zadatak: Instancirati novi objekat klase Automobil i dodeliti proizvoljne vrednosti za brojTablica i brzinu.
		//			  Ispisati podatke o novom objektu na konzolu.
		
		
	}

}
