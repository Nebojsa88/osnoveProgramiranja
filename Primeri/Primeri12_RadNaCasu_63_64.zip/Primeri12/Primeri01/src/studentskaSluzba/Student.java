package studentskaSluzba;
/**
 * 
 * @author Bojana/Milan
 * Klasa Student modeluje studenta.
 */
public class Student {
	
	//TODO: Zadatak: Dodati atribut prezime.
	String ime;
	double prosek;
	int sumaOcena;
	int brojOcena;
	boolean diplomirao;
	
	/**
	 * Konstruktor bez parametara.
	 * Postiže se isti efekat kao i kad nema konstruktora, ali čak se može dodati još funkcionalnosti.
	 * Inicijalizovali smo ime na prazan string.
	 */
	public Student() {	
		ime = "";
	}
	
	/**
	 * Konstruktor sa parametrima. Može imati jedan ili više parametara.
	 * Prilikom instanciranja objekta  potrebno je proslediti onoliko vrednosti koliko to konstruktor
	 * zahteva (u našem slučaju 3).
	 * @param novoIme
	 * @param novaSumaOcena
	 * @param noviBrojOcena
	 */
	public Student(String novoIme, int novaSumaOcena, int noviBrojOcena) {
		ime = novoIme;
		sumaOcena = novaSumaOcena;
		brojOcena = noviBrojOcena;
		izracunajProsek();
	}
	  
	/**
	 * Neispravan konstruktor sa parametrima koji se može "namestiti da radi" pomoću ključne reči <b>this</b>
	 */
	/*
	public Student(String ime, int sumaOcena, int brojOcena) {
		ime = ime;
		sumaOcena = sumaOcena;
		brojOcena = brojOcena;
	}
	*/

	/**
	 * Metoda ispisiProsek ispisuje prosek studenta u toku studija.
	 */
	void ispisiProsek() {
		System.out.println("Prosek studenta " + ime + " je " + prosek + ".");
	}
	
	/**
	 * Metoda izracunajProsek računa novi prosek na osnovu sume ocena i broja ocena.
	 */
	void izracunajProsek() {
		prosek = (double)sumaOcena/brojOcena;
		System.out.println("Novi prosek je " + prosek);
	}
	
	/**
	 * Metoda diplomiraj postavlja vrednost atributa 'diplomirao' na true i ispisuje na konzolu obeveštenje da je student diplomirao.
	 * Nakon poziva ove metode nije više moguće dodavati nove ocene za studenta.
	 */
	void dipomiraj() {
		diplomirao = true;
		System.out.println("Student " + ime + " je diplomirao.");
	}
	
	/**
	 * Ukoliko student nije diplomirao, metoda dodajOcenu dodaje unetu ocenu i na računa novi procek.
	 * U suprotnom, metoda na konzolu ispisuje obaveštenje o tome da nije moguće dodati novu ocenu za studenta.
	 * @param novaOcena 
	 * @return novi prosek
	 */
	double dodajOcenu(int novaOcena) {
		if(!diplomirao) {
			sumaOcena += novaOcena;
			brojOcena++;
			izracunajProsek();
		} else {
			System.out.println("Student " + ime + " je diplomirao i više nije moguće dodati novu ocenu za njega.");
		}

		return prosek;
	}
	
	/**
	 * Metoda izbrisiOcenu uklanja zadatu ocenu
	 * @param ocena
	 * @return novi prosek
	 */
	double izbrisiOcenu(int ocena) {
		/*
		 * TODO: Implementirati metodu izbrisiOcenu(int ocena) koja ispisuje novi prosek
		 *  posle uklanjanja ocene
		 */
		return prosek;
	}

}
