package radNaCasu_63_64;

//prosiriti clanskim brojem
public class Clan {
	String ime;
	String prezime;
	int clBroj;
	
	Clan(String ime, String prezime) {
		this.ime = ime;
		this.prezime = prezime;
	}
	
	Clan(){
		ime = "";
		prezime = "";
	}
	
	Clan(String ime, String prezime, int clBroj) {
		this.ime = ime;
		this.prezime = prezime;
		this.clBroj = clBroj;
	}
	
	void predstaviSe() {
		System.out.println(ime + " " + prezime + " " + clBroj);
	}
	
}
