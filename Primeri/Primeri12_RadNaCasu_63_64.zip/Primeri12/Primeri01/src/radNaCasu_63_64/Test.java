package radNaCasu_63_64;

public class Test {

	public static void main(String[] args) {
		Clan pera = new Clan("Pera", "Peric", 58);
//		pera.ime = "Pera";
//		pera.prezime = "Peric";
		
		Clan marko = new Clan();
		
//		System.out.println(pera.ime + " " + pera.prezime);
//		System.out.println(marko.ime + " " + marko.prezime);
		
		pera.predstaviSe();
		marko.predstaviSe();
		
		Clan sima = pera;
		sima.ime = "Sima";
		
		sima.predstaviSe();
		pera.predstaviSe();
	}

}
