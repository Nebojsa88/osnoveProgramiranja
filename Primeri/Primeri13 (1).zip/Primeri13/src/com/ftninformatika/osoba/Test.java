package com.ftninformatika.osoba;

public class Test {

	public static void main(String[] args) {
		
		Osoba pera = new Osoba("Pera", false);
		System.out.println(pera.isVozac());
		pera.poloziZaKola(pera);
		System.out.println(pera.isVozac());
		
		int a = 0;
		pera.test(a);
		System.out.println(a);

	}

}
