package com.ftninformatika.osoba;

public class Osoba {
	
	private String ime;
	private boolean vozac;
	
	public Osoba() {
		
	}

	public Osoba(String ime, boolean vozac) {
		this.ime = ime;
		this.vozac = vozac;
	}

	public String getIme() {
		return ime;
	}

	public void setIme(String ime) {
		this.ime = ime;
	}

	public boolean isVozac() {
		return vozac;
	}

	public void setVozac(boolean vozac) {
		this.vozac = vozac;
	}
	
	// slozen tip - prenos parametara isto po vrednosti
	// (u drugim programskim jezicima je ovo prenos po adresi)
	public void poloziZaKola(Osoba a) {
		a.vozac = true;
	}
	
	// prost tip - prenos parametara po vrednosti
	public void test(int a) {
		a = 1;
	}

	public String toString() {
		return "Osoba [ime=" + this.ime + "]" ;
	}
	
}
