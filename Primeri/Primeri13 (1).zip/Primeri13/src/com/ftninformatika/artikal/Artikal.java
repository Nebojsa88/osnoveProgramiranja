package com.ftninformatika.artikal;

public class Artikal {

	private String naziv;
	private double osnovnaCena;
	private double porez;

	public Artikal() {	

	}

	public Artikal(String naziv, double osnovnaCena, double porez) {
		this.naziv = naziv;
		this.osnovnaCena = osnovnaCena;
		this.porez = porez;
	}
	
	/**
	 * Getter za atribut naziv. Getter ima modifikator <b>public</b>, ima povratnu vrednost, 
	 * naziv počinje sa <b>get</b> i metoda nema parametre.
	 * @return
	 */
	public String getNaziv() {
		return naziv;
	}

	/**
	 * Setter za atribut naziv. Setter ima modifikator <b>public</b>, nema povratnu vrednost (void),
	 * naziv počinje sa <b>set</b> i metoda obično ima jedan parametar koji je tipa atributa kojem se vrednost dodeljuje.
	 * @param naziv
	 */
	public void setNaziv(String naziv) {
		this.naziv = naziv;
	}

	public double getOsnovnaCena() {
		return osnovnaCena;
	}

	public void setOsnovnaCena(double osnovnaCena) {
		this.osnovnaCena = osnovnaCena;
	}

	public double getPorez() {
		return porez;
	}

	public void setPorez(double porez) {
		this.porez = porez;
	}
	
	//method overload
	public void setPorez(double porez, double dodatniPorez) {
		this.porez = porez + dodatniPorez;
	}

	double izracunajKonacnuCenu() {
		
		double konacnaCena = this.osnovnaCena + this.osnovnaCena * this.porez;
		return konacnaCena;
	}
	
	double izracunajCenuSaPopustom(double popust) {
		
		double novaCena = 0;
		novaCena = izracunajKonacnuCenu() - izracunajKonacnuCenu()*popust;
		return novaCena;
	}

	@Override
	public String toString() {
		return "Artikal [naziv = " + this.naziv + ", osnovnaCena = " + this.osnovnaCena + "]";
	}
	
	


}
