package com.ftninformatika.artikal;

public class Test {

	public static void main(String[] args) {
		
		Artikal artikal1 = new Artikal("Jastuk", 1800.00, 0.2);
		
		// Program ima grešku
		/*
		System.out.println("Konačna cena za artikal: " + artikal1.naziv + " je " + artikal1.izracunajKonacnuCenu());
		System.out.println("Cena sa popustom za artikal: " + artikal1.naziv + " je " + artikal1.izracunajCenuSaPopustom(0.2));
		*/
		System.out.println("Konačna cena za artikal: " + artikal1.getNaziv() + " je " + artikal1.izracunajKonacnuCenu());
		System.out.println("Cena sa popustom za artikal: " + artikal1.getNaziv() + " je " + artikal1.izracunajCenuSaPopustom(0.2));
		
		// Program ima grešku
		//artikal1.naziv = "Ćebe";		
		artikal1.setNaziv("Ćebe");
		System.out.println(artikal1.getNaziv());
		//Prikaz toString
		System.out.println(artikal1);

	}

}
