package com.ftninformatika.evidencija;

import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.List;

public class Evidencija {

	private String nazivSuda;
	private String adresaSuda;
	private ArrayList<Predmet> predmeti;

	public Evidencija() {

		this.predmeti = new ArrayList<>();
	}

	public Evidencija(String nazivSuda, String adresaSuda) {

		this.nazivSuda = nazivSuda;
		this.adresaSuda = adresaSuda;
		this.predmeti = new ArrayList<>();
	}

	public String getNazivSuda() {
		return nazivSuda;
	}

	public void setNazivSuda(String nazivSuda) {
		this.nazivSuda = nazivSuda;
	}

	public ArrayList<Predmet> getPredmeti() {
		return predmeti;
	}

	public void setPredmeti(ArrayList<Predmet> predmeti) {
		this.predmeti = predmeti;
	}
	

	public String getAdresaSuda() {
		return adresaSuda;
	}

	public void setAdresaSuda(String adresaSuda) {
		this.adresaSuda = adresaSuda;
	}

	public boolean dodajPredmet(Predmet predmetZaDodavanje) {

		for(int i = 0; i < this.predmeti.size(); i++) {
			if(predmetZaDodavanje.getBroj() == this.predmeti.get(i).getBroj()) {
				return false;
			}
		}
		this.predmeti.add(predmetZaDodavanje);
		return true;
	}

	public void ispisNaOsnovuBroja(int brojPredmeta) {

		for(int i = 0; i < this.predmeti.size(); i++) {
			if(this.predmeti.get(i).getBroj() == brojPredmeta) {
				System.out.println(this.predmeti.get(i));
			}
		}
	}

	public void ispisNaOsnovuImena(String imePredmeta) {

		for(int i = 0; i < this.predmeti.size(); i++) {
			if(this.predmeti.get(i).getIme().equals(imePredmeta)) {
				System.out.println(this.predmeti.get(i));
			}
		}
	}
	
	public String dodajTekst(String noviTekst, int brojPredmeta) {
		
		for(int i = 0; i < this.predmeti.size(); i++) {
			if(this.predmeti.get(i).getBroj() == brojPredmeta) {
				String tekstZaDodavanje = this.predmeti.get(i).getTekst() + " " + noviTekst;
				this.predmeti.get(i).setTekst(tekstZaDodavanje);
				return tekstZaDodavanje;
			}
		}
		return null;
	}
	
	public void ispisPredmetaUOpseguDatuma(LocalDate min, LocalDate max) {
		
		for(int i = 0; i < this.predmeti.size(); i++) {
			if(this.predmeti.get(i).getDatum().compareTo(min) >= 0 &&
					this.predmeti.get(i).getDatum().compareTo(max) <= 0) {
				System.out.println(this.predmeti.get(i));
			}
		}
	}
	
	public void save(String path) {
		
		ArrayList<String> lines = new ArrayList<String>();
		
		//////////////////////////////////
		//BONUS
		String line1 = this.nazivSuda;
		String line2 = this.adresaSuda;
		
		lines.add(line1);
		lines.add(line2);
		//BONUS
		////////////////////////////////
		
		for (int i = 0; i < this.predmeti.size(); i++) {
			Predmet temp = this.predmeti.get(i);
			String line3 = temp.getBroj() + ";" + temp.getIme() + ";" + temp.getTekst() + ";" + temp.getDatum().format(DateTimeFormatter.ofPattern("dd.MM.yyyy."));
			lines.add(line3);
		}
		
		try {
			Files.write(Paths.get(path), lines, Charset.defaultCharset(), StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING, StandardOpenOption.WRITE); 
		} catch (IOException e) {
			System.out.println("File " + path + " not found.");
		}
	}
	
	public void load(String path) {

		this.predmeti.clear();
		List<String> lines;
		try {
			lines = Files.readAllLines(Paths.get(path), Charset.defaultCharset());
			
			////////////////////////////////////
			//BONUS
			//setNazivSuda(lines.get(0));
			//setAdresaSuda(lines.get(1));
			this.nazivSuda = lines.get(0);
			this.adresaSuda = lines.get(1);
			
			lines.remove(0);
			lines.remove(0);
			//BONUS
			///////////////////////////////////
			
			for (String line: lines) {
				String[] attributes = line.split(";");
				
				int brojPredmeta = Integer.parseInt(attributes[0]); 
				String nazivPredmeta = attributes[1];
				String tekstPredmeta = attributes[2];
				String datumString = attributes[3];
				LocalDate datum = null;
				try {
					datum = LocalDate.parse(datumString, DateTimeFormatter.ofPattern("dd.MM.yyyy."));
				} catch (DateTimeParseException e) {
					System.out.println("Desila se greska pri konverziji stringa u datum.");
				}
	
				Predmet predmet = new Predmet(brojPredmeta, nazivPredmeta, tekstPredmeta, datum);
				
				dodajPredmet(predmet);
			}
		} catch (IOException e) {
			System.out.println("File " + path + " not found.");
		}
	}

	public String toString() {

		String temp = "";
		temp += "Naziv suda: " + this.nazivSuda + "\n";
		temp += "Adresa suda: " + this.adresaSuda + "\n";
		temp += "Spisak predmeta:\n";
		for(int i = 0; i < this.predmeti.size(); i++) {
			temp += this.predmeti.get(i) + "\n";
		}

		return temp.trim();
	}


}
