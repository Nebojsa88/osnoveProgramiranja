package com.ftninformatika.evidencija;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class Predmet {
	
	private int broj;
	private String ime;
	private String tekst;
	private LocalDate datum;
	
	public Predmet() {
		
	}

	public Predmet(int broj, String ime, String tekst, LocalDate datum) {
		this.broj = broj;
		this.ime = ime;
		this.tekst = tekst;
		this.datum = datum;
	}

	public int getBroj() {
		return broj;
	}

	public void setBroj(int broj) {
		this.broj = broj;
	}

	public String getIme() {
		return ime;
	}

	public void setIme(String ime) {
		this.ime = ime;
	}

	public String getTekst() {
		return tekst;
	}

	public void setTekst(String tekst) {
		this.tekst = tekst;
	}

	public LocalDate getDatum() {
		return datum;
	}

	public void setDatum(LocalDate datum) {
		this.datum = datum;
	}

	@Override
	public String toString() {
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd.MM.yyyy.");
		return "Predmet [broj=" + this.broj + ", ime=" + this.ime + ", tekst=" + this.tekst + ", datum=" + dtf.format(this.datum) + "]";
	}

}
