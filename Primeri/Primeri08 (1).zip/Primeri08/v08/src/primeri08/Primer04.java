package primeri08;

public class Primer04 {
	
	/**
	 * Funkcija vraća invertovani tekst
	 * 
	 * @param s Početni tekst
	 * @return Invertovan tekst
	 */
	public static String inverse(String s) {
		// Inicijalizuj akumulator
		String retVal = "";
		
		// Prođi kroz string od kraja do početka
		for (int i = s.length() - 1; i >= 0; i--) {
			// Dodaj u akumulator tekući znak
			retVal += s.charAt(i);
		}
		
		return retVal;
	}
	
	public static void main(String[] args) {
		String s = "Hello World!";
		System.out.println(inverse(s));
	}
}
