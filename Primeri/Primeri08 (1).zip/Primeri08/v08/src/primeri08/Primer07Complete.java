package primeri08;

import java.util.Scanner;

public class Primer07Complete {
	
	/**
	 * Funkcija vraća vrednost aritmetičke operacije
	 * 
	 * @param op1 Prvi operand
	 * @param op2 Drugi operand
	 * @param op Operacija
	 * @return Rezultat
	 * @exception Operacija nije podržana
	 */
	public static double calculator(double op1, double op2, String op) throws Exception {
		// U zavisnosti od izabrane operaciju vrati vrednost
		// odgovarajućeg izraza
		switch (op) {
		case "+":
			return op1 + op2;
		case "-":
			return op1 - op2;
		case "*":
			return op1 * op2;
		case "/":
			if (op2 == 0) {
				throw new Exception("Division by zero!");
			}
			return op1 / op2;
		default:
			// Bazi izuzetak ako operacija nije podržana
			throw new Exception ("Operation " + op + " not supported!");
		}
	}
	
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		
		System.out.print("Enter first operand: ");
		double op1 = 0;
		try {
			op1 = Double.parseDouble(scanner.nextLine());
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		System.out.print("Enter second operand: ");
		double op2 = Double.parseDouble(scanner.nextLine());

		
		System.out.print("Enter operation: ");
		String op = scanner.nextLine();
		
		scanner.close();
		try {
			System.out.println("Result: " + calculator(op1, op2, op));
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}

	}
}