package primeri08;

public class Primer03 {
	
	/**
	 * Funkcija vraća akronim niza reči
	 * 
	 * @param words Početni tekst (reči)
	 * @return Akronim
	 */
	public static String acronym(String[] words) {
		// Inicijalizuj akumulator
		String retVal = "";
		
		// Prođi kroz listu reči
		for (int i = 0; i < words.length; i++) {
			// Transformiši prvo slovo reči u veliko slovi
			// i dodaj u akumulator
			retVal += words[i].charAt(0);
		}
		
		return retVal.toUpperCase();
	}
	
	public static void main(String[] args) {
		String[] words = {"random","access","memory"};
		System.out.println(acronym(words));
	}
}
