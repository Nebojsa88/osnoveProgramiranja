package primeri08;

import java.util.Scanner;

public class Primer05PripremaZaDomaci {
	
	/**
	 * Ukoliko student ima više od 3 izostanka, nema pravo da izađe na ispit
	 * @param number - broj izostanaka
	 * @return true ako student ima pravo da izađe na ispit, false ako nema.
	 */
	public static boolean isStudentQualifiedForExam(int number) {
		if (number > 3) {
			return false;
		} else {
			return true;
		}
	}
		 
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		int brojIzostanaka = 0;
		do {
			System.out.println("Unesite broj izostanaka studenta:");
			brojIzostanaka = Integer.parseInt(sc.nextLine());
		} while (!isStudentQualifiedForExam(brojIzostanaka));
	
		System.out.println("Student ima pravo da polaže ispit. Broj izostanaka: " + brojIzostanaka);

		sc.close();
	}

}
