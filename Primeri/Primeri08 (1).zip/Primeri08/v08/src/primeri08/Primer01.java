package primeri08;


public class Primer01 {
	
	public static void main(String[] args) {
		String s1 = "Hello world";
		String s2 = "Hello worl";
		s2 += "d";

		// Poredjenje objekta po referenci
		System.out.println("s1 == s2: " + (s1 == s2));
  		// Poredjenje objekta po vrednosti
		System.out.println("s1.equals(s2): " + s1.equals(s2));	
	}
} 
