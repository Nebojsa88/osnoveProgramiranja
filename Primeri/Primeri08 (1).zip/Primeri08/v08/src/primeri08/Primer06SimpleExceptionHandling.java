package primeri08;

import java.util.Scanner;

public class Primer06SimpleExceptionHandling {

	public static void main(String[] args) {
		
		System.out.println("Unesite broj:");
		Scanner sc = new Scanner(System.in);
		String broj_string = sc.nextLine();
		int broj = 0;
		try {
			broj = Integer.parseInt(broj_string);
			System.out.println(broj);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		sc.close();
		System.out.println("Ispis posle parsiranja.");
		
	}
}
