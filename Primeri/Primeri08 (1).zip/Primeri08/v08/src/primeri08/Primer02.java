package primeri08;

/*
 * Pregled string metoda.
 */
public class Primer02 {

	public static void main(String[] args) {
		String s1 = "ABCDEFGHIJ";
		
		char karakterNaIndeksu4 = s1.charAt(4);
		System.out.println(karakterNaIndeksu4);
		//ako pristupimo indeksu 17 dobijamo grešku
		
		int indexC = s1.indexOf("C");
		//Ako se unese nepostojeći karakter/string dobija se -1
		System.out.println("Indeks karaktera C je " + indexC);
		
		//Substring pronalazi podstring zadatog stringa. 
		//Dolazi u dve varijante:
		//Varijanta sa jednim parametrom gde je taj parametar početni indeks
		System.out.println("Podstring stringa " + s1 + " od indeksa 4 do kraja: " + s1.substring(4));

		//Varijanta sa dva parametra gde je prvi parametar početni indeks, a drugi krajnji
		System.out.println("Podstring stringa " + s1 + " od indeksa 4 do 7: " + s1.substring(4,7));
		//Karakter na krajnjem indeksu (u ovom primeru 7) ne ulazi u rešenje.
		
		int duzina = s1.length();
		for (int i=0; i<duzina; i++) {
			s1.charAt(i);
		}
		
		s1 = "ABC";
		String noviString = s1.concat("KL");
		System.out.println("Prvobitni string: " + s1);
		System.out.println("Novi string koji smo dobili konkatenacijom: " + noviString);
		//Konkatenacija - spajanje stringova. Dobijamo novi string, stari string s1 se ne menja.
		//Može i:
		//String noviString = s1 + "KL";
		
		//Contains proverava da li string sadrži neki podstring. 
		s1.contains("EF");
		
		//Replace kreira novi string menjajući karakter/string zadatim
		String rezultat = s1.replace("C", "www");
		System.out.println("Zamenom stringa \"C\" stringom \"www\" u stringu " + s1 
			 + " dobija se string " + rezultat);
		
		//Trim uklanja suvišne whitespace karaktere sa početka i kraja stringa.
		//Koristan kod unosa sa tastature.
		String s2 = "     Nesto    ";
		s2 = s2.trim();
		
		//CompareTo poredi stringove leksikografski - po abecedi
		//Ukoliko je prvi string pre drugog, compareTo vraća broj manji od 0
		//Ukoliko je prvi string posle drugog, compareTo vraća broj veći od 0
		//Ako su stringovi jednaki, compareTo vraća 0
		System.out.println(s1.compareTo(s2));
		//Postoji i varijacija compareToIgnoreCase
		
		//Split deli string na podstringove na osnovu odabranog znaka (ili stringa)
		//Rezultat je niz stringova
		String s3 = "Hello world dear humans";
		String[] niz = s3.split(" ");
		for (int i=0; i<niz.length; i++) {
			System.out.println(niz[i]);
		}
	}

}
