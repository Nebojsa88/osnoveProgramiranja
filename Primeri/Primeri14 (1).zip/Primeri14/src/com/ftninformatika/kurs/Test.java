package com.ftninformatika.kurs;

public class Test {
	
	public static void main(String[] args) {

		Kurs kurs = new Kurs(34567, "OOP", 20000);
		kurs.dodajPolaznika("Milan");

		kurs.dodajPolaznika("Milan");
		kurs.dodajPolaznika("Bojana");
		kurs.dodajPolaznika("Goran");
		kurs.dodajPolaznika("Stevan");
		
		System.out.println(kurs);
		
		System.out.println(kurs.pronadjiPolaznika("Milan"));
		System.out.println(kurs.izmeniPolaznika("Milan", "Aca"));
		System.out.println(kurs.pronadjiPolaznika("Milan"));
		System.out.println("Broj polaznika je: " + kurs.vratiBrojPolaznika());
		
		//brisanje polaznika Stevan
		kurs.ispisiPolaznike();
		kurs.obrisiPolaznika("Stevan");
		kurs.ispisiPolaznike();
		
		System.out.println("Cena po polazniku je : " + kurs.getCenaPoPolazniku());
		System.out.println("Ukupna cena kursa je : " + kurs.getUkupnaCenaKursa());
		
		kurs.setCenaPoPolazniku(-5.0);
		System.out.println("Cena po polazniku je : " + kurs.getCenaPoPolazniku());
		System.out.println("Ukupna cena kursa je : " + kurs.getUkupnaCenaKursa());
		
		kurs.setCenaPoPolazniku(1000);
		System.out.println("Cena po polazniku je : " + kurs.getCenaPoPolazniku());
		System.out.println("Ukupna cena kursa je : " + kurs.getUkupnaCenaKursa());
		
	}
}
