package primeri07;

public class Primer00RadNaCasu63 {
//Proširiti funkciju ispisom podataka o članskom broju
	public static void ispisPodataka(String ime, String prezime, int clBr) {
		
		System.out.println("--- Podaci o clanu ---");
		System.out.println("Clanski broj: " + clBr);
		System.out.println("Ime clana: " + ime);
		System.out.println("Prezime clana: " + prezime);
	}
	
 	public static void main(String[] args) {
		
 		ispisPodataka("Pera", "Peric", 123);
 		
		ispisPodataka("Sima", "Simic", 345);

	}

}
