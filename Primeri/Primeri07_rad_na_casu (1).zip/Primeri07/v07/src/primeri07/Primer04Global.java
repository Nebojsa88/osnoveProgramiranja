package primeri07;

public class Primer04Global {
	
	// Definicja globalne promenljive
	public static int i;
	
	// Funkcija inc inkrementira vrednost parametra
	public static void inc() {
		System.out.println(i);
		i++;
		System.out.println(i);
	}
	
	// Sta ce ispisati funkcija main?
	public static void main(String[] args) {
		i = 0;
		System.out.println(i);
		inc();
		System.out.println(i);
	}	
}