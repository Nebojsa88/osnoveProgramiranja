package primeri07;

public class Primer03Inc {

	// Funkcija inc inkrementira vrednost parametra
	public static int inc(int i) {
		i++;
		System.out.println(i);
		return i;
	}
	
	// Sta ce ispisati funkcija main?
	public static void main(String[] args) {
		int i = 0;
		System.out.println(i);
		i = inc(i);
		System.out.println(i);
	}	
}