package primeri07;
/*
 * Ovaj primer uvodi povratne vrednosti. Return naredba, tip povratne vrednosti itd.
 */
public class Primer01Zbir {

	public static int zbir(int num1, int num2) {
		int z = num1 + num2;
		return z;
	}
	
	public static void main(String[] args) {
		int a = 4;
		int b = 5;
		int c = zbir(a,b);
		System.out.println(c);
		System.out.println(a);
		System.out.println(b);
	}

}
