package studentskaSluzba;

public class Test {

	public static void main(String[] args) {
		
		/**
		 * Eksplicitno smo definisali konstruktor bez parametara i atributu prosek dodelili početnu vrednost.
		 */
		Student pera = new Student();
		System.out.println(pera.prosek);
		
		/**
		 * Primer konstruktora sa parametrima.
		 * Prosleđujemo direktno vrednosti odgovarajućeg tipa propisanog konstruktorom u redosledu propisanom konstruktorom.
		 */
		Student mika = new Student("Mika", 54, 7);
		System.out.println(mika.ime);
		System.out.println(mika.prosek);
		
		//TODO: Zadatak: Instancirati novog studenta pomoću novokreiranog konstruktora sa 3 parametra
		//				 i ispisati sve vrednosti novog objekta.
		
		
		mika.dodajOcenu(10);
		System.out.println(mika.prosek);
		mika.dodajOcenu(6);
		System.out.println(mika.prosek);
		System.out.println(mika.dodajOcenu(9));
		//TODO: Zadatak: Ispisati prethodni prosek (pozvati metodu izbrisiOcenu)
		
		mika.dipomiraj();
		
		mika.dodajOcenu(10); // neće se dodati ocena zbog toga što je student diplomirao

	}

}
