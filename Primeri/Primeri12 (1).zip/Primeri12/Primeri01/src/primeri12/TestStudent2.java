package primeri12;

public class TestStudent2 {
	
	public static void main(String[] args) {
		
		Student pera = new Student();
		Student sima = pera;
		
		pera.ime = "Pera";	// dodeljen je string "Pera" atributu ime tako što se tom atributu pristupilo pomoću . (tačke)
		pera.prosek = 8.67; // dodeljen je broj 8.67 atributu prosek tako što se tom atributu pristupilo pomoću . (tačke)
		
		System.out.println(pera.ime); // Šta će biti ispisano u ovom slučaju?
		
		sima.ime = "Sima"; // Objektu sima dodeljena je vrednost "Sima"
		
		System.out.println(sima.ime);
		System.out.println(pera.ime); // Šta će biti ispisano u ovom slučaju?
	}

}
