package primeri12;
/**
 * 
 * @author Bojana/Milan
 * Klasa Student modeluje studenta.
 */
public class Student {
	
	String ime;
	double prosek;

	/**
	 * Metoda ispisiProsek ispisuje prosek studenta u toku studija.
	 */
	void ispisiProsek() {
		System.out.println("Prosek studenta " + ime + " je " + prosek + ".");
	}
	
	/**
	 * Metoda diplomiraj ispisuje na konzolu obeveštenje da je student diplomirao.
	 */
	void diplomiraj() {
		System.out.println("Student " + ime + " je diplomirao.");
	}

}
