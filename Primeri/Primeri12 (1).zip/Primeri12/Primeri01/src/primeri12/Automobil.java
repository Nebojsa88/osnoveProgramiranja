package primeri12;
/**
 * 
 * @author Bojana/Milan
 *
 * Klasa Automobil modeluje stanje i ponašanje automobila.
 * Naziv klase počinje velikim slovom ispred koje je obavezna ključna reč <b>class</b>
 * O ključnoj reči <b>public<b> kasnije tokom kursa
 */
public class Automobil {
	
	/**
	 * Atributi <b>brojTablica</b> i <b>brzina</b> definišu stanje objekta klase Automobil.
	 * Kada se promeni vrednost bilo kog atributa kaže se da je objekat promenio svoje stanje.
	 */
	String brojTablica; //primer camelCase notacije gde naziv počinje malim slovom a svaka sledeća reč počinje velikim.
	double brzina = 0.0;
	
	/**
	 * Metoda pokreni služi za pokretanje automobila.
	 * Trenutno se pozivom ove metode samo vrši ispis na konzolu.
	 * Konvencija je da naziv počinje malim slovom a svaka sledeća reč velikim - npr. pokreniAutomobil()
	 */
	void pokreni() {
		System.out.println("Automobil je krenuo.");
	}
	
	/**
	 * Metoda parkiraj služi za parkiranje automobila.
	 * Trenutno se pozivom ove metode samo vrši ispis na konzolu.
	 */
	void parkiraj() {
		System.out.println("Automobil se parkira.");
		brzina = 0;
	}
	
	/**
	 * Metoda ubrzaj služi za ubrzavanje automobila.
	 * Trenutno se pozivom ove metode samo vrši ispis na konzolu.
	 */
	void ubrzaj(double km) {
		System.out.println("Automobil je ubrzao.");
		brzina += km;
		
	}
	
	/**
	 * Metoda uspori služi za usporavanje automobila.
	 * Trenutno se pozivom ove metode samo vrši ispis na konzolu.
	 */
	void uspori(double km) {
		System.out.println("Automobil je usporio.");
		brzina -= km;
	}

}
