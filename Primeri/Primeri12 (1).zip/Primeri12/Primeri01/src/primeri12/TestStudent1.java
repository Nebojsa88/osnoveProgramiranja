package primeri12;

public class TestStudent1 {

	public static void main(String[] args) {
		
		Student pera = new Student();
		Student mika = new Student();
		
		pera.ime = "Pera";	// dodeljen je string "Pera" atributu ime tako što se tom atributu pristupilo pomoću . (tačke)
		pera.prosek = 8.67; // dodeljen je broj 8.67 atributu prosek tako što se tom atributu pristupilo pomoću . (tačke)
		
		/**
		 * Pokušaćemo da ispišemo na konzolu informacije koje sadrži objekat pera.
		 * U prvoj liniji ispisa dobićemo "ružan" string koji se sastoji od imena klase (Student) simbola @
		 * i heškoda samog objekta u heksadecimalnom zapisu.
		 */
		System.out.println(pera);	// Ako ništa ne promenimo u klasi Student ovakav ispis nam ništa neće značiti.
		System.out.println(pera.ime);
		System.out.println(pera.prosek);
		
		//TODO Zadatak: Oživeti miku! Dodeliti ime i prosek objektu mika i ispisati te podatke u formatu: "Ja sam Mika i imam prosek 9.12."

	}

}
