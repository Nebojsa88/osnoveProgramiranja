package com.ftninformatika.evidencija64;

import java.util.ArrayList;

public class Evidencija {

	private String nazivSuda;
	private String adresaSuda;
	private ArrayList<Predmet> spisakPredmeta;

	public Evidencija() {
		this.spisakPredmeta = new ArrayList<>();
	}


	public Evidencija(String nazivSuda, String adresaSuda) {
		this.nazivSuda = nazivSuda;
		this.adresaSuda = adresaSuda;
		this.spisakPredmeta = new ArrayList<>();
	}


	public Evidencija(String nazivSuda, String adresaSuda, ArrayList<Predmet> spisakPredmeta) {
		this.nazivSuda = nazivSuda;
		this.adresaSuda = adresaSuda;
		this.spisakPredmeta = spisakPredmeta;
	}


	public String getNazivSuda() {
		return nazivSuda;
	}


	public void setNazivSuda(String nazivSuda) {
		this.nazivSuda = nazivSuda;
	}


	public String getAdresaSuda() {
		return adresaSuda;
	}


	public void setAdresaSuda(String adresaSuda) {
		this.adresaSuda = adresaSuda;
	}


	public ArrayList<Predmet> getSpisakPredmeta() {
		return spisakPredmeta;
	}


	public void setSpisakPredmeta(ArrayList<Predmet> spisakPredmeta) {
		this.spisakPredmeta = spisakPredmeta;
	}

	public boolean dodajPredmet(Predmet noviPredmet) {

		for(int i = 0; i < this.spisakPredmeta.size(); i++) {
			if(this.spisakPredmeta.get(i).getBroj() == noviPredmet.getBroj()) {
				return false;
			}
		}
		this.spisakPredmeta.add(noviPredmet);
		return true;
	}


	public void ispisiNaOsnovuBroja(int brojPredmeta) {

		for(int i = 0; i < this.spisakPredmeta.size(); i++) {
			if(brojPredmeta == this.spisakPredmeta.get(i).getBroj()) {
				System.out.println(this.spisakPredmeta.get(i));
			}
		}
	}

	public void ispisiNaOsnovuNaziva(String naziv) {

		for(int i = 0; i < this.spisakPredmeta.size(); i++) {
			if(naziv.equals(this.spisakPredmeta.get(i).getNaziv())) {
				System.out.println(this.spisakPredmeta.get(i));
			}
		}
	}
	
	public String dodajTekst(String tekst, int brojPredmeta) {
		
		for(int i = 0; i < this.spisakPredmeta.size(); i++) {
			if(brojPredmeta == this.spisakPredmeta.get(i).getBroj()) {
				String noviTekst = this.spisakPredmeta.get(i).getTekst() + " " + tekst;
				this.spisakPredmeta.get(i).setTekst(noviTekst);
				return this.spisakPredmeta.get(i).getTekst();
			}
		}
		return null;
	}

	public String toString() {

		String temp = "";
		temp += "Naziv suda: " + this.nazivSuda + "\n";
		temp += "Adresa suda: " + this.adresaSuda + "\n";
		temp += "Spisak predmeta:\n";
		for(int i = 0; i < this.spisakPredmeta.size(); i++) {
			temp += this.spisakPredmeta.get(i) + "\n";
		}

		return temp.trim();
	}

}
