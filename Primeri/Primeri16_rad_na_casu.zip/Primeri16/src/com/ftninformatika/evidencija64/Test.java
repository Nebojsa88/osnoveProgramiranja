package com.ftninformatika.evidencija64;

import java.time.LocalDate;

public class Test {

	public static void main(String[] args) {

		Evidencija evidencija = new Evidencija("Neki sud", "Neka adresa");
		//System.out.println(evidencija);
		LocalDate datumZaUnos = LocalDate.of(2011, 10, 13);
		LocalDate trenutniDatum = LocalDate.now();
		Predmet p1 = new Predmet(1, "Prvi predmet", "Tekst prvog predmeta", datumZaUnos);
		Predmet p2 = new Predmet(1, "Drugi predmet", "Tekst drugog predmeta", datumZaUnos);
		Predmet p3 = new Predmet(3, "Treci predmet", "Tekst treceg predmeta", trenutniDatum);
		evidencija.dodajPredmet(p1);
		evidencija.dodajPredmet(p2);
		evidencija.dodajPredmet(p3);
		evidencija.dodajTekst("Jos teksta", 3);
		evidencija.ispisiNaOsnovuNaziva("Treci predmet");
		evidencija.ispisiNaOsnovuBroja(1);
		//System.out.println(evidencija);
	}

}
