package com.ftninformatika.bicikl;

public class Bicikl {

	private Tocak prednji;
	private Tocak zadnji;
	
	public Bicikl(int precnik) {
		this.prednji = new Tocak(precnik);
		this.zadnji = new Tocak(precnik);
	}
	
	public Bicikl(Tocak prednji, Tocak zadnji) {
		this.prednji = prednji;
		this.zadnji = zadnji;
	}

	public Tocak getPrednji() {
		return prednji;
	}

	public void setPrednji(Tocak prednji) {
		this.prednji = prednji;
	}

	public Tocak getZadnji() {
		return zadnji;
	}

	public void setZadnji(Tocak zadnji) {
		this.zadnji = zadnji;
	}
	
}
