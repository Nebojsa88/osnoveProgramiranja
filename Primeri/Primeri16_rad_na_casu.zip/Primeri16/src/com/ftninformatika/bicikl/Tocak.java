package com.ftninformatika.bicikl;

public class Tocak {

	private int precnik;
	
	public Tocak(int precnik) {
		this.precnik = precnik;
	}

	public int getPrecnik() {
		return precnik;
	}

	public void setPrecnik(int precnik) {
		this.precnik = precnik;
	}
	
	
}
