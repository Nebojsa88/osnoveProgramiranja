package com.ftninformatika.evidencija63;

import java.time.LocalDate;

public class Test {

	public static void main(String[] args) {
		
		Evidencija evidencija = new Evidencija("Neki sud", "neka adresa");
		//System.out.println(evidencija);
		Predmet p1 = new Predmet(1, "Prvi predmet", "Tekst prvog predmeta", LocalDate.of(2010, 11, 15));
		Predmet p2 = new Predmet(1, "Drugi predmet", "Tekst drugog predmeta", LocalDate.of(2010, 11, 15));
		Predmet p3 = new Predmet(3, "Treci predmet", "Tekst treceg predmeta", LocalDate.now());
		evidencija.dodajPredmet(p1);
		evidencija.dodajPredmet(p2);
		evidencija.dodajPredmet(p3);
		evidencija.dodajTekst("Jos teksta", 3);
		evidencija.pretragaPoNazivu("Treci predmet");
		evidencija.pretragaPoBroju(1);
		//System.out.println(evidencija);
	}

}
