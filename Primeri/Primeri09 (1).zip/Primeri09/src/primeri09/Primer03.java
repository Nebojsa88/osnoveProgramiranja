package primeri09;

import java.util.ArrayList;

/*
 *  Sortiranje liste metodom selection sort.
 *  Autor: Milan Vidakovic
 */
class Primer03 {

  
  /** Stampa listu na ekranu. Ako su parametri i i j jednaki -1, onda se
    * samo stampa lista. Ako je barem jedan od njih razlicit od -1, 
    * element sa tim indeksom se prikazuje u uglastim zagradama.
    */
  static void print(ArrayList<Integer> a, int i, int j) {
    int n = a.size();
    int k;
  
    for (k = 0; k < n; k++) {
      if (k == i || k == j)
        System.out.printf("[%d] ", a.get(k));
      else
        System.out.printf(" %d  ", a.get(k));
    }
    System.out.println();
  }
  
  /** Sortira zadatu listu niz po algoritmu selection sort. */
  static void sort(ArrayList<Integer> a) {
    int n = a.size();
    int i, j, tmp;
    for (i = 0; i < n-1; i++)
    {
      /* tekuci el. iz petlje po 'i' poredimo
       sa svim ostalim elementima (petlja po 'j') */
      for (j = i+1; j < n; j++)
      {
        print(a, i, j); // odstampamo listu pre eventualne zamene
        if (a.get(i) > a.get(j)) {
          tmp = a.get(i);
          a.set(i, a.get(j));
          a.set(j, tmp);
        }
        print(a, i, j); // odstampamo listu posle eventualne zamene
      }
      System.out.println();
    }
  }
  
  public static void main(String[] args) {
    ArrayList<Integer> lista = new ArrayList<Integer>();
    lista.add(44);
    lista.add(55);
    lista.add(12);
    lista.add(42);
    lista.add(94);
    lista.add(18);
    lista.add(6);
    lista.add(67);
      
    System.out.printf("Nesortirano:\n");
    print(lista, -1, -1);
    System.out.println();
    sort(lista);
    System.out.printf("Sortirano:\n");
    print(lista, -1, -1);
  }
}