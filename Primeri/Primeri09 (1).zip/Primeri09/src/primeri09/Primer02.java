package primeri09;

import java.util.ArrayList;

/*
 *  Binarna pretraga liste.
 *  Ova metoda radi jedino ako je lista uredjena.
 *  Autor: Milan Vidakovic
 */
class Primer02 {
  
  /*
   * Stampa listu na ekran.
   */
  static void print(ArrayList<Integer> a) {
    int n = a.size();
    int i;
  
    for (i = 0; i < n; i++) {
      System.out.printf(" %02d  ", a.get(i));
    }
    System.out.println();
  }
  
  /*
   * Pretrazuje listu a za zadatim elementom el.
   */
  static int search(ArrayList<Integer> a, int el) {
    int n = a.size();
    int d = 0;   // donja granica 
    int g = n-1; // gornja granica
    while (d <= g) {
      int s = (d + g) / 2;      // sracunamo sredinu liste.
      System.out.printf("donja: %d, gornja: %d, sredina: %d\n", d, g, s);
      if (el > a.get(s))
        d = s + 1;              // trazimo u gornjoj polovini
      else if (el < a.get(s))
        g = s - 1;              // trazimo u donjoj polovini 
      else
        return s;               // nasli - vracamo poziciju 
     }
     return -1;                 // nismo nasli 
  }
  
  
  public static void main(String[] args) {
    ArrayList<Integer> lista = new ArrayList<Integer>();
    lista.add(2);
    lista.add(4);
    lista.add(9);
    lista.add(10);
    lista.add(13);
    lista.add(20);
    lista.add(68);
    lista.add(80);
    lista.add(300);
    lista.add(400);
  
    System.out.println("Lista:");
    print(lista);
    System.out.println();
    int i = search(lista, 9);
    System.out.printf("\nRedni broj elementa 9 u listi je: %d\n\n", i);
    i = search(lista, 25);
    System.out.printf("\nRedni broj elementa 25 u lista je: %d\n\n", i);
  }
}