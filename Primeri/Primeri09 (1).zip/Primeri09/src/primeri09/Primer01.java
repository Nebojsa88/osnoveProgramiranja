package primeri09;

import java.util.ArrayList;

/*
 *  Linearna pretraga liste.
 *  Ova metoda se koristi kada je niz neuredjen.
 *  Autor: Milan Vidakovic
 */
class Primer01 {


  /*
   * Stampa listu na ekran.
   */
  public static void print(ArrayList<Integer> a) {
    int n = a.size();
    int i;
  
    for (i = 0; i < n; i++) {
      System.out.printf(" %02d  ", a.get(i));
    }
    System.out.println();
  }
  
  /*
   * Linearna pretraga liste. Idemo od prvog do poslednjeg i
   * ako nadjemo, vratimo redni broj. Ako ne nadjemo, vratimo -1.
   */
  public static int search(ArrayList<Integer> a, int el) {
    int n = a.size();
    int i;
  
    for (i = 0; i < n; i++) {
      if (a.get(i) == el)
        return i;
    }
    return -1;
  }
  
  
  public static void main(String[] args) {
    ArrayList<Integer> lista = new ArrayList<Integer>();
    lista.add(7);
    lista.add(4);
    lista.add(9);
    lista.add(10);
    lista.add(1);
    lista.add(2);
    lista.add(16);
    lista.add(8);
    lista.add(3);
    lista.add(4);
  
    System.out.println("Lista:");
    print(lista);
    System.out.println();
    int i = search(lista, 9);
    System.out.printf("Redni broj elementa 9 u listi je: %d\n", i);
    i = search(lista, 25);
    System.out.printf("Redni broj elementa 25 u listi je: %d\n", i);
  }
}