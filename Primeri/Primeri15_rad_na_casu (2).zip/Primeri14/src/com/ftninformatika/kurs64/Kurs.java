package com.ftninformatika.kurs64;

import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;

public class Kurs {

	private int sifra;
	private String naziv;
	private ArrayList<String> spisakPolaznika;
	private double cenaPoPolazniku;
	private double ukupnaCena;

	public Kurs() {
		this.naziv = "";
		this.spisakPolaznika = new ArrayList<>();
	}
	
	

	public Kurs(int sifra, String naziv, double cenaPoPolazniku) {
		this.sifra = sifra;
		this.naziv = naziv;
		this.cenaPoPolazniku = cenaPoPolazniku;
		this.spisakPolaznika = new ArrayList<>();
	}



	public Kurs(int sifra, String naziv, ArrayList<String> spisakPolaznika, double cenaPoPolazniku) {
		this.sifra = sifra;
		this.naziv = naziv;
		this.spisakPolaznika = spisakPolaznika;
		this.cenaPoPolazniku = cenaPoPolazniku;
	}

	public int getSifra() {
		return sifra;
	}

	public void setSifra(int sifra) {
		this.sifra = sifra;
	}

	public String getNaziv() {
		return naziv;
	}

	public void setNaziv(String naziv) {
		this.naziv = naziv;
	}

	public ArrayList<String> getSpisakPolaznika() {
		return spisakPolaznika;
	}

	public void setSpisakPolaznika(ArrayList<String> spisakPolaznika) {
		this.spisakPolaznika = spisakPolaznika;
	}

	public double getCenaPoPolazniku() {
		return cenaPoPolazniku;
	}

	public void setCenaPoPolazniku(double cenaPoPolazniku) {
		this.cenaPoPolazniku = cenaPoPolazniku;
	}
	
	public double izracunajSumu() {
		double suma = this.cenaPoPolazniku * this.spisakPolaznika.size();
		return suma;
	}

	public double getUkupnaCena() {
		this.ukupnaCena = izracunajSumu();
		return ukupnaCena;
	}
	
	public boolean dodajPolaznika(String imeIPrezime) {
		
		for(int i = 0; i < this.spisakPolaznika.size(); i++) {
			if(imeIPrezime.equals(this.spisakPolaznika.get(i))) {
				return false;
			}
		}
		this.spisakPolaznika.add(imeIPrezime);
		return true;
	}
	
	public void ispisiPolaznike() {
		
		for(int i = 0; i < this.spisakPolaznika.size(); i++) {
			System.out.println(this.spisakPolaznika.get(i));
		}
	}
	
	public String izbrisiPolaznika(String imeIPrezime) {
		
		for(int i = 0; i < this.spisakPolaznika.size(); i++) {
			if(imeIPrezime.equals(this.spisakPolaznika.get(i))) {
				return this.spisakPolaznika.remove(i);
			}
		}
		return null;
	}
	
	public boolean izmeniPolaznika(String staroIme, String novoIme) {
		
		for(int i = 0; i < this.spisakPolaznika.size(); i++) {
			if(staroIme.equals(this.spisakPolaznika.get(i))) {
				this.spisakPolaznika.set(i, novoIme);
				return true;
			}
		}
		return false;
	}
	
	public void pretragaPoImenuIPrezimenu(String imeIPrezime) {
		
		for(int i = 0; i < this.spisakPolaznika.size(); i++) {
			if(imeIPrezime.equals(this.spisakPolaznika.get(i))) {
				System.out.println(this.spisakPolaznika.get(i));
			}
		}
	}
	
	public ArrayList<String> pretragaPoImenu(String ime) {
		
		ArrayList<String> listaRezultata = new ArrayList<>();
		for(int i = 0; i < this.spisakPolaznika.size(); i++) {
			//String[] delovi = this.spisakPolaznika.get(i).split(" ");
			//if(delovi[0].equals(ime)) {
			if(this.spisakPolaznika.get(i).substring(0, this.spisakPolaznika.get(i).indexOf(" ")).equals(ime)) {
				listaRezultata.add(this.spisakPolaznika.get(i));
				System.out.println(this.spisakPolaznika.get(i));
			}
		}
		return listaRezultata;
	}
	
	public void ispisiBrojPolaznika() {
		System.out.println("Ukupan broj polanzika je: " + this.spisakPolaznika.size());
	}
	
	public void sacuvajPolaznike(String putanja) {
		
		ArrayList<String> lines = new ArrayList<>();
		lines.add(String.valueOf(this.sifra));
		lines.add(this.naziv);
		for(int i = 0; i < this.spisakPolaznika.size(); i++) {
			String line = this.spisakPolaznika.get(i);
			lines.add(line);
		}
		
		try {
			Files.write(Paths.get(putanja), lines, Charset.defaultCharset(), StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING, StandardOpenOption.WRITE);
		} catch (IOException e) {
			System.out.println("Desila se greska pri upisu!");
		}
	}
	
	public void ucitajPodatke(String putanja) {
		
		this.spisakPolaznika = new ArrayList<>();
		try {
			 ArrayList<String> lines = (ArrayList<String>) Files.readAllLines(Paths.get(putanja), Charset.defaultCharset());
			 this.sifra = Integer.valueOf(lines.get(0));
			 this.naziv = lines.get(1);
			 for(int i = 2; i < lines.size(); i++) {
				 this.spisakPolaznika.add(lines.get(i));
			 }
			 /*lines.remove(0);
			 lines.remove(0);
			 for(String line : lines) {
				 this.spisakPolaznika.add(line);
			 }*/
			 
		} catch (IOException e) {
			System.out.println("Desila se greska prilikom citanja!");
		}
	}


	public String toString() {
		
		String temp = "";
		temp += "Sifra kursa: " + this.sifra + "\n";
		temp += "Naziv kursa: " + this.naziv + "\n";
		temp = temp + "Cena po polazniku: " + this.cenaPoPolazniku + "\n";
		temp += "Ukupna cena: " + getUkupnaCena() + "\n";
		temp += "Spisak polaznika:\n";
		for(int i = 0; i < this.spisakPolaznika.size(); i++) {
			temp += this.spisakPolaznika.get(i) + "\n";
		}
		return temp.trim();
	}

}
