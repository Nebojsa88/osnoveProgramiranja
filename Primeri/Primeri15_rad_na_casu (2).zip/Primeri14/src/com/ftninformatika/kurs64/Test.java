package com.ftninformatika.kurs64;

public class Test {

	public static void main(String[] args) {


		Kurs kurs = new Kurs(111, "ABC", 100.0);
		//System.out.println(kurs);
		if(kurs.dodajPolaznika("Milan Peric")) {
			System.out.println("Korisnik je uspesno dodat!");
		}
		kurs.dodajPolaznika("Milana Peric");
		kurs.dodajPolaznika("Mika Mikic");
		kurs.dodajPolaznika("Pera Zikic");
		//System.out.println(kurs);
		//kurs.izbrisiPolaznika("Mika Mikic");
		kurs.izmeniPolaznika("Mika Mikic", "Zika Zikic");
		//kurs.ispisiPolaznike();
		//kurs.pretragaPoImenuIPrezimenu("Pera Peric");
		kurs.pretragaPoImenu("Milan");
		//kurs.ispisiBrojPolaznika();
		kurs.sacuvajPolaznike("kurs64.txt");
		kurs.ucitajPodatke("kurs64.txt");
		System.out.println(kurs);

	}

}
