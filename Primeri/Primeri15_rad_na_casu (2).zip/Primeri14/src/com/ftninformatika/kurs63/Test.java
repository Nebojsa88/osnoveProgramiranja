package com.ftninformatika.kurs63;

public class Test {

	public static void main(String[] args) {
		
		Kurs kurs = new Kurs(11111, "OP", 100.0);
		//System.out.println(kurs);
		kurs.dodajPolaznika("Pera Peric");
		kurs.dodajPolaznika("Pera Peric");
		kurs.dodajPolaznika("Mika Mikic");
		kurs.dodajPolaznika("Pera Mikic");
		kurs.dodajPolaznika("Zika Zikic");
		//System.out.println(kurs);
		//kurs.ispisPolaznika();
		//kurs.izbrisiPolaznika("Pera Peric");
		//kurs.ispisPolaznika();
		//kurs.izmeniPolaznika("Mika Mikic", "Zika Zikic");
		//System.out.println();
		//kurs.ispisPolaznika();
		//kurs.pretragaPoImenuIPrezimenu("Zika Zikic");
		kurs.pretragaPoImenu("Pera");
		kurs.ispisBrojaPolaznika();
		kurs.sacuvajPolaznike("kurs63.txt");
		kurs.ucitajPodatke("kurs63.txt");
		kurs.ispisPolaznika();
	}

}
