package com.ftninformatika.kurs;
import java.util.ArrayList;

public class Kurs {

	private int sifra;
	private String nazivKursa;
	private ArrayList<String> polaznici;
	private double cenaPoPolazniku;
	private double ukupnaCenaKursa;

	/*
	 * Konstruktor bez parametara
	 */
	public Kurs() {
		this.polaznici = new ArrayList<String>();
		this.cenaPoPolazniku = 15000;
	}

	/*
	 * Konstruktor sa 2 parametra
	 */
	public Kurs(int sifra, String nazivKursa) {
		this.sifra = sifra;
		this.nazivKursa = nazivKursa;
		this.cenaPoPolazniku = 15000;
		this.polaznici = new ArrayList<String>();
	}
	
	/*
	 * Kostruktor sa 3 parametara
	 */
	public Kurs(int sifra, String nazivKursa, double cenaPoPolazniku) {
		
		this.sifra = sifra;	
		this.nazivKursa = nazivKursa;
		this.cenaPoPolazniku = cenaPoPolazniku;
		this.polaznici = new ArrayList<String>();
	}
	
	
	
	public Kurs(int sifra, String nazivKursa, ArrayList<String> polaznici, double cenaPoPolazniku) {
		super();
		this.sifra = sifra;
		this.nazivKursa = nazivKursa;
		this.polaznici = polaznici;
		this.cenaPoPolazniku = cenaPoPolazniku;
	}

	/*
	 * getter za atribut sifra
	 */
	public double getSifra() {
		return this.sifra;
	}

	/*
	 * setter za atribut sifra
	 */
	public void setSifra(int sifra) {
		if (String.valueOf(sifra).length() == 5) {
			this.sifra = sifra;
		} else {
			System.out.println("Uneta sifra nema tacno 5 cifara. Izmena nije izvrsena.");
		}
	}

	/*
	 * getter za atibut nazivKursa
	 */
	public String getNazivKursa() {
		return this.nazivKursa;
	}

	/*
	 * setter za nazivKursa
	 */
	public void setNazivKursa(String nazivKursa) {
		this.nazivKursa = nazivKursa;
	}

	/*
	 * getter za atribut polaznici
	 */
	public ArrayList<String> getPolaznici() {
		return this.polaznici;
	}

	/*
	 * setter za atribut polaznici
	 */
	public void setPolaznici(ArrayList<String> polaznici) {
		this.polaznici = polaznici;
	}
	

	/*
	 * getter za atribut cenaPoPolazniku
	 */
	public double getCenaPoPolazniku() {
		return this.cenaPoPolazniku;
	}

	/*
	 * setter za atribut cenaPoPolazniku
	 */
	public void setCenaPoPolazniku(double cenaPoPolazniku) {
		if (cenaPoPolazniku >= 0) {
			this.cenaPoPolazniku = cenaPoPolazniku;
		} else {
			System.out.println("Uneta cena po polazniku je manja od 0. Izmena nije izvrsena.");
		}
		
	}

	/*
	 * getter za atribut ukupnaCenaKursa
	 */
	public double getUkupnaCenaKursa() {
		this.ukupnaCenaKursa = this.polaznici.size() * this.cenaPoPolazniku;
		return ukupnaCenaKursa;
	}

	/*
	 * U listi polaznici se pronalazi polaznik zadatog imena i prezimena
	 */
	public String pronadjiPolaznika(String polaznik) {

		for(int i = 0; i < this.polaznici.size(); i++) {
			if(this.polaznici.get(i).equals(polaznik)) {
				return this.polaznici.get(i);
			}
		}

		return "Korisnik sa imenom " + polaznik + " nije pronadjen.";
	}
	
	
	public void ispisiPolaznikeSaIstimImenom(String ime) {
		
		for(int i = 0; i < this.polaznici.size(); i++) {
			String[] names = this.polaznici.get(i).split(" ");
			if(names[0].equals(ime)) {
				System.out.println(this.polaznici.get(i));
			}
		}
		
	}

	/*
	 * Iz liste polaznika uklanja se polaznik zadatog imena
	 */
	public boolean obrisiPolaznika(String polaznik) {

		for(int i = 0; i < this.polaznici.size(); i++) {
			if(this.polaznici.get(i).equals(polaznik)) {
				this.polaznici.remove(i);
				return true;
			}
		}
		return false;
	}
	
	/*
	 * Dodavanje novog polaznika.
	 * Ogranicenje - ne postoji dva ili vise polaznika sa istim imenom i prezimenom.
	 */
	public boolean dodajPolaznika(String polaznik) {

		for(int i = 0; i < this.polaznici.size(); i++) {
			if(this.polaznici.get(i).equals(polaznik)) {
				return false;
			}
		}
		this.polaznici.add(polaznik);
		return true;
	}

	/*
	 * Iz liste polaznika menja se polaznik imena stariPolaznik za polaznika imena noviPolaznik
	 */
	public boolean izmeniPolaznika(String stariPolaznik, String noviPolaznik) {

		for(int i = 0; i < this.polaznici.size(); i++) {
			if(this.polaznici.get(i).equals(stariPolaznik)) {
				this.polaznici.set(i, noviPolaznik);
				return true;
			}
		}

		return false;
	}

	/*
	 * Izracunava broj polaznika
	 */
	public int vratiBrojPolaznika() {

		return this.polaznici.size();
	}
	
	/*
	 * Ispis liste polaznika
	 */
	public void ispisiPolaznike(){
		System.out.println(">>>>>>>>>>Polaznici kursa<<<<<<<<<<");
		for(int i = 0; i < this.polaznici.size(); i++) {
			System.out.println(this.polaznici.get(i));
		}
	}

	@Override
	public String toString() {

		return "Kurs [sifra = " + this.sifra + ", nazivKursa = " + this.nazivKursa + "]";
	}

}
