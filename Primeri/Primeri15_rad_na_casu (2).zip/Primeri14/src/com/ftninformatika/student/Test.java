package com.ftninformatika.student;

public class Test {

	public static void main(String[] args) {
		
		Student student = new Student(34567, "Pera", "Peric");
		
		System.out.println(student.getProsek());
		
		student.upisiOcenu("OOP", 6);
		student.upisiOcenu("Matematika", 8);
		student.upisiOcenu("Matematicka analiza", 7);
		student.upisiOcenu("Fizika", 10);
		
		student.ispisPodatakaOStudentu();
		
		student.izmeniOcenu("Matematika", 10);
		System.out.println(student.getProsek());
		
		student.ispisiPredmeteSaOCenomVecomOd(7);
		
		student.ispisiOcene();
		
		student.pretragaPoNazivuPredmeta("mAtem");
		
		student.ponistiOcenu("Fizika");
		student.ispisiOcene();
		
	}

}
