package domaci09;

import java.util.ArrayList;
import java.util.Scanner;

public class Domaci02 {
	
	// Kolekcije u kojima se čuvaju podaci o korisnicima
	public static ArrayList<String> firstNames = new ArrayList<String>();
	public static ArrayList<String> lastNames = new ArrayList<String>();
	public static ArrayList<String> usernames = new ArrayList<String>();
	public static ArrayList<String> passwords = new ArrayList<String>();
	public static ArrayList<String> emails = new ArrayList<String>();
	public static ArrayList<String> ids = new ArrayList<String>();
	
	public static Scanner scanner = new Scanner(System.in);
	
	/**
	 * Validira ime (počinje velikim slovom)
	 */
	public static boolean isFirstNameValid(String firstName) {
		if (firstName.equals("")) {
			return false;
		}
		
		return Character.isUpperCase(firstName.charAt(0));
	}
	
	/**
	 * Validira prezime (počinje velikim slovom)
	 */
	public static boolean isLastNameValid(String lastName) {
		if (lastName.equals("")) {
			return false;
		}
		
		return Character.isUpperCase(lastName.charAt(0));
	}
	
	/**
	 * Validira korisničko ime (sadrži samo slova)
	 */
	public static boolean isUsernameValid(String username) {
		if (username.equals("")) {
			return false;
		}
		
		boolean containsLettersOnly = true;
		for (int i = 0; i < username.length(); i++) {
			if (!Character.isLetter(username.charAt(i))) {
				containsLettersOnly = false;
				break;
			}
		}
		
		return containsLettersOnly;
	}
	
	/**
	 * Validira lozinku (sadrži bar jedno malo slovo, veliko slovo, cifru i specijalni znak
	 * i ima između 6 i 12 znakova)
	 */
	public static boolean isPasswordValid(String password) {
		if (password.equals("")) {
			return false;
		}
		
		boolean isValidLength = password.length() >= 6 && password.length() <= 12;
		
		boolean containsDigit = false;
		for (int i = 0; i < password.length(); i++) {
			if (Character.isDigit(password.charAt(i))) {
				containsDigit = true;
				break;
			}
		}
		
		boolean containsLowerCaseLetter = false;
		for (int i = 0; i < password.length(); i++) {
			if (Character.isLowerCase(password.charAt(i))) {
				containsLowerCaseLetter = true;
				break;
			}
		}
		
		boolean containsUpperCaseLetter = false;
		for (int i = 0; i < password.length(); i++) {
			if (Character.isUpperCase(password.charAt(i))) {
				containsUpperCaseLetter = true;
				break;
			}
		}
		
		boolean containsSpecialCharacter = false;
		for (int i = 0; i < password.length(); i++) {
			if (!Character.isLetter(password.charAt(i)) && !Character.isDigit(password.charAt(i))) {
				containsSpecialCharacter = true;
				break;
			}
		}
		
		return isValidLength && containsDigit && containsLowerCaseLetter && containsUpperCaseLetter && containsSpecialCharacter;
	}
	
	/**
	 * Validira e-mail adresu (sadrži znak @)
	 */
	public static boolean isEmailValid(String email) {
		if (email.equals("")) {
			return false;
		}
		
		return email.contains("@");
	}
	
	/**
	 * Validira JMBG (ima tačno 13 cifara)
	 */
	public static boolean isIDValid(String id) {
		if (id.equals("")) {
			return false;
		}
		
		boolean containsDigitsOnly = true;
		for (int i = 0; i < id.length(); i++) {
			if (!Character.isDigit(id.charAt(i))) {
				containsDigitsOnly = false;
				break;
			}
		}
		
		return id.length() == 13 && containsDigitsOnly;
	}
	
	/**
	 * Registracija korisnika
	 */
	public static void register() {
		String firstName;
		do {
			System.out.print("First Name: ");
			firstName = scanner.nextLine();
		} while (!isFirstNameValid(firstName));
		firstNames.add(firstName);
		
		String lastName;
		do {
			System.out.print("Last Name: ");
			lastName = scanner.nextLine();
		} while (!isLastNameValid(lastName));
		lastNames.add(lastName);
		
		String username;
		do {
			System.out.print("Username: ");
			username = scanner.nextLine();
		} while (!isUsernameValid(username));
		usernames.add(username);

		String password;
		do {
			System.out.print("Password: ");
			password = scanner.nextLine();
		} while (!isPasswordValid(password));
		passwords.add(password);
		
		String email;
		do {
			System.out.print("E-mail: ");
			email = scanner.nextLine();
		} while (!isEmailValid(email));
		emails.add(email);
		
		String id;
		do {
			System.out.print("ID: ");
			id = scanner.nextLine();
		} while (!isIDValid(id));
		ids.add(id);
	}
	
	/**
	 * Prikaz svih korisnika
	 */
	public static void list() {
		
		System.out.printf("|  First Name  |     Last Name     |   Username   |   Password   |          E-Mail          |       ID      |\n");
		for (int i = 0; i < usernames.size(); i++) {
			System.out.printf("| %12s | %17s | %12s | %12s | %24s | %13s |\n",
					firstNames.get(i), lastNames.get(i), usernames.get(i),
					passwords.get(i), emails.get(i), ids.get(i));
		}
	}
	
	/**
	 * Prijava korisnika
	 */
	public static void login() {
		System.out.print("Username: ");
		String username = scanner.nextLine();
		System.out.print("Password: ");
		String password = scanner.nextLine();
		
		for (int i = 0; i < usernames.size(); i++) {
			if (usernames.get(i).equals(username) && passwords.get(i).equals(password)) {
				System.out.println("Hello " + firstNames.get(i) + " " + lastNames.get(i) + ".");
				return;
			}
		}
		System.out.println("Wrong username or password.");
	}
	
	/**
	 * Sortiranih korisnika po korisničkom imenu
	 */
	public static void sort() {
	    int n = lastNames.size();
	    int i, j;
	    String firstName, lastName, username, password, email, id;
	    for (i = 0; i < n-1; i++) {
	      for (j = i+1; j < n; j++) {
	        // poredimo svaka dva uzastopna elementa 
	        if (usernames.get(i).compareTo(usernames.get(j)) > 0) { // ako je prvi veci od drugog 
	          // zamenimo ih 
	          firstName = firstNames.get(i);
	          firstNames.set(i, firstNames.get(j));
	          firstNames.set(j, firstName);
	          
	          lastName = lastNames.get(i);
	          lastNames.set(i, lastNames.get(j));
	          lastNames.set(j, lastName);
	          
	          username = usernames.get(i);
	          usernames.set(i, usernames.get(j));
	          usernames.set(j, username);
	          
	          password = passwords.get(i);
	          passwords.set(i, passwords.get(j));
	          passwords.set(j, password);
	          
	          email = emails.get(i);
	          emails.set(i, emails.get(j));
	          emails.set(j, email);
	          
	          id = ids.get(i);
	          ids.set(i, ids.get(j));
	          ids.set(j, id);
	        }
	      }
	    }
	}

	public static void main(String[] args) {
		
		firstNames.add("Marko");
		lastNames.add("Marković");
		usernames.add("marko.markovic");
		passwords.add("1!aAAA");
		emails.add("marko.markovic@gmail.com");
		ids.add("1234567890123");
		
		firstNames.add("Nikola");
		lastNames.add("Nikolić");
		usernames.add("nikola.nikolic");
		passwords.add("1!aAAA");
		emails.add("nikola.nikolic@gmail.com");
		ids.add("1234567890123");
		
		String answer;
		
		do {
			// Prikaz menija
			System.out.println("Menu:");
			System.out.println("1. Register");
			System.out.println("2. List");
			System.out.println("3. Login");
			System.out.println("x. Exit");
			
			answer = scanner.nextLine();
			
			// Poziv izabrane funkcije
			switch (answer) {
			case "1":
				register();
				break;
			case "2":
				sort();
				list();
				break;
			case "3":
				login();
				break;
			case "x":
				break;
			default:
				System.out.println("Wrong option. Please try again.");
			}
			
		} while (!answer.equals("x"));
		
		scanner.close();
	}
}