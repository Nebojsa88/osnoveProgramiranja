package com.ftninformatika.op.biblioteka;

import java.util.ArrayList;
import java.util.Scanner;

public class Biblioteka {

	public static void main(String[] args) {
		
		//Podaci o clanovima
		ArrayList<Integer> clanoviBroj = new ArrayList<Integer>();
		ArrayList<String> clanoviIme = new ArrayList<String>();
		ArrayList<String> clanoviPrezime = new ArrayList<String>();
		
		//Podaci o knjigama
		ArrayList<Integer>  sifreKnjiga = new ArrayList<Integer>();
		ArrayList<String> naziviKnjiga = new ArrayList<String>();
		ArrayList<String> autoriKnjiga = new ArrayList<String>();
		
		//dodajemo nekoliko podataka samo radi testiranja
		
		//Unosimo 2 clana
		clanoviBroj.add(11);
		clanoviIme.add("Marko");
		clanoviPrezime.add("Markovic");
		
		clanoviBroj.add(22);
		clanoviIme.add("Dragana");
		clanoviPrezime.add("Draganic");
		
		//Unosimo 2 knjige
		sifreKnjiga.add(100);
		naziviKnjiga.add("The Old Man and the Sea");
		autoriKnjiga.add("Ernest Hemingway");
		
		sifreKnjiga.add(100);
		naziviKnjiga.add("Nemiri");
		autoriKnjiga.add("Ivo Andric");
		
		Scanner sc = new Scanner(System.in);
		
		//opcija iz menija koju je korisnik odabrao
		String opcija;
		do {
			
			System.out.println("*********** MENI **********");
			System.out.println("1. Unos clana");
			System.out.println("2. Brisanje clana");
			System.out.println("3. Izmena clana");
			System.out.println("4. Prikaz svih clanova");
			System.out.println("5. Pretraga clanova");
			System.out.println("6. Unos knjige");
			System.out.println("7. Brisanje knjige");
			System.out.println("8. Izmena knjige");
			System.out.println("9. Prikaz svih knjiga");
			System.out.println("10. Pretrage knjiga po naslovu");
			System.out.println("11. Pretraga knjiga po autoru");
			System.out.println("x. Izlaz");
			System.out.print("Unesite opciju: ");
			
			opcija = sc.nextLine();
			
			switch (opcija) {
				//unos clana
				case "1" :
					System.out.print("Unesite broj clana: ");
					String brojStr = sc.nextLine();
					int broj = Integer.parseInt(brojStr);
					System.out.print("Unesite ime clana: ");
					String ime = sc.nextLine();
					System.out.print("Unesite prezime clana: ");
					String prezime = sc.nextLine();
					clanoviBroj.add(broj); 
					clanoviIme.add(ime);
					clanoviPrezime.add(prezime);
					System.out.println("Clan je uspesno dodat.");
					break;
				
				//brisanje clana 
				case "2" :
					System.out.print("Unesite broj clana: ");
					brojStr = sc.nextLine();
					broj = Integer.parseInt(brojStr);
					//trazim index clana u listi
					int index = clanoviBroj.indexOf(broj);
					//ako smo ga pronasli
					if(index > -1) {
						clanoviBroj.remove(index);
						clanoviIme.remove(index);
						clanoviPrezime.remove(index);
						System.out.println("Clan uspesno obrisan");
					}
					else
						System.out.println("Ne postoji clan sa navedenim brojem");
				break;
				
				//izmena clana
				case "3" :
					System.out.print("Unesite broj clana: ");
					brojStr = sc.nextLine();
					broj = Integer.parseInt(brojStr);
					//trazim index clana u listi
					index = clanoviBroj.indexOf(broj);
					//ako smo ga pronasli
					if(index > -1) {
						//ako smo ga pronasli
						System.out.print("Unesite novo ime clana: ");
						ime = sc.nextLine();
						System.out.print("Unesite novo prezime clana: ");
						prezime = sc.nextLine();
						
						//menja se ime i prezime, broj nema smilsa menjati
						clanoviIme.set(index, ime);
						clanoviPrezime.set(index, prezime);
						System.out.println("Clan uspesno promenjen");
					}
					else
						System.out.println("Ne postoji clan sa navedenim brojem");
					break;
				
				//prikaz svih clanova
				case "4":
					for (int i = 0; i < clanoviBroj.size(); i++) 
						System.out.printf("%5d %10s %10s \n", clanoviBroj.get(i), clanoviIme.get(i), clanoviPrezime.get(i));
					break;
				
				//prikaz clana sa navedenim brojem
				case "5" :
					System.out.print("Unesite broj clana: ");
					brojStr = sc.nextLine();
					broj = Integer.parseInt(brojStr);
					
					index = clanoviBroj.indexOf(broj);
					//ako smo ga pronasli
					if(index > -1)
						System.out.printf("%5d %10s %10s \n", clanoviBroj.get(index), clanoviIme.get(index), clanoviPrezime.get(index));
					else
						System.out.println("Ne postoji clan sa navedenim brojem");
					break;
				
				//unos knjige	
				case "6" :
					System.out.print("Unesite sifru knjige: ");
					String sifraStr = sc.nextLine();
					int sifra = Integer.parseInt(sifraStr);
					System.out.print("Unesite naziv knjige: ");
					String naziv = sc.nextLine();
					System.out.print("Unesite autore knjige: ");
					String autor = sc.nextLine();
					//dodajemo knjigu
					sifreKnjiga.add(sifra); 
					naziviKnjiga.add(naziv);
					autoriKnjiga.add(autor);
					System.out.println("Knjiga je uspesno dodata.");
					break;
				
				//brisanje knjige
				case "7" :
					System.out.print("Unesite sifru knjige: ");
					sifraStr = sc.nextLine();
					sifra = Integer.parseInt(sifraStr);
					index = sifreKnjiga.indexOf(sifra);

					//ako smo ga pronasli
					if(index > -1) {
						sifreKnjiga.remove(index);
						naziviKnjiga.remove(index);
						autoriKnjiga.remove(index);
						System.out.println("Knjiga je uspesno obrisana");
					}
					else
						System.out.println("Ne postoji knjiga sa navedenom sifrom");
					break;
				
				//izmena knjige
				case "8" :
					System.out.print("Unesite sifru knjige: ");
					sifraStr = sc.nextLine();
					sifra = Integer.parseInt(sifraStr);
					index = sifreKnjiga.indexOf(sifra);
					
					//ako smo ga pronasli
					if(index > -1) {
						//unos novog naziva i autora
						System.out.print("Unesite novi naziv knjige: ");
						naziv = sc.nextLine();
						System.out.print("Unesite novog autora knjige: ");
						autor = sc.nextLine();
						
						//menja se nazi i autor knjige
						naziviKnjiga.set(index, naziv);
						autoriKnjiga.set(index, autor);
						System.out.println("Knjiga uspesno promenjena");
					}
					else
						System.out.println("Ne postoji knjiga sa navedenim brojem");
					break;
				
				//prikaz svih knjiga
				case "9":
					for (int i = 0; i < sifreKnjiga.size(); i++) 
						System.out.printf("%5d %-30s %10s \n", sifreKnjiga.get(i),  naziviKnjiga.get(i), autoriKnjiga.get(i));
					break;
				
				//Pretraga knjige po naslovu
				case "10" :
					System.out.print("Unesite naziv knjige: ");
					naziv = sc.nextLine();
					//indikator da li smo pronasli bar jednu knjigu sa navedenim naslovom
					boolean pronadjen = false;
					
					//pronalazimo index knjige koji se menja;
					for(int i = 0; i < naziviKnjiga.size(); i++) {
						String tekucaKnjiga = naziviKnjiga.get(i);
						//poredimo sa equalsIgnoreCase sto omogucuje da se ne razlikuju velika i mala slova npr: a == a i A == A i a == A
						if(tekucaKnjiga.equalsIgnoreCase(naziv)) {
							System.out.printf("%5d %-30s %10s \n", sifreKnjiga.get(i), naziviKnjiga.get(i), autoriKnjiga.get(i));
							pronadjen = true;
						}
					}
					//ako nema knjige sa navedenim naslovom poruka o tome
					if(!pronadjen)
						System.out.println("Ne postoji knjiga sa navedenim nazivom");
					break;
				
				//Pretraga knjige po autoru
				case "11" :
					System.out.print("Unesite autora knjige: ");
					autor = sc.nextLine();
					pronadjen = false;
					
					//pronalazimo index knjige koji se menja;
					for(int i = 0; i < naziviKnjiga.size(); i++) {
						String tekuciAutor = autoriKnjiga.get(i);
						//poredimo sa equalsIgnoreCase sto omogucuje da se ne razlikuju velika i mala slova npr: a == a i A == A i a == A
						if(tekuciAutor.equalsIgnoreCase(autor)) {
							System.out.printf("%5d %-30s %10s \n", sifreKnjiga.get(i), naziviKnjiga.get(i), autoriKnjiga.get(i));
							pronadjen = true;
						}
					}
					
					//ako nema knjige sa navedenim naslovom poruka o tome
					if(!pronadjen)
						System.out.println("Ne postoji knjiga sa navedenim autorom");
					break;
			}
			
			
		}
		while(!opcija.equals("x"));
		
		sc.close();

	}

}
