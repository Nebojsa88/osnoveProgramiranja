package com.ftninformatika.op.biblioteka;

import java.util.ArrayList;
import java.util.Scanner;

public class Biblioteka2 {
	
	public static void main(String[] args) {
		ArrayList<String> clanskiBrojevi = new ArrayList<String>();
		ArrayList<String> imenaClanova = new ArrayList<String>();
		ArrayList<String> prezimenaClanova = new ArrayList<String>();
		
		ArrayList<Integer> sifreKnjiga = new ArrayList<Integer>();
		ArrayList<String> nasloviKnjiga = new ArrayList<String>();
		ArrayList<String> autoriKnjiga = new ArrayList<String>();
		
		clanskiBrojevi.add("123");
		clanskiBrojevi.add("111");
		clanskiBrojevi.add("222");
		
		imenaClanova.add("Petar");
		imenaClanova.add("Jelena");
		imenaClanova.add("Ivana");
		
		prezimenaClanova.add("Petrovic");
		prezimenaClanova.add("Jelic");
		prezimenaClanova.add("Ivanovic");
		
		sifreKnjiga.add(111);
		sifreKnjiga.add(222);
		sifreKnjiga.add(333);
		sifreKnjiga.add(444);
		
		nasloviKnjiga.add("Naslov 1");
		nasloviKnjiga.add("Naslov 2");
		nasloviKnjiga.add("Naslov 3");
		nasloviKnjiga.add("Naslov 4");
		
		
		autoriKnjiga.add("Petar Petrovic");
		autoriKnjiga.add("Jelena Jelic");
		autoriKnjiga.add("Ivana Ivanovic");
		autoriKnjiga.add("Ivana Markovic");
		
		
		Scanner sc = new Scanner(System.in);
		
		String opcija;
		
		//vrtimo se u petlji, dok korisnik nece da zavrsi program
		do {
			//prikazuje opcije menija
			System.out.println("********** MENI **************");
			System.out.println("1. Prikaz clanova");
			System.out.println("2. Dodavanje clanova");
			System.out.println("3. Izmena clanova");
			System.out.println("4. Brisanje clanova");
			System.out.println("5. Pretraga po clanskom broju");
			System.out.println("6. Prikaz knjiga");
			System.out.println("7. Dodavanje knjiga");
			System.out.println("8. Izmena knjiga");
			System.out.println("9. Brisanje knjige");
			System.out.println("10. Pretraga knjiga po naslovu");
			System.out.println("11. Pretraga knjiga po autoru");
			System.out.println("x. Kraj");
			System.out.println();
			System.out.println("Opcija: ");
			
			//od korisnika se ucitava opcija
			opcija = sc.nextLine();
			
			//zavisno od opcije izvrsi se neka funkcionalnost
			switch (opcija) {
				case "1":
					for(int i = 0; i < imenaClanova.size(); i++)
						System.out.printf("%10s %10s %10s \n", clanskiBrojevi.get(i), imenaClanova.get(i), prezimenaClanova.get(i));
					break;
				case "2":
					System.out.print("Unesite clanski broj: ");
					String clanskiBroj = sc.nextLine();
					System.out.print("Unesite ime clana: ");
					String ime = sc.nextLine();
					System.out.print("Unesite prezime clana: ");
					String prezime = sc.nextLine();
					
					//unete podetke dodajemo u odgovarajuce liste (na kraj liste)
					clanskiBrojevi.add(clanskiBroj);
					imenaClanova.add(ime);
					prezimenaClanova.add(prezime);
					System.out.println("Clan je uspesno upisan.");
					break;
				case "3":
					System.out.print("Unesite broj clna: ");
					clanskiBroj = sc.nextLine();
					
					//trazimo poziciju studenta u listi
					int pozicija = clanskiBrojevi.indexOf(clanskiBroj);
					//ako postoji student sa tim brojem indeksa
					//onda unosimo novo ime i prezime
					if(pozicija > -1) {
						System.out.print("Unesite novo ime clana: ");
						String novoIme = sc.nextLine();
						System.out.print("Unesite novo prezime clana: ");
						String novoPrezime = sc.nextLine();
						
						//azuriramo podatke na odgovovarajucoj poziciji u nizu
						imenaClanova.set(pozicija, novoIme);
						prezimenaClanova.set(pozicija, novoPrezime);
						
						System.out.println("Clan je uspesno promenjen.");
					}
					else
						System.out.println("Clan sa unesenim brojem ne postoji.");
					
					break;
				case "4":
					System.out.print("Unesite broj clana: ");
					clanskiBroj = sc.nextLine();
					
					pozicija = clanskiBrojevi.indexOf(clanskiBroj);
					//ako postoji student sa tim brojem indeksa
					if(pozicija != -1) {
						clanskiBrojevi.remove(pozicija);
						imenaClanova.remove(pozicija);
						prezimenaClanova.remove(pozicija);
						System.out.println("Clan je uspesno obrisan.");
					}
					else
						System.out.println("Clan sa unesenim brojem ne postoji.");
					
					break;
				case "5":
					System.out.print("Unesite broj clana: ");
					clanskiBroj = sc.nextLine();
					
					pozicija = clanskiBrojevi.indexOf(clanskiBroj);
					//ako postoji student sa tim brojem indeksa
					if(pozicija != -1) {
						System.out.printf("%10s %10s %10s \n", clanskiBrojevi.get(pozicija), imenaClanova.get(pozicija), prezimenaClanova.get(pozicija));
					}
					else
						System.out.println("Clan sa unesenim brojem ne postoji.");
					break;
				case "6":
					for(int i = 0; i < sifreKnjiga.size(); i++)
						System.out.printf("%10d %10s %10s \n", sifreKnjiga.get(i), nasloviKnjiga.get(i), autoriKnjiga.get(i));
					break;
				case "7":
					System.out.print("Unesite sifra knjige: ");
					int sifraKnjige = Integer.parseInt(sc.nextLine());
					System.out.print("Unesite naslov knjige: ");
					String naslov = sc.nextLine();
					System.out.print("Unesite autora knjige: ");
					String autor = sc.nextLine();
					
					//unete podetke dodajemo u odgovarajuce liste (na kraj liste)
					sifreKnjiga.add(sifraKnjige);
					nasloviKnjiga.add(naslov);
					autoriKnjiga.add(autor);
					System.out.println("Knjiga je uspesno upisana.");
					break;
				case "8":
					System.out.print("Unesite sifru knjige: ");
					sifraKnjige = Integer.parseInt(sc.nextLine());
					
					//trazimo poziciju studenta u listi
					pozicija = sifreKnjiga.indexOf(sifraKnjige);
					//ako postoji student sa tim brojem indeksa
					//onda unosimo novo ime i prezime
					if(pozicija > -1) {
						System.out.print("Unesite novi naslov knjige: ");
						String noviNaslov = sc.nextLine();
						System.out.print("Unesite novog autora knjige: ");
						String noviAutor = sc.nextLine();
						
						//azuriramo podatke na odgovovarajucoj poziciji u nizu
						nasloviKnjiga.set(pozicija, noviNaslov);
						autoriKnjiga.set(pozicija, noviAutor);
						
						System.out.println("Knjiga je uspesno promenjena.");
					}
					else
						System.out.println("KNjiga sa unetom sifrom ne postoji.");
					
					break;
				case "9":
					System.out.print("Unesite sifru knjige: ");
					sifraKnjige = Integer.parseInt(sc.nextLine());
					
					//trazimo poziciju studenta u listi
					pozicija = sifreKnjiga.indexOf(sifraKnjige);
					//ako postoji student sa tim brojem indeksa
					if(pozicija > -1) {
						sifreKnjiga.remove(pozicija);
						nasloviKnjiga.remove(pozicija);
						autoriKnjiga.remove(pozicija);
						System.out.println("Knjiga je uspesno obrisan.");
					}
					else
						System.out.println("Knjiga sa unesenom sifrom ne postoji.");
					
					break;
				case "10":
					System.out.print("Unesite novi naslov knjige: ");
					String naslovPretraga = sc.nextLine();
					for(int i = 0; i < nasloviKnjiga.size(); i++) {
						if(nasloviKnjiga.get(i).equalsIgnoreCase(naslovPretraga))
							System.out.printf("%10d %10s %10s \n", sifreKnjiga.get(i), nasloviKnjiga.get(i), autoriKnjiga.get(i));
					}
					break;
				case "11":
					System.out.print("Unesite autora knjige: ");
					String autorPretraga = sc.nextLine();
					for(int i = 0; i < nasloviKnjiga.size(); i++) {
						if(autoriKnjiga.get(i).equalsIgnoreCase(autorPretraga))
							System.out.printf("%10d %10s %10s \n", sifreKnjiga.get(i), nasloviKnjiga.get(i), autoriKnjiga.get(i));
					}
					break;
				
			}
		
		//u petlji se vrtimo sve dok se ne odabere opcija x
		} while(!opcija.equals("x"));
			
		sc.close();
	}

}
