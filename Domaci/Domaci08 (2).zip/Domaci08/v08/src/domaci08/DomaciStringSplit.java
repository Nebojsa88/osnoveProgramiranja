package domaci08;

public class DomaciStringSplit {
	/*
	public static ArrayList<Integer> clanoviBroj = new ArrayList<Integer>();
	public static ArrayList<String> clanoviIme = new ArrayList<String>();
	 */
	
	public static void main(String[] args) {
		//Cilj je izdvajanje članskog broja i imena i njihovo
		//dodavanje u kolekcije clanoviBroj i clanoviIme
		String podatak = "325;   NIKOLA  \n";
		//Uklanjamo nepotrebne razmake metodom replace
		//zamenjujemo space praznim stringom
		podatak = podatak.replace(" ", "");
		System.out.println(podatak);
		
		//Uklanjamo \n karakter sa kraja stringa
		//Pronalazimo podstring stringa koji ne sadrži poslednji karakter
		//Mogli smo i da koristimo metodu replace -> podaci.replace("\n", "")
		String podatakBezNewLine = podatak.substring(0, podatak.length()-1);
		//podatak = "325;NIKOLA"
		//Razdvajamo string na 2 stringa, prvi sadrži čl.broj, drugi ime
		String[] splits = podatakBezNewLine.split(";");
		//splits = ["325", "NIKOLA"]
		
		String brojStr = splits[0];
		//Čl. broj je string pa ga pretvaramo u int
		int broj = Integer.parseInt(brojStr);
		System.out.println("Članski broj: " + broj);
		
		//Ime je napisano velikim slovima
		//Želimo da sva slova smanjimo, a da prvo ostane veliko
		String imeVelikaSlova = splits[1];
		//Izdvajamo prvo slovo imena (njega ne pretvaramo u malo)
		char prvoSlovoImena = imeVelikaSlova.charAt(0);
		//Izdvajamo ostala slova imena metodom substring
		String ostalaSlovaImena = imeVelikaSlova.substring(1);
		//Pretvaramo ih u mala slova
		String ostalaSlovaImenaMalimSlovima = ostalaSlovaImena.toLowerCase();
		//Ime dobijamo spajanjem prvog slova imena sa smanjenim ostalim slovima
		String ime = prvoSlovoImena + ostalaSlovaImenaMalimSlovima;
		System.out.println("Ime: " + ime);
		
		/*
		//Dodavali bismo izdvojene podatke u odgovarajuće kolekcije...
		clanoviBroj.add(broj);
		clanoviIme.add(ime);
		*/
		
	}
}
