package artikal;

public class Test {
	public static void main(String[] args) {
		
		Artikal artikal1 = new Artikal("Jastuk", 1800.00, 0.2);
		System.out.println("Konačna cena za artikal: " + artikal1.naziv + " je " + artikal1.izracunajKonacnuCenu());
		System.out.println("Cena sa popustom za artikal: " + artikal1.naziv + " je " + artikal1.izracunajCenuSaPopustom(0.2));

		System.out.println(artikal1);
	}
}
