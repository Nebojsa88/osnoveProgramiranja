package artikal;

public class Artikal {

	String naziv;
	double osnovnaCena;
	double porez;
	
	Artikal() {
		
	}

	Artikal(String naziv, double osnovnaCena, double porez) {
		this.naziv = naziv;
		this.osnovnaCena = osnovnaCena;
		this.porez = porez;
	}

	double izracunajKonacnuCenu() {
		
		double konacnaCena = osnovnaCena + osnovnaCena * porez;
		return konacnaCena;
	}
	
	double izracunajCenuSaPopustom(double popust) {
		
		double novaCena = 0;
		novaCena = izracunajKonacnuCenu() - izracunajKonacnuCenu()*popust;
		return novaCena;
	}
}
