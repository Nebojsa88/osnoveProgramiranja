package com.ftninformatika.biblioteka;

/**
 * Klasa modeluje knjigu.
 * @author Bojana/Milan
 *
 */
public class Knjiga {

	private int broj;
	private String ime;
	private String autor;
	private boolean izdata;

	//konstruktor bez parametara
	public Knjiga() {

	}

	//konstruktor sa parametrima
	public Knjiga(int broj, String ime, String autor, boolean izdata) {
		this.broj = broj;
		this.ime = ime;
		this.autor = autor;
		this.izdata = izdata;
	}

	public int getBroj() {
		return broj;
	}



	public void setBroj(int broj) {
		this.broj = broj;
	}



	public String getIme() {
		return ime;
	}



	public void setIme(String ime) {
		this.ime = ime;
	}



	public boolean isIzdata() {
		return izdata;
	}



	public void setIzdata(boolean izdata) {
		this.izdata = izdata;
	}



	public String getAutor() {
		return autor;
	}

	public void setAutor(String autor) {
		this.autor = autor;
	}

	public String toString() {
		return this.broj + " " + this.ime + " " + this.autor + " " + (this.izdata ? "knjiga je izdata" : "knjiga nije izdata")+ "\n";
	}

}
