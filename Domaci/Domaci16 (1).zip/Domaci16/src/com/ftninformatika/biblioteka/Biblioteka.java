package com.ftninformatika.biblioteka;
import java.util.ArrayList;

/**
 * Klasa modeluje biblioteku.
 * @author Bojana/Milan
 *
 */
public class Biblioteka {

	private String naziv;
	private String adresa;
	private ArrayList<Knjiga> lista;
	
	//konstruktor bez parametara
	public Biblioteka() {
		this.lista = new ArrayList<Knjiga>();
	}
	
	
	public Biblioteka(String naziv, String adresa) {
		this.naziv = naziv;
		this.adresa = adresa;
		this.lista = new ArrayList<>();
	}
	
	

	public String getNaziv() {
		return naziv;
	}


	public void setNaziv(String naziv) {
		this.naziv = naziv;
	}


	public String getAdresa() {
		return adresa;
	}


	public void setAdresa(String adresa) {
		this.adresa = adresa;
	}


	public ArrayList<Knjiga> getLista() {
		return lista;
	}


	public void setLista(ArrayList<Knjiga> lista) {
		this.lista = lista;
	}

	/**
	 * Metoda dodajKnjigu dodaje prosleđeni objekat Knjiga u listu knjiga.
	 * @param k
	 * @return
	 */
	public boolean dodajKnjigu(Knjiga k) {
		
		for (int i = 0; i < this.lista.size(); i++) {
			if ((this.lista.get(i)).getBroj() == k.getBroj()) {
				return false;
			}
		}
		//Knjiga novaKnjiga = new Knjiga(k.getBroj(), k.getIme(), k.getAutor(), k.isIzdata());
		this.lista.add(k);
		return true;
	}
	
	/**
	 * Metoda obrisiKnjigu briše knjigu sa prosleđenim identifikacionim brojem iz liste knjiga.
	 * @param broj
	 * @return
	 */
	public Knjiga obrisiKnjigu(int broj) {
		
		int indeks = -17;
		for (int i = 0; i < this.lista.size(); i++) {
			if (((this.lista.get(i)).getBroj() == broj)) {
				indeks = i;
				break;
			}
		}
		if(indeks != -17) {
			return this.lista.remove(indeks);
		}
		System.out.println("Knjiga sa brojem " + broj + " ne postoji.");
		return null;
	}
	
	/**
	 * Metoda ukupnoKnjiga vraća ukupan broj knjiga u listi.
	 * @return
	 */
	public int ukupnoKnjiga() {
		
		return this.lista.size();
	}
	
	/**
	 * Metoda izdato vraća ukupan broj knjiga koje su izdate.
	 * @return
	 */
	public int izdato() {
		
		int broj = 0;
		for (int i = 0; i < this.lista.size(); i++) {
			if ((this.lista.get(i)).isIzdata()) {
				broj++;
			}
		}
		return broj;
	}
	
	/**
	 * Metoda nijeIzdato vraća ukupan broj knjiga koje nisu izdate.
	 * @return
	 */
	public int nijeIzdato() {
		
		/*int broj = 0;
		for (int i = 0; i < lista.size(); i++) {
			if (!(this.lista.get(i)).isIzdata()) {
				broj++;
			}
		}
		return broj;*/
		return this.lista.size() - izdato();
	}
	
	/**
	 * Metoda sortira knjige po broju u rastućem redosledu.
	 */
	public void sortiraj() {
		
		for(int i = 0; i < this.lista.size()-1; i++) {
			for(int j = i+1; j < this.lista.size(); j++) {
				if((this.lista.get(i)).getBroj() > (this.lista.get(j)).getBroj()){
					/*
					Nema smisla ovo raditi! Čak ni ne vršimo zamenu elemenata
					već zamenjujemo vrednosti svakog atributa, dok celi elementi ostaju na istoj poziciji.
					int broj = (this.lista.get(i)).getBroj();
					String ime = (this.lista.get(i)).getIme();
					String autor = (this.lista.get(i)).getAutor();
					boolean izdato =(this.lista.get(i)).isIzdata();
					(this.lista.get(i)).setBroj((this.lista.get(j)).getBroj());
					(this.lista.get(j)).setBroj(broj);
					(this.lista.get(i)).setIme((this.lista.get(j)).getIme());
					(lista.get(j)).setIme(ime);
					(this.lista.get(i)).setAutor(this.lista.get(j).getAutor());
					(this.lista.get(j)).setAutor(autor);
					(this.lista.get(i)).setIzdata((this.lista.get(j)).isIzdata());
					(this.lista.get(j)).setIzdata(izdato);*/
					Knjiga temp = this.lista.get(i);
					this.lista.set(i, this.lista.get(j));
					this.lista.set(j, temp);
					
				}
			}
		}
	}
	
	public ArrayList<Knjiga> vratiKnjigePoAutoru(String autor) {

		ArrayList<Knjiga> listaKnjiga = new ArrayList<Knjiga>();
		for(int i = 0; i < this.lista.size(); i++) {
			if (this.lista.get(i).getAutor().equals(autor)) {
				listaKnjiga.add(this.lista.get(i));
				System.out.println(this.lista.get(i));
			}
		}
		return listaKnjiga;
	}
	
	public String toString() {
		
		StringBuilder sb = new StringBuilder();
		sb.append("Naziv biblioteke: " + this.naziv + "\n");
		sb.append("Adresa biblioteke: " + this.adresa + "\n");
		for(int i = 0; i < this.lista.size(); i++)
			sb.append(this.lista.get(i));
		return sb.toString().trim();
	}
	
	/*public String toString() {
		
		String temp = "";
		temp += "Naziv biblioteke: " + this.naziv + "\n";
		temp += "Adresa biblioteke: " + this.adresa + "\n";
		for(int i = 0; i < lista.size(); i++)
			temp += (lista.get(i));
		return temp;
	}*/
	


}
