package com.posta; 

public class Posta {

	public static void main(String[] args) {
		//sledece 4 verijable se definisu i odmah im se dodeli neka vrednost
		String nazivPosiljaoca = "Goran Sladic";
		String adresaPosiljaoca = "Fruskogorska 11";
		boolean preporuceno = false;
		double tezina = 0.5;
		//a moze i drugacije:
		
		//sledece dve varijable se prvo definisu
		String nazivPrimaoca;
		String adresaPrimaoca;
		
		//pa im se onda naknadno dodeli vrednost
		nazivPrimaoca = "FTN Novi Sad";
		adresaPrimaoca = "Trg D. Obradovica 6.";
		
		//Ispis podataka o primaocu i posiljaocu
		//Jako dugacko pa se moze razbiti u vise reodva (ispis ce i dalje biti u jednom redu)
		//Obratite paznju u prvom redu System.out.println nema na kraju ;
		//to je zato jer se naredba nastavlja u drugom redu
		System.out.println("Posiljac " + nazivPosiljaoca + " " + adresaPosiljaoca  + 
						   " salje paket primaocu " + nazivPrimaoca + " " + adresaPrimaoca);

		//Ispis podataka o tezini paketa
		System.out.println("Tezina paketa je " + tezina + ".");
		//Da li se paket salje preporuceno ili ne.
		System.out.println("Poslati preporuceno: " + preporuceno);
		
	}

}
