package domaci07;

public class Domaci02 {

	// Definicija funkcije koja proverava da li je broj neparan
	public static boolean odd(int n) {
		// Broj je neparan ako pri deljenju da 2 daje ostatak 1
		if (n % 2 == 1) {
			return true;
		} else {
			return false;
		}
		
		//Ili kraće
		//return n % 2 == 1;
	}
	
	public static void main(String[] args) {
		// Pozivi funkcije koja proverava da li je broj neparan	
		System.out.println(odd(1));
		System.out.println(odd(2));	
	}	
}
