package domaci07;

public class Domaci03 {

	// Definicija funkcije koja vraća poslednju cifru broja
	public static int digit(int n) {
		// Poslednja cifra broja je ostatak pri deljenju broja sa 10
		return n % 10;
	}
	
	public static void main(String[] args) {
		// Pozivi funkcije koja vraća poslednju cifru broja	
		System.out.println(digit(1));
		System.out.println(digit(12));
		System.out.println(digit(123));	
	}	
}
