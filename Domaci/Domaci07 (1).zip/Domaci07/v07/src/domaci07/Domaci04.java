package domaci07;

public class Domaci04 {

	// Definicija funkcije koja proverava da li je godina prestupna
	public static boolean leap(int year) {
		// Godina je prestupna ako je deljiva sa 400
		if (year % 400 == 0) {
			return true;
		// Inače nije prestupna ako je deljiva sa 100
		} else if (year % 100 == 0) {
			return false;
		// Inače je prestupna ako je deljiva sa 4
		} else if (year % 4 == 0) {
			return true;
		// Inače nije prestupna
		} else {
			return false;
		}
	}
	
	public static void main(String[] args) {
		// Pozivi funkcije koja proverava da li je godina prestupna
		System.out.println(leap(1900));
		System.out.println(leap(1996));
		System.out.println(leap(1999));
		System.out.println(leap(2000));
	}	
}
