package domaci07;

import java.util.ArrayList;

public class Domaci01 {

	// Definicija funkcije koja vraća minimalni element liste
	public static int min(ArrayList<Integer> list1) {
		// Pretpostavi da je prvi element liste minimalni element
		int min = list1.get(0);
		
		// Prođi kroz listu
		for (int i = 1; i < list1.size(); i++) {
			// Ako je tekući element liste manji od minimalnog, onda je on minimalni element
			if (list1.get(i) < min) {
				min = list1.get(i);
			}
		}
		
		return min;
	}
	
	// Definicija funkcije koja vraća maksimalni element liste
	public static int max(ArrayList<Integer> list) {
		int max = list.get(0);
		
		for (int i = 1; i < list.size(); i++) {
			if (list.get(i) > max) {
				max = list.get(i);
			}
		}
		
		return max;
	}
	
	// Definicija funkcije koja vraća sumu elemenata liste
	public static int sum(ArrayList<Integer> list) {
		// Početna vrednost akumulatora je 0
		int sum = 0;
		
		// Prođi kroz listu
		for (int i = 0; i < list.size(); i++) {
			// Ikrementiraj akumulator za tekući element
			sum += list.get(i);
		}
		
		return sum;
	}
	
	// Definicija funkcije koja vraća prosek elemenata liste
	public static double avg(ArrayList<Integer> list) {
		// Za računanje proseka može se iskoristiti suma
		return (double)sum(list) / list.size();
	}
	
	public static void main(String[] args) {
		// Inicijalizacija liste
		ArrayList<Integer> list = new ArrayList<Integer>();
		list.add(3);
		list.add(7);
		list.add(5);
		list.add(1);
		list.add(10);
		
		// Poziv funkcije koja vraća minimalni element liste
		int minimum = min(list);
		System.out.println(minimum);
	
		// Poziv funkcije koja vraća maksimalni element liste
		System.out.println(max(list));
		// Poziv funkcije koja vraća sumu elemenata liste
		System.out.println(sum(list));
		// Poziv funkcije koja vraća prosek elemenata liste
		System.out.println(avg(list));	
	}	
}
