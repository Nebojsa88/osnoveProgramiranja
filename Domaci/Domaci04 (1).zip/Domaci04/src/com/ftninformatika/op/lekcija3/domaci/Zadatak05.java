package com.ftninformatika.op.lekcija3.domaci;

import java.util.ArrayList;

public class Zadatak05 {
	
	

	public static void main(String[] args) {
		ArrayList<Double> lista = new ArrayList<Double>();
		lista.add(3.0);
		lista.add(5.3);
		lista.add(7.344);
		lista.add(9.11);
		lista.add(11.9);
		lista.add(-12.89);
		lista.add(5.3);
		lista.add(4.1); 
		
		//inicijalno stavimo da je 1. element liste nanajmanjijveci
		double najmanji = lista.get(0);

		//idemo kroz ostale elemente, i ide od 1.
		for (int i = 1; i < lista.size(); i++) {
			//poredimo element na i-toj poziciji
			//sa prethodnim najmanjim
			//ako je on manji od prethodnog najmanjeg onda njega stavimo za najmanjeg
		    if (najmanji > lista.get(i)) {
		    		najmanji = lista.get(i);
		    }
		}
		
		System.out.println("Najmanji element: " + najmanji);
	}

}
