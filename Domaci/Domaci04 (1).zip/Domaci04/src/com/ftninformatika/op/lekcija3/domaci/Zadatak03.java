package com.ftninformatika.op.lekcija3.domaci;

import java.util.ArrayList;

public class Zadatak03 {
	
	

	public static void main(String[] args) {
		ArrayList<Integer> lista = new ArrayList<Integer>();
		lista.add(3);
		lista.add(5);
		lista.add(7);
		lista.add(9);
		lista.add(11);
		lista.add(12);
		lista.add(5);
		lista.add(4);
		
		
		int brojPetica = 0;
		
		//prolazimo kroz listu i brojimo petice
		for(int i = 0; i < lista.size(); i++) {
			if(lista.get(i) == 5)
				brojPetica++;
		}
		System.out.println("U listi ima " + brojPetica + " elemenata sa vrednoscu 5");

	}

}
