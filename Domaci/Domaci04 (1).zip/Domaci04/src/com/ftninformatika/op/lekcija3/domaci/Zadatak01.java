package com.ftninformatika.op.lekcija3.domaci;

import java.util.ArrayList;

public class Zadatak01 {
	
	

	public static void main(String[] args) {
		ArrayList<Integer> lista = new ArrayList<Integer>();
		lista.add(3);
		lista.add(5);
		lista.add(7);
		lista.add(9);
		lista.add(11);
		lista.add(12);
		lista.add(4);
		
		//sadrzace sumu elemenata
		int sum = 0;
		//sadrzce srednju vrednost
		double srVred;
		
		//racunamo sumu elemenata
		for(int i = 0; i < lista.size(); i++) {
			sum += lista.get(i);
		}
		
		//racuna se srednja vrednost
		//suma se mora castovati u double pre deljenja da deljenje ne bi bilo celobrojno
		srVred =  (double)sum/lista.size();
		System.out.println("Srednja vrednost je: " + srVred);

	}

}
