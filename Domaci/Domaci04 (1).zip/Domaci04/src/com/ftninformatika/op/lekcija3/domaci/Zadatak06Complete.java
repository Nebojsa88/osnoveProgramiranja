package com.ftninformatika.op.lekcija3.domaci;

import java.util.ArrayList;

public class Zadatak06Complete {
	
	

	public static void main(String[] args) {
		ArrayList<String> imena = new ArrayList<String>();
		ArrayList<String> prezimena = new ArrayList<String>();
		ArrayList<Integer> prisustvo = new ArrayList<Integer>();
		
		//Dodajemo sve podatke 1. polaznika na poziciju 0
		imena.add("Petar");
		prezimena.add("Petrovic");
		prisustvo.add(0);
		
		//Dodajemo sve podatke 2. polaznika na poziciju 1
		imena.add("Marko");
		prezimena.add("Markovic");
		prisustvo.add(0);
		
		//Dodajemo sve podatke 3. polaznika na poziciju 2
		imena.add("Ivana");
		prezimena.add("Ivanovic");
		prisustvo.add(0);
		
		//Dodajemo sve podatke 4. polaznika na poziciju 3
		imena.add("Jelena");
		prezimena.add("Jelic");
		prisustvo.add(0);
		
		//Dodajemo sve podatke 5. polaznika na poziciju 4
		imena.add("Tijana");
		prezimena.add("Tijanic");
		prisustvo.add(0);
		
		//Dodajemo sve podatke 6. polaznika na poziciju 5
		imena.add("Dragan");
		prezimena.add("Dragovic");
		prisustvo.add(0);
		
		System.out.println("-----------------------PRIKAZ SVIH POLAZNIKA---------------------------");
		//PRIKAZ SVIH POLAZNIKA
		for(int i = 0; i < imena.size(); i++) {
			System.out.println(imena.get(i) + " " + prezimena.get(i) + " " + prisustvo.get(i));
		}
		
		
		//BRISANJE NA OSNOVU POZICIJE
		int indexZaBrisanje = 4; //Brise se Tijana Tijanic
		//MORAMO obrisati sve 3 liste
		imena.remove(indexZaBrisanje);
		prezimena.remove(indexZaBrisanje);
		prisustvo.remove(indexZaBrisanje);
		
		System.out.println("-----------------------PRIKAZ SVIH POLAZNIKA NAKON BRISNJA NA POZICIJI 4---------------------------");
		//PRIKAZ SVIH POLAZNIKA
		for(int i = 0; i < imena.size(); i++) {
			System.out.println(imena.get(i) + " " + prezimena.get(i) + " " + prisustvo.get(i));
		}
		
		//BRISANJE NA OSNOVU IMENA I PREZIMENA
		int indexBrisi = -1;
		//Trazimo osobu koja se zove kako nama treba
		String imeBrisi = "Marko";
		String prezimeBrisi = "Markovic";
		for(int i = 0; i < imena.size(); i++) {
			//Ako smo pronasli, stavimo da je indexBrisi i-ta pozicija
			//I moze break jer ne treba vise da prolazimo kroz listu, tj. zavrsavamo for petlju
			if(imena.get(i).equals(imeBrisi) && prezimena.get(i).equals(prezimeBrisi)) {
				indexBrisi = i;
				break;
			}
		}
		//Ako je index > -1 to znaci da smo pronasli element koji brisemo pa mozemo pristputi brisanju
		if(indexBrisi > -1) {
			imena.remove(indexBrisi);
			prezimena.remove(indexBrisi);
			prisustvo.remove(indexBrisi);
		}
		
		System.out.println("-----------------------PRIKAZ SVIH POLAZNIKA NAKON BRISNJA Marko Markovic---------------------------");
		//PRIKAZ SVIH POLAZNIKA
		for(int i = 0; i < imena.size(); i++) {
			System.out.println(imena.get(i) + " " + prezimena.get(i) + " " + prisustvo.get(i));
		}
		
		//UVECANJE PRISUSTVA ZA POLAZNIKA
		//BRISANJE NA OSNOVU IMENA I PREZIMENA
		int indexUvecaj = -1;
		//Trazimo osobu koja se zove kako nama treba
		String imeUvecaj = "Jelena";
		String prezimeUvecaj = "Jelic";
		for(int i = 0; i < imena.size(); i++) {
			//Ako smo pronasli, stavimo da je indexUvecaj i-ta pozicija
			//I moze break jer ne treba vise da prolazimo kroz listu, tj. zavrsavamo for petlju
			if(imena.get(i).equals(imeUvecaj) && prezimena.get(i).equals(prezimeUvecaj)) {
				indexUvecaj = i;
				break;
			}
		}
		
		//Ako je index > -1 to znaci da smo pronasli element koji uvecavamo za 1
		if(indexUvecaj > -1) {
			//stari broj prisustva
			int brojPrisustva = prisustvo.get(indexUvecaj);
			//uvecamo za 1
			brojPrisustva++;
			//azuriramo listu
			prisustvo.set(indexUvecaj, brojPrisustva);
		}
		
		System.out.println("-----------------------PRIKAZ SVIH POLAZNIKA NAKON UVECANJA PRISUSTVA ZA Jelena Jelic---------------------------");
		
		//PRIKAZ SVIH POLAZNIKA
		for(int i = 0; i < imena.size(); i++) {
			System.out.println(imena.get(i) + " " + prezimena.get(i) + " " + prisustvo.get(i));
		}
		
		
		
	}

}
