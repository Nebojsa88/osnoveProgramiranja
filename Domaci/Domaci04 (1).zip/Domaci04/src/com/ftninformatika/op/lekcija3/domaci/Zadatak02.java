package com.ftninformatika.op.lekcija3.domaci;

import java.util.ArrayList;

public class Zadatak02 {
	
	

	public static void main(String[] args) {
		ArrayList<Integer> lista = new ArrayList<Integer>();
		lista.add(3);
		lista.add(5);
		lista.add(7);
		lista.add(9);
		lista.add(11);
		lista.add(12);
		lista.add(5);
		lista.add(4);
		
		boolean postoji5 = lista.contains(5);
		//moze i ovako
		//boolean postoji5 = lista.indexOf(5) > -1;
		
		System.out.println("Postoji broj 5: " + postoji5);
		//malo lepsi ispis
		System.out.println("Postoji broj 5: " + (postoji5 ? "DA" : "NE"));
		//druga varijanta
		if(postoji5)
			System.out.println("Broj 5 postoji");
		else
			System.out.println("Broj 5 ne postoji");
		
	}

}
