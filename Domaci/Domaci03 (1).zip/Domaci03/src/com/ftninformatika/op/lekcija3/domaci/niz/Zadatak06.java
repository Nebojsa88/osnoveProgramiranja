package com.ftninformatika.op.lekcija3.domaci.niz;

public class Zadatak06 {
	
	

	public static void main(String[] args) {
		double niz[] =  {3.5, -55.0, 7.9, 15.3, 3.9}; 
		
		//inicijalno stavimo da je 1. element niza najveci
		double najmanji = niz[0];
		
		//idemo kroz ostale elemente, i ide od 1.
		for (int i = 1; i < niz.length; i++) {
			//poredimo element na i-toj poziciji 
			//sa prethodnim najmanjim
			//ako je on manji od prethodnog najmanjeg onda njega stavimo za najmanjeg
		    if (najmanji > niz[i]) {
		    		najmanji = niz[i];
		    }
		}
		
		
		System.out.println("Najmanji element: " + najmanji);
	}

}
