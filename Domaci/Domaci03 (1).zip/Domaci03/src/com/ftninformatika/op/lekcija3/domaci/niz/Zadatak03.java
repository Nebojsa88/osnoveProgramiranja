package com.ftninformatika.op.lekcija3.domaci.niz;

public class Zadatak03 {
	
	

	public static void main(String[] args) {
		int niz[] =  {3, 15, 7, 9, 11, 12, 5}; 
		
		//Inicijalno pretpostavimo da br 5. ne postoji
		boolean postoji5 = false;
		
		//proveravamo da li broj postoji,
		//prolazimo kroz sve elemente niza
		for(int i = 0; i < niz.length; i++)
			//Ako broj postoji stavicemo
			//indikator da postoji
			//i vise nema potrebe da proveravamo pa pozovemo break (prekida ostatka iteracija u for petlji)
			if(niz[i] == 5) {
				postoji5 = true;
				break;
			}
		
		
		System.out.println("Postoji broj 5: " + postoji5);
		//malo lepsi ispis
		System.out.println("Postoji broj 5: " + (postoji5 ? "DA" : "NE"));
		//druga varijanta
		if(postoji5)
			System.out.println("Broj 5 postoji");
		else
			System.out.println("Broj 5 ne postoji");

	}

}
