package com.ftninformatika.op.lekcija3.domaci.niz;

public class Zadatak01 {

	public static void main(String[] args) {
		
		for(int i = 1; i <= 20; i++) {
			if(i % 3 == 0) {
				System.out.println(i);
			}
		}
		

	}

}
