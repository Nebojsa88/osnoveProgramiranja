package com.ftninformatika.op.lekcija3.domaci.niz;

public class Zadatak05 {
	
	

	public static void main(String[] args) {
		double niz[] =  {3.5, -55.0, 7.9, 15.3, 3.9}; 
		
		//inicijalno stavimo da je 1. element niza najveci
		double najveci = niz[0];

		//idemo kroz ostale elemente, i ide od 1.
		for (int i = 1; i < niz.length; i++) {
			//poredimo element na i-toj poziciji
			//sa prethodnim najvecim
			//ako je on veci od prethodnog najveceg onda njega stavimo za najveceg
		    if (najveci < niz[i]) {
		    		najveci = niz[i];
		    }
		}
		
		
		System.out.println("Najveci element: " + najveci);
	}

}
