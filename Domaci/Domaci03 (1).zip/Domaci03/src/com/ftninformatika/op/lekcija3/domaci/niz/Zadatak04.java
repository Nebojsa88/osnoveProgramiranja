package com.ftninformatika.op.lekcija3.domaci.niz;

public class Zadatak04 {
	
	

	public static void main(String[] args) {
		int niz[] =  {3, 5, 7, 5, 3}; 
		
		//inicijalno pretpostavimo da je simetrican
		boolean simetrican = true;

		//idemo kroz prvu polovini niza
		for (int i = 0; i < niz.length / 2; i++) {
			//poredimo element na i-toj poziciji prve polovine,
			//sa elementom na "simetricnom indeksu" druge polovine
			//ako ta dva elementa nisu isti znaci da niz nije simetrican,
			//pa onda nema potrebe proveravati ostale, zato ide break
		    if (niz[i] != niz[niz.length - i - 1]) {
		    		simetrican = false;
		        break;
		    }
		}
		
		
		System.out.println("Nizovi simetricni: " + simetrican);
		//malo lepsi ispis
		System.out.println("Nizovi simetricni: " + (simetrican ? "DA" : "NE"));
		//druga varijanta
		if(simetrican)
			System.out.println("Nizovi su simetricni");
		else
			System.out.println("Nizovi nisu simetricni");

	}

}
