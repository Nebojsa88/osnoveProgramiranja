package com.ftninformatika.op.lekcija3.domaci.niz;

public class Zadatak02 {
	
	

	public static void main(String[] args) {
		int niz[] =  {3, 5, 7, 9, 11, 12}; 
		//sadrzace sumu elemenata
		int sum = 0;
		//sadrzce srednju vrednost
		double srVred;
		
		//racunamo sumu elemenata
		for(int i = 0; i < niz.length; i++) 
			sum += niz[i];
		
		//racuna se srednja vrednost
		//suma se mora castovati u double pre deljenja da deljenje ne bi bilo celobrojno
		srVred =  (double)sum/niz.length;
		System.out.println("Srednja vrednost niza je: " + srVred);

	}

}
