package com.ftninformatika.pas;

public class Pas {

	//atributi klase pas
	private String ime;
	private int starost;
	private boolean vakcinisan;
	private String rasa;
	
	//konstruktor bez parametara
	public Pas() {
		this.ime = "";
		this.rasa = "";
	}
	
	public Pas(String ime, int starost) {
		this.ime = ime;
		this.starost = starost;
	}
	
	
	
	
	/**
	 * @param ime
	 * @param rasa
	 */
	public Pas(String ime, String rasa) {
		super();
		this.ime = ime;
		this.rasa = rasa;
	}

	//Konstruktor sa parametrima
	public Pas(String ime, int starost, boolean vakcinisan, String rasa) {
		
		this(ime, starost);
		this.ime = ime;
		this.starost = starost;
		this.vakcinisan = vakcinisan;
		this.rasa = rasa;
		
	}

	//getter za atribut ime
	public String getIme() {
		return ime;
	}
	
	//setter za atribut ime
	public void setIme(String ime) {
		this.ime = ime;
	}

	//getter za atribut starost
	public int getStarost() {
		return starost;
	}

	//setter za atribut starost
	public void setStarost(int starost) {
		this.starost = starost;
	}

	//getter za atribut vakcinisan (posto je tipa boolean getter pocinje sa "is")
	public boolean isVakcinisan() {
		return vakcinisan;
	}

	//setter za atribut vakcinisan
	public void setVakcinisan(boolean vakcinisan) {
		this.vakcinisan = vakcinisan;
	}

	//getter za atribut rasa
	public String getRasa() {
		return rasa;
	}

	//setter za atribut rasa
	public void setRasa(String rasa) {
		this.rasa = rasa;
	}
	
	/*
	 * Metoda za vakcinisanje psa
	 * Bez parametara
	 * Vraća true ukoliko je pas uspešno vakcinisan,
	 * odnosno false ukoliko psa nije moguće vakcinisati (jer je već vakcinisan)
	 */
	public boolean vakcinisi() {
		boolean uspesno = false;
		if (!this.vakcinisan) {
			this.vakcinisan = true;
			uspesno = true;
		} 
		if(uspesno) {
			System.out.println("Vaš pas " + this.ime + " je uspešno vakcinisan.");
		} else {
			System.out.println("Vaš pas " + this.ime + " je neuspešno vakcinisan.");
		}
		//alternativno korišcenjem ternarnog operatora
		//System.out.println("Vaš pas " + this.ime + " je " + (uspesno ? "" : "ne") + "uspešno vakcinisan.");
		return uspesno;
	}
	
	/*
	 * Metoda ispisuje starost psa u ljudskim godinama.
	 * Za pretvaranje psećih u ljudske godine, pseće godine se množe sa 7.
	 */
	public void ispisiStarostULjudskimGodinama() {
		System.out.println("Vaš pas " + this.ime + " ima " + this.starost*7 + " ljudskih godina.");
	}
	
	
	//toString metoda
	@Override
	public String toString() {

		if(this.vakcinisan) {
			return "Pas " + this.ime + " je rase " + this.rasa + ", ima " + this.starost + " godina i vakcinisan je.";
		} else {
			return "Pas " + this.ime + " je rase " + this.rasa + ", ima " + this.starost + " godina i nije vakcinisan.";
		}
		//alternativno koriscenjem ternarnog operatora
		//return "Pas " + this.ime + " je rase " + this.rasa + ", ima " + this.starost + " godina i " + (this.vakcinisan ? "vakcinisan je" : "nije vakcinisan") + ".";
	}
	
}
