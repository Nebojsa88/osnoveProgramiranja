﻿package com.ftninformatika.pas;

import java.util.ArrayList;

public class Test {

	public static void main(String[] args) {

		//Kreira se 7 objekata klase Pas
		Pas badi = new Pas("Badi", 4, true, "zlatni retriver");
		Pas maza = new Pas("Maza", 2, true, "koker španijel");
		Pas lunja = new Pas("Lunja", 3, false, "mešanac");
		Pas sima = new Pas("Sima", 5, false, "epanjel breton");
		Pas lesi = new Pas("Lesi", 7, true, "skotski ovcar");
		Pas pongo = new Pas("Pongo", 3, true, "dalmatinac");
		Pas skubiDu = new Pas("Skubi Du", 6, true, "danska doga");

		//Formira se lista objekata klase Pas u koju dodajemo prethodno formirane objekte
		ArrayList<Pas> psi = new ArrayList<>();
		
		psi.add(badi);
		psi.add(maza);
		psi.add(lunja);
		psi.add(sima);
		psi.add(lesi);
		psi.add(pongo);
		psi.add(skubiDu);

		//Prolazimo kroz listu pasa i pronalazimo najstarijeg
		Pas najstarijiPas = psi.get(0);
		for (int i = 1; i < psi.size(); i++) {
			if (psi.get(i).getStarost() > najstarijiPas.getStarost()) {
				najstarijiPas = psi.get(i);
			}
		}

		//Ako imamo vise pasa koji imaju isto (najvise) godina ispisacemo sve
		//na osnovu starosti predhodno pronadjenog prvog najstarijeg
		for(int i = 0; i < psi.size(); i++) {
			if(psi.get(i).getStarost() == najstarijiPas.getStarost()) {
				System.out.println(psi.get(i));
			}
		}

		System.out.println("-------Najstariji pas-------");
		System.out.println(najstarijiPas);
		System.out.print("Ljudske godine najstarijeg psa: ");
		najstarijiPas.ispisiStarostULjudskimGodinama();
		sima.vakcinisi();

		//Prolazimo kroz listu pasa i ispisujemo imena vakcinisanih
		System.out.println("-------Ispis imena vakcinisanih pasa-------");
		for (int i = 0; i < psi.size(); i++) {
			Pas temp = psi.get(i);
			if (temp.isVakcinisan()) {
				System.out.println(temp.getIme());
			}
		}

	}

}
