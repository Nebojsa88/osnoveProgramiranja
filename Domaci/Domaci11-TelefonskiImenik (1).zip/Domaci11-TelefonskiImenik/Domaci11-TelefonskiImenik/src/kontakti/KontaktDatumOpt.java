package kontakti;

import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
/*
 * Verzija 3
 * Ubačen datum. Unos i izmena su izmenjeni tako da se od korisnika ne traži da unese
 * sve podatke o kontaktu ukoliko je uneo postojeći id kod unosa, ili nepostojeći id kod izmene.
 * 
 * Ispis zaglavlja tabele je izdvojen u posebnu metodu (printFormatedHeader).
 * Ispis podataka o jednom kontaktu (na osnovu indeksa) 
 * je takođe izdvojen u posebnu metodu (printContactData).
 */
public class KontaktDatumOpt {
	
	public static ArrayList<Integer> identifikatori = new ArrayList<Integer>();
	public static ArrayList<String> imena = new ArrayList<String>();
	public static ArrayList<String> prezimena = new ArrayList<String>();
	public static ArrayList<String> radnaMesta = new ArrayList<String>();
	public static ArrayList<String> brojeviProstorije = new ArrayList<String>();
	public static ArrayList<Integer> lokali = new ArrayList<Integer>();
	public static ArrayList<LocalDate> datumi = new ArrayList<LocalDate>();
	
	public static Scanner scanner = new Scanner(System.in);
	public static DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd.MM.yyyy");

	/*
	 * Metoda proverava da li je uneti string sa tastature ceo broj.
	 */
	public static boolean isNumber(String string) {
		try {
			Integer.parseInt(string);
		} catch (Exception e) {
			return false;
		}
		return true;
	}
	
	public static boolean isLocalDate(String datum) {
		try {
			LocalDate.parse(datum, formatter);
			return true;
		} catch (Exception e) {
			return false;
		}
	}
	
	/*
	 * Na osnovu zadatog identifikatora, proverava se da
	 * li postoji kontakt sa takvim ID-jem.
	 */
	public static boolean postojeciID(int id) {
		for (int i=0; i<identifikatori.size(); i++) {
			int currentID = identifikatori.get(i);
			if (currentID == id) {
				return true;
			}
		}
		return false;
	}

	public static void unesiKontakt() {

		int id;
		String ime;
		String prezime;
		String nazivRadnogMesta;
		String brojProstorije;
		int brojLokala;
		LocalDate datum = null;
		String idKontakta = null;
		do {
			System.out.print("Identifikacioni broj: ");
			idKontakta = scanner.nextLine();
			
		/*
		 * Proširujemo uslov za izlazak iz petlje. Ukoliko je korisnik uneo sadržaj koji nije
		 * broj ili ukoliko već postoji kontakt sa istim ID-jem, omogućujemo korisniku da
		 * ponovi unos
		 */
		} while(!isNumber(idKontakta) || postojeciID(Integer.parseInt(idKontakta)));
		
		id = Integer.parseInt(idKontakta);
		
		System.out.print("Ime kontakta: ");
		ime = scanner.nextLine();
		
		System.out.print("Prezime kontakta: ");
		prezime = scanner.nextLine();
		
		System.out.print("Naziv radnog mesta kontakta: ");
		nazivRadnogMesta = scanner.nextLine();
		
		System.out.print("Broj prostorije: ");
		brojProstorije = scanner.nextLine();
		
		String brLokala = null;
		do {
			System.out.print("Broj lokala: ");
			brLokala = scanner.nextLine();
		} while(!isNumber(brLokala));
		
		brojLokala = Integer.parseInt(brLokala);
		
		String strDatum;
		do {
			System.out.println("Datum: ");
			strDatum = scanner.nextLine();
		} while (!isLocalDate(strDatum));
		
		datum = LocalDate.parse(strDatum, formatter);

		identifikatori.add(id);
		imena.add(ime);
		prezimena.add(prezime);
		radnaMesta.add(nazivRadnogMesta);
		brojeviProstorije.add(brojProstorije);
		lokali.add(brojLokala);
		datumi.add(datum);
		System.out.println("Kontakt je uspešno dodat.");
		
	}

	public static void ispisKontakata() {
		//Metoda ispisuje formatirano zaglavlje
		printFormatedHeader();
		//Prolazimo for petljom kroz kolekcije
		for(int i = 0; i < identifikatori.size(); i++) {
			//Metoda ispisuje formatirane podatke o jednom kontaktu
			printContactData(i);
		}
	}

	public static void brisanjeKontakta() {

		int id;
		String idKontakta = null;
		do {
			System.out.println("Identifikacioni broj kontakta za brisanje: ");
			idKontakta = scanner.nextLine().trim();
		} while(!isNumber(idKontakta));
		
		id = Integer.parseInt(idKontakta);

		//prolazimo kroz listu na standardan način
		for (int i = 0; i < identifikatori.size(); i++) {
			//Ukoliko pronađemo traženi kontakt, brišemo ga
			if(identifikatori.get(i) == id) {
				identifikatori.remove(i);
				imena.remove(i);
				prezimena.remove(i);
				radnaMesta.remove(i);
				brojeviProstorije.remove(i);
				lokali.remove(i);
				datumi.remove(i);
				return;
			}
		}
		
		System.out.println("Kontakt sa zadatim brojem ne postoji.");

	}

	public static void kontaktiULokalu() {

		String brLokala = null;
		do {
			System.out.println("Unesite broj lokala: ");
			brLokala = scanner.nextLine();
		} while(!isNumber(brLokala));
		
		int brojLokala = Integer.valueOf(brLokala);
		printFormatedHeader();
		
		//prolazimo kroz listu na standardan način
		for (int i = 0; i < lokali.size(); i++) {
			if(lokali.get(i) == brojLokala) {
				printContactData(i);
			} 
		}
	}

	public static void kontaktiNaIstomRadnomMestu() {

		System.out.println("Unesite naziv radnog mesta: ");
		String radnoMesto = scanner.nextLine();
		printFormatedHeader();
		for (int i = 0; i < radnaMesta.size(); i++) {
			if(radnaMesta.get(i).equalsIgnoreCase(radnoMesto)) {
				printContactData(i);
			}
		}
	}

	public static void kontaktiSaIstimImenom() {

		System.out.println("Unesite ime kontakta: ");
		String ime = scanner.nextLine();
		printFormatedHeader();
		
		for (int i = 0; i < imena.size(); i++) {
			if (imena.get(i).equalsIgnoreCase(ime)) {
				printContactData(i);
			}
		}
	}

	public static void kontaktiPoUslovima8() {

		System.out.println("Unesite ime kontakta: ");
		String ime = scanner.nextLine();
		System.out.println("Unesite prezime kontakta: ");
		String prezime = scanner.nextLine();
		System.out.println("Unesite početna slova naziva radnog mesta: ");
		String radnoMesto = scanner.nextLine();
		printFormatedHeader();
		//prolazimo kroz listu na standardan način
		for (int i = 0; i < identifikatori.size(); i++) {
			
			if (imena.get(i).equalsIgnoreCase(ime) && prezimena.get(i).equalsIgnoreCase(prezime) &&
					radnaMesta.get(i).toLowerCase().startsWith(radnoMesto.toLowerCase())) {
				printContactData(i);
			}
		}
	}

	public static void izmenaKontakta() {

		String idKontakta = null;
		do {
			System.out.println("Unesite identifikacioni broj kontakta: ");
			idKontakta = scanner.nextLine();
		} while(!isNumber(idKontakta) || !postojeciID(Integer.parseInt(idKontakta)));
		
		int id = Integer.valueOf(idKontakta);
		String ime;
		String prezime;
		String nazivRadnogMesta;
		String brojProstorije;
		int brojLokala;
		LocalDate datum = null;
		System.out.print("Ime kontakta: ");
		ime = scanner.nextLine();
		System.out.print("Prezime kontakta: ");
		prezime = scanner.nextLine();
		System.out.print("Naziv radnog mesta: ");
		nazivRadnogMesta = scanner.nextLine();
		System.out.print("Broj prostorije: ");
		brojProstorije = scanner.nextLine();
		String brLokala = null;
		do {
			System.out.print("Broj lokala: ");
			brLokala = scanner.nextLine();
		} while(!isNumber(brLokala));
		brojLokala = Integer.valueOf(brLokala);
		
		String strDatum;
		do {
			System.out.println("Datum: ");
			strDatum = scanner.nextLine();
		} while (!isLocalDate(strDatum));
		
		datum = LocalDate.parse(strDatum, formatter);

		//dodavanje unosa u kolekcije
		int i = identifikatori.indexOf(id);
		if (i > -1) {
			imena.set(i, ime); 
			prezimena.set(i, prezime);
			radnaMesta.set(i, nazivRadnogMesta);
			brojeviProstorije.set(i, brojProstorije);
			lokali.set(i, brojLokala);
			datumi.set(i, datum);
			System.out.println("Izmena je uspešno izvršena.");
		}
	}
	
	public static void save(String path) {
		
		/*
		 * lista koja će se popuniti redovima koji će biti u formatu:
		 * identifikacioniBroj;imeKontakta;prezimeKontakta;nazivRadnogMesta;brojProstorije;brojLokala
		 */
		ArrayList<String> lines = new ArrayList<String>();
		
		//prolazimo kroz listu na standardan način
		for (int i = 0; i < identifikatori.size(); i++) {
			/*
			 * Kreiramo String line koji predstavlja jedan red u tekstualnoj datoteci a sadrži informacije o pojedinačnom kontaktu
			 */ 
			String line = identifikatori.get(i) + ";" + imena.get(i) + ";" + prezimena.get(i) + ";" + radnaMesta.get(i)
							+ ";" + brojeviProstorije.get(i) + ";" + lokali.get(i)+";"+formatter.format(datumi.get(i));
			lines.add(line);
		}
		
		try {
			Files.write(Paths.get(path), lines, Charset.defaultCharset(), StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING);
		} catch (java.io.IOException e) {
			System.out.println("Datoteka " + path + " nije pronaðena.");
			e.printStackTrace();
		}
	}
	
	/*
	 * Metoda učitava podatke o kontaktima iz tekstualnog fajla čiji se naziv prosleđuje u listaKontakata koji je atribut klase Imenik.
	 */
	public static void load(String path) {
		
		identifikatori = new ArrayList<Integer>();
		imena = new ArrayList<String>();
		prezimena = new ArrayList<String>();
		radnaMesta = new ArrayList<String>();
		brojeviProstorije = new ArrayList<String>();
		lokali = new ArrayList<Integer>();
		datumi = new ArrayList<LocalDate>();
		List<String> lines;
		try {
			//učitavaju se sve linije iz fajla
			lines = Files.readAllLines(Paths.get(path), Charset.defaultCharset());
			
			/*
			 * prolazi se for petljom kroz svaku liniju koja je u formatu:
			 * identifikator;ime;prezime;radnoMesto;brojProstorije;lokal;datum
			 */

			for (String line: lines) {
				//svaka linija se "secka" na reči koje su odvojene znakom ; pomoću metode split klase String i tako se dobija niz stringova
				String[] attributes = line.split(";");
				
				/*
				 * Pošto znamo redosled vrednosti koje su pisane u datoteci znamo kojim redom da ih preuzimamo iz niza attributes
				 */
				int id = Integer.parseInt(attributes[0]); 
				String ime = attributes[1];
				String prezime = attributes[2]; 
				String radnoMesto = attributes[3]; 
				String brojProstorije = attributes[4]; 
				int brojLokala = Integer.parseInt(attributes[5]);
				LocalDate datum = LocalDate.parse(attributes[6], formatter);

				/*
				 * Izdvojene vrednosti smeštamo u liste
				 */
				identifikatori.add(id);
				imena.add(ime);
				prezimena.add(prezime);
				radnaMesta.add(radnoMesto);
				brojeviProstorije.add(brojProstorije);
				lokali.add(brojLokala);
				datumi.add(datum);
			}
		} catch (java.io.IOException e) {
			System.out.println("Datoteka " + path + " nije pronaðena.");
			e.printStackTrace();
		}
	
	}

	//Štampa zaglavlje za tabelarni ispis kontakata
	public static void printFormatedHeader() {
		System.out.printf("%15s %15s %15s %25s %15s %15s %20s \n", 
				"Id", "Ime kontakta", "Prezime kontakta", "Naziv radnog mesta",
				"Broj prostorije", "Broj lokala", "Datum");
		System.out.println("-------------------------------------------------------------------------------------------------------------------------------------");
		
	}
	
	//Štampa formatirane podatke o jednom kontaktu
	public static void printContactData(int index) {
		System.out.printf("%15d %15s %15s %25s %15s %15d %20s \n",
				identifikatori.get(index), imena.get(index), prezimena.get(index),
				radnaMesta.get(index), brojeviProstorije.get(index), lokali.get(index),
				formatter.format(datumi.get(index)));
	
	}
	
	public static void main(String[] args) {

		if(Files.exists(Paths.get("kontakti_datum.txt"))) {
			load("kontakti_datum.txt");
		}
		
		String answer = null;

		do {

			System.out.println("Meni:");
			System.out.println("1. Unesi kontakt");
			System.out.println("2. Ispis svih kontakata");
			System.out.println("3. Brisanje kontakta");
			System.out.println("4. Ispis kontakata u istom lokalu");
			System.out.println("5. Ispis kontakata sa istim radnim mestom");
			System.out.println("6. Ispis kontakata sa istim imenom");
			System.out.println("7. Ispis sa istim imenom, prezimenom i nazivom radnog mesta koje počinje sa prosleđenim stringom");
			System.out.println("8. Izmena kontakta");
			System.out.println("x. Izlaz");

			answer = scanner.nextLine();

			switch (answer) {
			case "1":
				unesiKontakt();
				break;
			case "2":
				ispisKontakata();
				break;
			case "3":
				brisanjeKontakta();
				break;
			case "4":
				kontaktiULokalu();
				break;
			case "5":
				kontaktiNaIstomRadnomMestu();
				break;
			case "6":
				kontaktiSaIstimImenom();
				break;
			case "7":
				kontaktiPoUslovima8();
				break;
			case "8":
				izmenaKontakta();
				break;
			case "x":
				break;
			default:
				System.out.println("Pogrešan izbor opcije. Pokušajte ponovo.");
			}

		} while (!answer.equals("x"));

		save("kontakti_datum.txt");
		scanner.close();
	}

}
