package com.ftninformatika.kurs;

import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.List;

/*
 * Provere unutar konstruktora i set metoda nisu neophodne jer iste ili slične provere
 * imamo u Test klasi. Dodatne provere su uvek dobre, ali takođe "prljaju" kod.
 * Treba dobro razmisliti da li nam one trebaju na dva mesta.
 */
public class Kurs {

	private int sifra;
	private String nazivKursa;
	private ArrayList<String> polaznici;
	private double cenaPoPolazniku;
	private double ukupnaCenaKursa;

	/*
	 * Konstruktor bez parametara
	 */
	public Kurs() {
		this.polaznici = new ArrayList<String>();
		this.cenaPoPolazniku = 15000;
	}

	/*
	 * Konstruktor sa 2 parametra
	 */
	public Kurs(int sifra, String nazivKursa) {
		if (String.valueOf(sifra).length() == 5) {
			this.sifra = sifra;
		} else {
			this.sifra = 11111;
			System.out.println("Uneta je sifra koja nije petocifrena. Sifra je postavljena na 11111.");
		}

		this.nazivKursa = nazivKursa;
		this.cenaPoPolazniku = 15000;
		this.polaznici = new ArrayList<String>();
	}

	/*
	 * Kostruktor sa 3 parametara
	 */
	public Kurs(int sifra, String nazivKursa, double cenaPoPolazniku) {
		if (String.valueOf(sifra).length() == 5) {
			this.sifra = sifra;
		} else {
			this.sifra = 11111;
			System.out.println("Uneta je sifra koja nije petocifrena. Sifra je postavljena na 11111.");
		}

		this.nazivKursa = nazivKursa;
		if (cenaPoPolazniku >= 0) {
			this.cenaPoPolazniku = cenaPoPolazniku;
		} else {
			this.cenaPoPolazniku = 15000;
		}

		this.polaznici = new ArrayList<String>();
	}
	
	

	public Kurs(int sifra, String nazivKursa, ArrayList<String> polaznici, double cenaPoPolazniku) {
		super();
		if (String.valueOf(sifra).length() == 5) {
			this.sifra = sifra;
		} else {
			this.sifra = 11111;
			System.out.println("Uneta je sifra koja nije petocifrena. Sifra je postavljena na 11111.");
		}

		this.nazivKursa = nazivKursa;
		if (cenaPoPolazniku >= 0) {
			this.cenaPoPolazniku = cenaPoPolazniku;
		} else {
			this.cenaPoPolazniku = 15000;
		}

		this.polaznici = polaznici;
	}

	/*
	 * getter za atribut sifra
	 */
	public int getSifra() {
		return this.sifra;
	}

	/*
	 * setter za atribut sifra
	 */
	public void setSifra(int sifra) {
		if (String.valueOf(sifra).length() == 5) {
			this.sifra = sifra;
		} else {
			System.out.println("Uneta sifra nema tacno 5 cifara. Izmena nije izvrsena.");
		}
	}

	/*
	 * getter za atibut nazivKursa
	 */
	public String getNazivKursa() {
		return this.nazivKursa;
	}

	/*
	 * setter za nazivKursa
	 */
	public void setNazivKursa(String nazivKursa) {
		this.nazivKursa = nazivKursa;
	}

	/*
	 * getter za atribut polaznici
	 */
	public ArrayList<String> getPolaznici() {
		return this.polaznici;
	}

	/*
	 * setter za atribut polaznici
	 */
	public void setPolaznici(ArrayList<String> polaznici) {
		this.polaznici = polaznici;
	}

	/*
	 * getter za atribut cenaPoPolazniku
	 */
	public double getCenaPoPolazniku() {
		return this.cenaPoPolazniku;
	}

	/*
	 * setter za atribut cenaPoPolazniku
	 */
	public void setCenaPoPolazniku(double cenaPoPolazniku) {
		if (cenaPoPolazniku >= 0) {
			this.cenaPoPolazniku = cenaPoPolazniku;
		} else {
			System.out.println("Uneta cena po polazniku je manja od 0. Izmena nije izvrsena.");
		}

	}

	/*
	 * getter za atribut ukupnaCenaKursa
	 */
	public double getUkupnaCenaKursa() {
		this.ukupnaCenaKursa = this.polaznici.size() * this.cenaPoPolazniku;
		return ukupnaCenaKursa;
	}

	/*
	 * U listi polaznici se pronalazi polaznik zadatog imena
	 */
	public ArrayList<String> pronadjiPolaznika(String polaznik) {

		ArrayList<String> listaRezultata = new ArrayList<>();
		for (int i = 0; i < this.polaznici.size(); i++) {
			if (this.polaznici.get(i).equals(polaznik)) {
				listaRezultata.add(this.polaznici.get(i));
			}
		}
		return listaRezultata;
	}

	public void ispisiPolaznikeSaIstimImenom(String ime) {

		for (int i = 0; i < this.polaznici.size(); i++) {
			String[] names = this.polaznici.get(i).split(" ");

			if (names[0].equals(ime)) {
				System.out.println(this.polaznici.get(i));
			}
		}

	}

	/*
	 * Iz liste polaznika uklanja se polaznik zadatog imena
	 */
	public boolean obrisiPolaznika(String polaznik) {

		for (int i = 0; i < this.polaznici.size(); i++) {
			if (this.polaznici.get(i).equals(polaznik)) {
				this.polaznici.remove(i);
				return true;
			}
		}
		return false;
	}

	public boolean dodajPolaznika(String polaznik) {
		
		for (int i = 0; i < this.polaznici.size(); i++) {
			if (this.polaznici.get(i).equals(polaznik)) {
				return false;
			}
		}
		this.polaznici.add(polaznik);
		return true;

	}

	/*
	 * Iz liste polaznika menja se polaznik imena stariPolaznik za polaznika
	 * imena noviPolaznik
	 */
	public boolean izmeniPolaznika(String stariPolaznik, String noviPolaznik) {

		for (int i = 0; i < this.polaznici.size(); i++) {
			if (this.polaznici.get(i).equals(stariPolaznik)) {
				this.polaznici.set(i, noviPolaznik);
				return true;
			}
		}

		return false;
	}

	/*
	 * Izračunava broj polaznika
	 */
	public int vratiBrojPolaznika() {

		return this.polaznici.size();
	}

	/*
	 * Ispis liste polaznici
	 */
	public void ispisiPolaznike() {
		System.out.println(">>>>>>>>>>Polaznici kursa<<<<<<<<<<");
		for (int i = 0; i < this.polaznici.size(); i++) {
			System.out.println(this.polaznici.get(i));
		}
	}

	@Override
	public String toString() {
		return "Kurs [sifra=" + this.sifra + ", nazivKursa=" + this.nazivKursa + ", cenaPoPolazniku=" + this.cenaPoPolazniku
				+ ", getUkupnaCenaKursa()=" + getUkupnaCenaKursa() + "]";
	}

	/*
	 * Metoda save za skladištenje liste polaznika u tekstualnu datoteku
	 */
	public void save(String path) {

		ArrayList<String> lines = new ArrayList<String>();
		for (int i = 0; i < polaznici.size(); i++) {
			String line = polaznici.get(i);
			lines.add(line);
		}
		try {
			Files.write(Paths.get(path), lines, Charset.defaultCharset(), StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING, StandardOpenOption.WRITE);
		} catch (IOException e) {
			System.out.println("File " + path + " not found.");
		}
		
	}

	/*
	 * Metoda load za učitavanje liste polaznika iz tekstualne datoteke
	 */
	public void load(String path) {

		List<String> lines = new ArrayList<>();
		polaznici.clear();
		try {
			lines = Files.readAllLines(Paths.get(path), Charset.defaultCharset());

			for (String line : lines) {
				polaznici.add(line);
			}
		} catch (java.io.IOException e) {
			System.out.println("Datoteka " + path + " nije prona�ena.");
		}
	}

	

}
