package com.ftninformatika.kurs;

import java.util.Scanner;

public class Test {

	public static Scanner scanner = new Scanner(System.in);
	
	public static boolean proveriValidnostCene(String cenaPoPolazniku) {
		try {
			double cena = Double.parseDouble(cenaPoPolazniku);
			if (cena >= 0) {
				return true;
			}
			return false;
		}catch(Exception e) {
			return false;
		}
	}

	public static boolean proveriValidnostSifre(String sifra) {
		try {
			
			if (sifra.length() == 5) {
				Integer.parseInt(sifra);
				return true;
			}
			return false;
		}catch(NumberFormatException e){
			return false;
		}
		
	}
	/**
	 * Unos podataka o kursu
	 */
	public static void unesiKurs(Kurs kurs) {
		String sifra;
		do {
			System.out.print("Sifra: ");
			sifra = scanner.nextLine();
		} while (!proveriValidnostSifre(sifra));
		kurs.setSifra(Integer.parseInt(sifra));

		String naziv;
		System.out.print("Naziv: ");
		naziv = scanner.nextLine();
		kurs.setNazivKursa(naziv);

		String cenaPoPolazniku;
		do {
			System.out.print("Cena po polazniku: ");
			cenaPoPolazniku = scanner.nextLine();
		} while (!proveriValidnostCene(cenaPoPolazniku));
		double cena = Double.parseDouble(cenaPoPolazniku);
		kurs.setCenaPoPolazniku(cena);
		System.out.println(kurs);

	}

	/**
	 * Unos polaznika
	 */
	public static void unesiPolaznika(Kurs kurs) {

		String polaznik;
		System.out.print("Ime i prezime polaznika: ");
		polaznik = scanner.nextLine();
		
		boolean flag = kurs.dodajPolaznika(polaznik);
		if(flag) {
			System.out.println("Uspesno unet polaznik.");
		} else {
			System.out.println("Neuspesan pokusaj unosa.");
		}

	}

	/**
	 * Izmena polaznika
	 */
	public static void izmeniPolaznika(Kurs kurs) {
		String staroIme, novoIme;
		System.out.print("Staro ime i prezime: ");
		staroIme = scanner.nextLine();
		System.out.print("Novo ime i prezime: ");
		novoIme = scanner.nextLine();
		boolean flag = kurs.izmeniPolaznika(staroIme, novoIme);
		if(flag) {
			System.out.println("Uspesno izmenjen polaznik.");
		} else {
			System.out.println("Neuspesan pokusaj izmene.");
		}
	}

	/**
	 * Brisanje polaznika
	 */
	public static void obrisiPolaznika(Kurs kurs) {

		String polaznik;
		System.out.print("Ime i prezime polaznika: ");
		polaznik = scanner.nextLine();
		boolean flag = kurs.obrisiPolaznika(polaznik);
		if(flag) {
			System.out.println("Uspesno izbrisan polaznik.");
		} else {
			System.out.println("Neuspesan pokusaj birsanja.");
		}

	}

	public static void ispisiPolaznikeSaIstimImenom(Kurs kurs) {

		String ime;
		System.out.print("Ime polaznika: ");
		ime = scanner.nextLine();
		kurs.ispisiPolaznikeSaIstimImenom(ime);
	}
	
	public static void ispisiPolaznike(Kurs kurs) {
		kurs.ispisiPolaznike();
		
	}
	
	

	public static void main(String[] args) {

		Kurs kurs = new Kurs();
		
		kurs.load("polaznici.txt");

		String answer = null;

		do {
			// Prikaz menija
			System.out.println("Meni:");
			System.out.println("1. Kreiraj kurs");
			System.out.println("2. Unesi polaznika");
			System.out.println("3. Izmeni polaznika");
			System.out.println("4. Izbriši polaznika");
			System.out.println("5. Ispiši polaznike sa istim imenom");
			System.out.println("6. Ispiši podatke o kursu i polaznicima");

			System.out.println("x. Izlaz");

			// Unošenje opcije sa tastature
			answer = scanner.nextLine();

			// Izvrsavanje unete opcije (poziv izabrane funkcije)
			switch (answer) {
			case "1":
				unesiKurs(kurs);
				break;
			case "2":
				unesiPolaznika(kurs);
				kurs.save("polaznici.txt");
				break;
			case "3":
				izmeniPolaznika(kurs);
				kurs.save("polaznici.txt");
				break;	
			case "4":
				obrisiPolaznika(kurs);
				kurs.save("polaznici.txt");
				break;
			case "5":
				ispisiPolaznikeSaIstimImenom(kurs);
				break;
			case "6":
				ispisiPolaznike(kurs);
				break;
			case "x":
				break;
			default:
				System.out.println("Pogresan izbor opcije. Pokusajte ponovo.");
			}

		} while (!answer.equals("x"));

		//kurs.save("polaznici.txt");
		scanner.close();
		
	}
	
}
