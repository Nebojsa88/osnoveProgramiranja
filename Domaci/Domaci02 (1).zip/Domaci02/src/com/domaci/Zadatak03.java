package com.domaci;

public class Zadatak03 {

	public static void main(String[] args) {
		double stranicaA = 4;
		double stranicaB = 5;
		double obim = 2 * stranicaA + 2 * stranicaB;
		double povrsina = stranicaA * stranicaB;
		
		System.out.println("a=" + stranicaA + " b=" + stranicaB + " O=" + obim + " P=" + povrsina);

	}

}
