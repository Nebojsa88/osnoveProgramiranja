package com.domaci;

public class Zadatak01 {

	public static void main(String[] args) {
		double tempCel = 40;
		double tempFar = tempCel * 1.8 + 32;
		System.out.println(tempCel + "C = " + tempFar + "F");
	}

}
